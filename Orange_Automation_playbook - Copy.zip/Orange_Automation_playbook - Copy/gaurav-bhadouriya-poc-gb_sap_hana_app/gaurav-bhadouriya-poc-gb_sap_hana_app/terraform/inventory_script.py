import json
import os
from jinja2 import Template

data_file_backup = open('output_befor_update.json', 'r')
data_file_new = open('output_after_update.json', 'r')

# parse and stockage in data
data_old = json.load(data_file_backup)
data_new = json.load(data_file_new)

## VARIABLES
list_ip_of_old_tfstate=[]
groups=[]
tenant_id=[]
path_ansible= "."
path_inventory=f"{path_ansible}/hosts"
inventory = open(path_inventory,'w')

## TEMPLATES iventory_global
File = open('template_inventory_global', 'r')
content = File.read()
File.close()

## TEMPLATES inventory_lin_postconf
Template_lin_postconf = open('template_inventory_lin_postconf', 'r')
content_template_lin_postconf = Template_lin_postconf.read()
Template_lin_postconf.close()

## TEMPLATES inventory_win_postconf
Template_win_postconf = open('template_inventory_win_postconf', 'r')
content_template_win_postconf = Template_win_postconf.read()
Template_win_postconf.close()

## LIST IPs FROM TFSTATE BEFOR UPDATE
for key, value in data_old.items():
        values = key.split(".")
        if isinstance(value['value'], dict):
            for sub_key, sub_value in value['value'].items():                
                list_ip_of_old_tfstate.append(str(sub_value['vm_ip'][0]))
                                

## LIST ALL TENANT ID AND GROUPS(environment)
for key, value in data_new.items():
 if isinstance(value['value'], dict):
    for sub_key, sub_value in value['value'].items():
      tenant= sub_value['tenant_id']
      group = sub_value['vm_environment']
      if tenant not in tenant_id:
         tenant_id.append(tenant)
      if group not in groups:
         groups.append(group)


# Render the template and pass the variables for inventory_global
for key, value in data_new.items():
 if isinstance(value['value'], dict):
    print("on est dans la boucle 1")
    
    template = Template(content)
    rendered_form = template.render(groups=groups, vms= value['value'].items(), tenant=tenant_id)

# SAVE TEMPLATE 
output = open('inventory_global', 'w')
output.write(rendered_form)
output.close()

# Render the template and pass the variables for inventory_local
for key, value in data_new.items():

    if isinstance(value['value'], dict):

                template = Template(content_template_win_postconf)
                rendered_form = template.render(groups=groups, vms= value['value'].items(), list_ip_of_old_tfstate= list_ip_of_old_tfstate)
# SAVE TEMPLATE
output = open('inventory_win_local', 'w')
output.write(rendered_form)
output.close()

# Render the template and pass the variables for inventory_local
for key, value in data_new.items():

    if isinstance(value['value'], dict):

                template = Template(content_template_lin_postconf)
                rendered_form = template.render(groups=groups, vms= value['value'].items(), list_ip_of_old_tfstate= list_ip_of_old_tfstate)
# SAVE TEMPLATE
output = open('inventory_lin_local', 'w')
output.write(rendered_form)
output.close()










