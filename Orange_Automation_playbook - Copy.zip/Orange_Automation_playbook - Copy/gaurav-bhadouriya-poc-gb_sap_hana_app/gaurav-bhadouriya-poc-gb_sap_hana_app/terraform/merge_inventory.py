import configparser
from io import StringIO
config1 = configparser.ConfigParser()
config2 = configparser.ConfigParser()

config1.read('inventory/00hosts')
config2.read('inventory_global')
for section in config2.sections():
     if not config1.has_section(section):
                                   config1.add_section(section)
     for key, value in config2.items(section):
                   config1.set(section, key, value)
with open('inventory/00hosts', 'w') as merge:
          config1.write(merge, space_around_delimiters=False)
