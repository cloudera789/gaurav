# ocb.cyberark-account

Create account in cyberark using PVWA API, with a credential stored retreived with the CCP API.

## Requirements

- Ansible version >= 2.9
- module ansible: cyberark_authentication, cyberark_account and cyberark_credential provided by the
  [ansible security automation collection](https://github.com/cyberark/ansible-security-automation-collection) from CyberArk,
  a local copy is available on [gitlab casa](https://gitlab-bypassproxy.casa.uro.equant.com/ocb-csd/pco/st/ansible/modules/cyberark-ansible-collection)
- Operating systems: Any ; the role must be run with delegate_to directive
(localhost or any node that can be request CCP and PVWA Api)

## Role Variables

|Name|Type|Description|Example|Default|Mandatory|
|----------------------------|------|-----------------------------------|------------------------|-----------------------------|---|
|`oCyberarkCcpUrl`             |string|Base url for the ccp api           |https://ccp.exemple.com |                             |Yes|
|`oCyberarkAppId`              |string|App id to query ccp api            |AWX_XXX                 |                             |Yes|
|`oCyberarkM2MSafe`            |string|safe which contains the m2m account|XX_XX_XX                |                             |Yes|
|`oCyberarkM2Maccount`         |string|username for the m2m account       |M2M_AWX                 |                             |Yes|
|`oCyberarkPvwaUrl`            |string|url for the pvwa api               |https://pvwa.exemple.com|                             |Yes|
|`oCyberakVerify`              |bool  |sould ansible verify api certif.   |False                   |True                         |No |
|`oCyberarkReason`             |string|comment to get m2m account         |                        |'ansible to register account'|No |
|`oCyberarkAccount `           |list of dict| see bellow                  |                        |                             |Yes|

each account entry in ` oCyberarkAccount` must contains:
|Name                |Type    |Description                                    |
|---                 |---     |---                                            |
| `state`              | string | state of account (present|absent)             |
| `safe`               | string | safe name to store the account                |
| `name`               | string | account name, must be in form user@address    |
| `user`               | string | username for the account                      |
| `address`            | string | target ip address for the account             |
| `secret`             | string | password or key for the account               |
| `secretType`         | string | type of secret for the account (password|key) |
| `cpmEnabled`         | bool   | yes if the password rotation is enabled       |
| `cpmDisableReasaon`  | string | if cmpEnable is false, raison to disable it   |
| `hostname`           | string | hostname for the account                      |
| `comment`            | string | comment for the account                       |
| `reconciliationSafe` | string | reconciliation account safe                   |
| `reconciliationName` | string | name of reconciliation account                |

## Example of playbook
Store 2 account in cyberark
~~~
- hosts: servers
  vars:
    oCyberarkCcpUrl: https://ccp.example.com
    oCyberarkAppId: MY_APP_ID
    oCyberarkM2MSafe: M2M_SAFE
    oCyberarkM2Maccount: ansible
    oCyberarkPvwaUrl: https://pvwa.example.com
    oCyberakVerify: false
    oCyberarkAccount:
      - state: present
        name: admin@10.0.0.1
        user: admin
        address: 10.0.0.1
        secret: MyNewPassw0rd
        cpmEnabled: true
        comment: 'just an example'
      - state: present
        name: user1@10.0.0.1
        user: user1
        address: 10.0.0.1
        cpmEnabled: false
        cpmDisableReason: dont rotate this password
        comment: 'just another example'
  roles: ocb.cyberarkaccount

~~~

## Contributing
:point_right:  Create an issue or a [Merge Request](http://devops-store.rd.francetelecom.fr/dos?p=3539) to contribute.

## Copyright
Copyright (c) 2022, Orange. All rights reserved.

## License
[3-Clause BSD License](LICENSE.md)

## Author Information
Maintainer:
* renaud.breard@orange.com

Contributors:
