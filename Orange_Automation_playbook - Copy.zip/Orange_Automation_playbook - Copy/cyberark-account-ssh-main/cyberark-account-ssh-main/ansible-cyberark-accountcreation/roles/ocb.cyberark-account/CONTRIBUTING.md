## How to contribute to this role

### **Did you find a bug?**
* **Ensure the bug was not already reported** by searching open or closed **Issues**.
* If you're unable to find an issue addressing the problem, open a new one. Be sure to include a **title and clear description**, and much relevant information as possible, and a **code sample** or an **executable test case** demonstrating the expected behaviour that is not occurring.

### **Do you intend to add a new feature or change an existing one?**
* Suggest your change in new Issue.

### **How to contribute**
* Create a new feature branch based on the dev branch.
* Give it a descriptive name of what you're about to do starting by `ft-`
* Write your code and tests.
* Add the Issue title in the commit message (ex: *Issue #1: Add documentations*) and Push.
* Update the [CHANGELOG.md](CHANGELOG.md) file.
* Add your name at the end of the [README.md](README.md), *Contributors* part, because you deserve it.
* Be sure the Pipeline is **success**.
* Create a new GitLab merge request to the dev branch. Ensure the description clearly describes the problem and solution. Include the relevant issue number if applicable.
* Submit your merge request and congratulate yourself while waiting for validation from the maintainer.

Thanks! :kiss:
