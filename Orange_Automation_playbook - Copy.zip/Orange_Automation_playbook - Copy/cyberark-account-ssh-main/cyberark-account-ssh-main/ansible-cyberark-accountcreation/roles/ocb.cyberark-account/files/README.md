> *file* folder contains files which can be copied from tasks.
