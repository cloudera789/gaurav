deploy nginx
================
This playbook deploys / update nginx
All the backends are in ssl on default port 443
The created backend is available on http(s)://{{SERVICE}}.{{DOMAIN}}, don't forget to create the CNAME on the right server on the IPA (or in your hosts file).
For Example : http(s)://ambari.data.talend

By default the basic auth is disable, and the kibana backend is configured as default :
```
ansible-playbook -i ../inventories/<hosts> deployNginx.yml -l talenhdp-ves001 -e IPA_USER="admin" -e IPA_PASSWORD="adminadmin2"  --list-hosts
```

If you want to use basic auth, you can activate it using BASIC_AUTH parameter
```
ansible-playbook -i ../inventories/<hosts> deployNginx.yml -l talenhdp-ves001 -e BASIC_AUTH="true" --list-hosts
```

If you want to install a different backen, configure SERVICE, SERVICE_PROTOCOL, SERVICE_HOST, SERVICE_PORT vars, here for ambari service :
```
ansible-playbook -i ../inventories/<hosts> deployNginx.yml -l talenhdp-ves001 -e SERVICE="ambari" -e SERVICE_PROTOCOL="https" -e SERVICE_HOST="10.102.16.6" -e SERVICE_PORT="8083" --list-hosts
```

To deploy certificates or csr only : use tags :
```
ansible-playbook -i ../inventories/fe_obklab deployNginx.yml -e IPA_USER="admin" -e IPA_PASSWORD="adminadmin2" --tags=csr
```

Post Config
-----------

Add following entry to your local VM /etc/hosts :
```
10.102.10.<ves001_IP_lastdigit> <hosts>-ves001.data.<hosts> yarnui.data.<hosts> sparkhistory.data.<hosts> ambari.data.<hosts> knox.data.<hosts> jobhistory.data.<hosts> oozie.data.<hosts> ranger.data.<hosts>
```

Example Playbook
----------------
    - hosts: edge
      roles:
        - role: nginx
