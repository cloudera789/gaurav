# Main Description
+	The aim of these playbooks is to automate instantiation of pub sub resources in GCP and to run python scripts to validate the deployment
+	A docker container (Cloud run component) is installed also to deploy a node.js server. It is used to validate push delivery

# Ansible Inventory
+	ansible_hosts_edh/dryrunops_bastion

# Testing Environment:
+	Bootstrap : obitsvcp-vbt001 
+	OS : CentoOS Linux release 7.9.2009
+	Host: dryrunops-gcp001.data.edh
+   User: gcpadmin
+   Additional information: https://ocbconfluence.equant.com/x/coSY

# Additional Information:
+	There is one terraform project per GCP component
example: /home/gcpadmin//scripts/terraform/pubsub

# Description of playbooks
+	**playbook_pubsub_destroy_all_terraform_resources.yml**
        A playbook is executed to run terraform. Please note that only the GCP resources inside terraform scripts « pubsub*cloudrun*demo*.tf» are deleted

    +	Example of use:
    `sudo -E -u edh_automation ansible-playbook -v -i ansible_hosts_edh/dryrunops_bastion pubsub/playbook_pubsub_destroy_all_terraform_resources.yml --private-key=/etc/security/ocb_ssh_automation/ocb_edh_automation_dryrunops_key --skip-tags=minimalChecking -u edh_automation --vault-password-file /etc/security/ocb_ssh_automation/vault/dryrunops_bastion_vault_pass`
<br />

+	**playbook_pubsub_subscription_pull_deployment.yml**
        This playbook will instantiate a pubsub subscriber resources with a pull delivery.
        Terraform scripts are generated in /home/gcpadmin/scripts/terraform/pubsub
        Playbook will run terraform scripts to create resources in GCP. 

    +	Example of use:
    `sudo -E -u edh_automation ansible-playbook -v -i ansible_hosts_edh/dryrunops_bastion pubsub/playbook_pubsub_subscription_pull_deployment.yml --private-key=/etc/security/ocb_ssh_automation/ocb_edh_automation_dryrunops_key --skip-tags=minimalChecking -u edh_automation -e GCP_TOPIC_NAME=topicdemoocb001 -e TOPOLOGY_REGION=europe-west1 -e GCP_TOPICSUBPULL_NAME=topicdemoocb001subpull001 -e GCP_TOPICSUBPULL_LABEL_KEY=topicdemoocb001subpull001 -e GCP_TOPICSUBPULL_LABEL_VALUE=topicdemoocb001subpull001 -e GCP_TOPICSUBPULL_MESSAGE_RETENTION_SEC=1200 -e GCP_TOPICSUBPULL_RETAIL_ACKED_MESSAGES=true -e GCP_TOPICSUBPULL_ACK_DEADLINE_SECONDS=59 -e GCP_TOPICSUBPULL_TTL_SEC=300000 -e GCP_TOPICSUBPULL_MIN_BACKOFF_SEC=10 -e GCP_TOPICSUBPULL_ENABLE_MESSAGE_ORDERING=true -e CHANNEL= --vault-password-file /etc/security/ocb_ssh_automation/vault/dryrunops_bastion_vault_pass`
<br />

+	**playbook_pubsub_subscription_push_deployment.yml**
        This playbook will instantiate a pubsub subscriber resources with a push delivery.
        Terraform scripts are generated in /home/gcpadmin/scripts/terraform/pubsub
        Playbook will run terraform scripts to create resources in GCP. 

    +	Example of use:
    `sudo -E -u edh_automation ansible-playbook -v -i ansible_hosts_edh/dryrunops_bastion pubsub/playbook_pubsub_subscription_push_deployment.yml --private-key=/etc/security/ocb_ssh_automation/ocb_edh_automation_dryrunops_key --skip-tags=minimalChecking -u edh_automation -e GCP_TOPIC_NAME=topicdemoocb001 -e TOPOLOGY_REGION=europe-west1 -e GCP_TOPICSUBPUSH_NAME=topicdemoocb001subpush001 -e GCP_TOPICSUBPUSH_LABEL_KEY=topicdemoocb001subpush001 -e GCP_TOPICSUBPUSH_LABEL_VALUE=topicdemoocb001subpush001 -e GCP_TOPICSUBPUSH_MESSAGE_RETENTION_SEC=1200 -e GCP_TOPICSUBPUSH_RETAIL_ACKED_MESSAGES=true -e GCP_TOPICSUBPUSH_ACK_DEADLINE_SECONDS=20 -e GCP_TOPICSUBPUSH_ENDPOINT_URL=https://nodejs-docs-samples-demo-lxo2mboyia-nw.a.run.app -e GCP_TOPICSUBPUSH_TTL_SEC=300000 -e GCP_TOPICSUBPUSH_MIN_BACKOFF_SEC=10 -e GCP_TOPICSUBPUSH_ENABLE_MESSAGE_ORDERING=false -e GCP_SERVICE_ACCOUNT=856533697179-compute@developer.gserviceaccount.com -e CHANNEL= --vault-password-file /etc/security/ocb_ssh_automation/vault/dryrunops_bastion_vault_pass`
<br />

+	**playbook_pubsub_test_pull_sub_consumer.yml**
        This playbook will generate a python script to consume messages from pub sub subscriber with pull delivery
        Python scripts are generated in /home/gcpadmin/scripts/python/pubsub
        A check is done at the end of the script to get the number of messages before and after consuming messages
        Playbook runs the python script

    +	Example of use:
    `sudo -E -u edh_automation ansible-playbook -v -i ansible_hosts_edh/dryrunops_bastion pubsub/playbook_pubsub_test_pull_sub_consumer.yml --private-key=/etc/security/ocb_ssh_automation/ocb_edh_automation_dryrunops_key -u edh_automation -e GCP_TOPICSUBPULL_NAME=topicdemoocb001subpull001 -e GCP_PROJECT_NAME=ocb-big-data-sandbox -e GCP_NUMBER_SEC_SUBSCRIBER_LISTEN_MESSAGES=50 -e refreshPeriod=180 -e CHANNEL= --vault-password-file /etc/security/ocb_ssh_automation/vault/dryrunops_bastion_vault_pass`
<br />

+	**playbook_pubsub_test_pull_sub_producer.yml**
        This playbook will generate a python script to produce messages in pub sub topic
        Python scripts are generated in /home/gcpadmin/scripts/python/pubsub
        A check is done at the end of the script to get the number of messages before and after producing messages
        Playbook runs the python script

    +	Example of use:
    `sudo -E -u edh_automation ansible-playbook -vv -i ansible_hosts_edh/dryrunops_bastion pubsub/playbook_pubsub_test_pull_sub_producer.yml --private-key=/etc/security/ocb_ssh_automation/ocb_edh_automation_dryrunops_key -u edh_automation -e GCP_TOPIC_NAME=topicdemoocb001 -e GCP_PROJECT_NAME=ocb-big-data-sandbox -e GCP_TOPICSUBPULL_NAME=topicdemoocb001subpull001 -e NUM_MESSAGES=1000 -e refreshPeriod=180 -e CHANNEL= --vault-password-file /etc/security/ocb_ssh_automation/vault/dryrunops_bastion_vault_pass`
<br />

+	**playbook_pubsub_test_push_with_cloud_run.yml**
        This playbook will instantiate a cloud run resource with start a node.js server.
        The aim is to validate push delivery thanks to the end point url
        Terraform scripts are generated in /home/gcpadmin/scripts/terraform/cloudrun
        Playbook will run terraform scripts to create resources in GCP. 

    +	Example of use:
    `sudo -E -u edh_automation ansible-playbook -v -i ansible_hosts_edh/dryrunops_bastion pubsub/playbook_pubsub_test_push_with_cloud_run.yml --private-key=/etc/security/ocb_ssh_automation/ocb_edh_automation_dryrunops_key --skip-tags=minimalChecking -u edh_automation -e GCP_CLOUDRUN_SERVICE_NAME=nodejs-docs-samples-demo -e GCP_CLOUDRUN_IMAGE_NAME=eu.gcr.io/ocb-big-data-sandbox/nodejs-docs-samples -e 'GCP_CLOUDRUN_SERVICE_LOCATION="europe-west2"' -e GCP_SERVICE_ACCOUNT=856533697179-compute@developer.gserviceaccount.com -e CHANNEL= --vault-password-file /etc/security/ocb_ssh_automation/vault/dryrunops_bastion_vault_pass`
<br />

+	**playbook_pubsub_topic_deployment.yml**
        This playbook will instantiate a pubsub topic resource.
        Terraform scripts are generated in /home/gcpadmin/scripts/terraform/pubsub
        Playbook will run terraform scripts to create resources in GCP. 

    +	Example of use:
    `sudo -E -u edh_automation ansible-playbook -v -i ansible_hosts_edh/dryrunops_bastion pubsub/playbook_pubsub_topic_deployment.yml --private-key=/etc/security/ocb_ssh_automation/ocb_edh_automation_dryrunops_key --skip-tags=minimalChecking -u edh_automation -e GCP_TOPIC_NAME=topicdemoocb001 -e 'ALLOWED_PERSISTENCE_REGIONS="europe-west1","europe-west2","europe-west3"' -e GCP_KMS_STATUS= -e CHANNEL= --vault-password-file /etc/security/ocb_ssh_automation/vault/dryrunops_bastion_vault_pass`


