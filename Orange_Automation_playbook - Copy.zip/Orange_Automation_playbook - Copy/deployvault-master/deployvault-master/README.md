# deployvault

## Servers vault
`ansible-playbook -i ../ansible_hosts/fe_edhv2_kafka_external/ deployVault.yml --ask-vault-pass`

## Unseal a cluster
`ansible-playbook -i ../ansible_hosts/fe_edhv2_kafka_external/ deployVault.yml --tags unseal --ask-vault-pass`

## Client side
To deploy a consul template CLIENT_KEY_PEM (works with grafana, nginx, cockroach and kafka)
`ansible-playbook -i ../ansible_hosts/fe_winit_proj/ deployVault.yml --tags client -l grafana --ask-vault-pass`

For test on kafka
`ansible-playbook -i ../ansible_hosts/fe_winit_prod_external/ deployVault.yml --tags client -l kafka --ask-vault-pass`


