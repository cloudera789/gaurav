## Version 1.1.1   08/02/2024 - Saida AOUAQ ###
- Autorized ssh runner public key in svc_ansible_admin derectory
- import password.yml in playbook template
- Add pre_task GET SSH Public Runner
- Add ANSIBLE_FORCE_COLOR=true

     

## Version 1.1.0   07/02/2024 - Saida AOUAQ ###

- Optimisation vault - read passwords and save him in the fact ansible 
- Update template inventory windows
- fix variable token artifactory
- fix group administrators for svc-ansible-admin,OBS-svc-inventory, svc-cyberark-admin
- delete inventory_script
- Fix reboot vm windows 

## Version 1.0.0 le  06/02/2024 - Saida AOUAQ ###

- Update requirements URLS (ocbmca to onems-tooling)
- Filter get password by group 
- Update README
- Update VAULT, Migrating to ID_TOKENS
- Update Module terraform URL  
