Template deploy vms vapps
==========================

This template that are limited to the execution on Service Zone of Customer project for: 
- Creating, update, and delete vms/vapps
- Generate Inventory ansible.


Version:
=========

```bash
 version=1.0.0
 git clone $version https://sourcehub.orange-business.com/onems-tooling/cav-templates/customer-service-zone-create-vms-vapps.git
   
```
Template Dependencies
=======================
This template has the  dependencies [Customer tree structure gitlab](https://espace.agir.orange.com/display/ONEMSPROGRAM/3+-+Customer+Git+tree+structure),  [Inventory template](https://sourcehub.orange-business.com/onems-tooling/templates/inventory-template.git), [Vault tree strecture](https://collaboration.factory.orange-business.com/display/TASKFORCEMIGRATION/1+-+Customer+Vault+tree+structure)

[vapp module](https://sourcehub.orange-business.com/onems-tooling/terraform-modules/vcd_vapp), [vm module](https://sourcehub.orange-business.com/onems-tooling/terraform-modules/vcd_vm) and [ list of roles - postconf].


Without this tree gitlab strucrture and vault tree, this template doesn't work.

Compatibility
========================

|     Name                    |  version      |
|-----------------------------|---------------|
|  Terraform                  | 1.3           |
|  VCD                        | >= 3.10.0     | 
|  VAULT                      | 1.13          | 
|  Ansible                    | >=2.13        |

Variables_Terraform:
====================
  VMs:
  ================

|   Name                          | Require        | Description
|---------------------------------|----------------|----------------
| HOSTNAME                        |YES             | Machine name 
| ESPACE_VAULT                    |NO              | Your password storage in vault space
| ORGANIZATION                    |NO              | Name organisation in CAV
| VAPP                            |YES             | Your vapp name
| CATALOGUE_NAME                  |YES             | Your catalague name in CAV
| TEMPLATE                        |YES             | Template name
| VDC_NAME                        |YES             | VDC name
| CPU_QUANTITY                    |YES             | The number of CPU
| RAM_QUANTITY                    |YES             | The number of RAM
| STORAGE_POLICY                  |YES             | Storage Policy (silver or gold)
| DISK_BUS                        |YES             | Default "paravirtual"
| DISK1                           |NO              | Additional disk 1
| DISK2                           |NO              | Additional disk 2
| DISK3                           |NO              | Additional disk 3
| VLAN                            |YES             | Vlan name type list
| METADATA                        |NO              | List of metadata entry (check vms.yml inputs example and variables.tf for more informations)

 Vapps:
 ==========
 

|   Name                          | Require        | Description
|---------------------------------|----------------|----------------
| ORG_NAME                        |YES             | tenant id 
| VDC_NAME                        |YES             | vdc name
| VAPP_NAME                       |YES             | vapp name
| ORG_NETWORK                     |YES             | network name


List of roles - postconf
==========================
 - ob_setdns                        
 - ob_users
 - ob_os_licence                            
 - ob_lin_postconf                
 - ob_hardening          
 - ob_telegraf         
 - ob_trendmicro      
 - ob_reboot         
 - ob_scan_lynis
         