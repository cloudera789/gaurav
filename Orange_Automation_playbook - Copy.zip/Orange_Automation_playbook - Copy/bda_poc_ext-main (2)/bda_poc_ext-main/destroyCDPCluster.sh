# destroy cluster
if [ $# -eq 0 ]
  then
    echo "No arguments supplied"
    exit 1
fi

CLUSTER_NAME=$1
ansible -i bda_inventories/$CLUSTER_NAME vad -b -m shell -a "systemctl stop cloudera-scm-server"
ansible -i bda_inventories/$CLUSTER_NAME cdh_servers -b -m shell -a "systemctl stop cloudera-scm-agent"
#ansible -i bda_inventories/$CLUSTER_NAME cdh_servers -b -m shell -a "pkill -f supervisord"

ansible -i bda_inventories/$CLUSTER_NAME cdh_servers -b -m shell -a "apt purge cloudera-manager-agent cloudera-manager-daemons cloudera-manager-server -y ; rm -rf /etc/cloudera-scm-agent /var/lib/cloudera-scm-agent/ /var/run/cloudera-scm-agent /etc/cloudera-scm-server/ /etc/cloudera* /var/lib/cloudera-* /var/run/cloudera-scm-* /dfs/nn/* /dfs/jn/* /dfs/dn/* /var/lib/zookeeper/* /var/local/kafka/ /opt/cloudera/cm-agent ;systemctl daemon-reload"
ansible -i bda_inventories/$CLUSTER_NAME mno -m shell -a 'rm -rf /hadoop/hdfs/' -b
ansible -i bda_inventories/$CLUSTER_NAME dno -m shell -a 'rm -rf /grid/' -b
ansible -i bda_inventories/$CLUSTER_NAME nma -m shell -a 'rm -rf /grid/' -b


ansible -i bda_inventories/$CLUSTER_NAME bdd[0] -m shell -a 'echo "
amon
das
hue
metastore
nav
navms
oozie
ranger
rman
scm
sentry
rangerkms" >  /tmp/purge_databases;for x in `cat /tmp/purge_databases` ; do mysql -u root -padmin -e "drop  database $x" ; done' -b


