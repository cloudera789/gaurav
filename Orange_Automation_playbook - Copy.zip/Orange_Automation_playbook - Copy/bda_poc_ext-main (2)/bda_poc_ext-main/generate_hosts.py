import json
import sys

def generate_hosts_file(input_file, output_file, prefix):
    with open(input_file) as f:
        data = json.load(f)

    out_vm = data["out_vm"]["value"]
    hosts = {}

    for vm_name, vm_data in out_vm.items():
        if vm_name.startswith(f"{prefix}-"):
            vm_ip = vm_data["vm_ip"][0]
            vm_type = vm_name.split("-")[1][:3]

            if vm_type not in hosts:
                hosts[vm_type] = []

            hosts[vm_type].append({
                "name": vm_name,
                "ip": vm_ip
            })

    # Add the special groups to extra_hosts with empty lists as values
    extra_hosts = {
        "vad": [],
        "ves": [],
        "vhm": [],
        "bdd": [],
        "ipa_master": [],
        "ipa_replica": [],
        "kafka": [],
        "kafkamanager": [],
        "hive": [],
        "ranger": [],
        "sspr": [],  # New heading: [sspr]
        #"reverse_proxy": [],  # New heading: [reverse_proxy]
    }

    # Add VMs to the special groups based on their presence in the out_vm data
    for group, hosts_list in extra_hosts.items():
        if group == "bdd":
            for i in range(1, 3):
                vm_name = f"{prefix}-vhm{i:03d}"
                if vm_name in out_vm:
                    extra_hosts[group].append(vm_name)
        elif group == "ipa_master":
            vm_name = f"{prefix}-vkb001"
            if vm_name in out_vm:
                extra_hosts[group].append(vm_name)
                extra_hosts["sspr"].append(vm_name)  # Add VM to [sspr] if present
        elif group == "ipa_replica":
            vm_name = f"{prefix}-vkb002"
            if vm_name in out_vm:
                extra_hosts[group].append(vm_name)
        elif group == "kafka":
            for i in range(1, 3):
                vm_name = f"{prefix}-vhm{i:03d}"
                if vm_name in out_vm:
                    extra_hosts[group].append(vm_name)
        elif group == "kafkamanager":
            vm_name = f"{prefix}-vhm001"
            if vm_name in out_vm:
                extra_hosts[group].append(vm_name)
        elif group == "hive":
            for i in range(1, 3):
                vm_name = f"{prefix}-vhm{i:03d}"
                if vm_name in out_vm:
                    extra_hosts[group].append(vm_name)
        elif group == "ranger":
            vm_name = f"{prefix}-vhm003"
            if vm_name in out_vm:
                extra_hosts[group].append(vm_name)
        # elif group == "reverse_proxy":
        #     vm_name = f"{prefix}-vrp001"
        #     if vm_name in out_vm:
        #         extra_hosts["reverse_proxy"].append(vm_name)  # Add VM to [reverse_proxy] if present

    # Remove the special groups from extra_hosts if they already exist in hosts
    for group in ["vad", "ves", "vhm"]:
        if group in hosts:
            del extra_hosts[group]

    children = {
        "dno:vars": [],
        "adm:children": ["vad"],
        "mno:children": ["vhm"],
        "dno:children": ["vhm"],
        "edge:children": ["ves"],
        "hue_server:children": ["ves"],
        "atlas:children": [],
        "oozie:children": ["vhm"],
        "knox:children": ["ves"],
        "nifi:children": [],
        "reverse_proxy:children": [],
        "utility_servers:children": ["mno", "bdd"],
        "cdh_servers:children": ["adm", "mno", "dno", "edge", "nifi", "kafka", "hive"],
        "ipa_client:children": ["cdh_servers", "bdd"],
        "hive_client:children": ["hive", "edge", "kafka", "nifi"],
    }

    with open(output_file, "w") as f:
        for vm_type, vm_list in hosts.items():
            f.write(f"[{vm_type}]\n")

            for vm in vm_list:
                f.write(f"{vm['name']} ansible_host={vm['ip']}")

                if vm_type == "vhm":
                    f.write(f" host_template=HostTemplate-Master{vm_list.index(vm) + 1}-Full")
                elif vm_type == "ves":
                    f.write(" host_template=HostTemplate-Edge role_ref_names=HDFS-HTTPFS-1")

                f.write("\n")

            f.write("\n")

        for group, hosts_list in extra_hosts.items():
            f.write(f"[{group}]\n")

            # If the group is one of the special groups and it has no members, write an empty line
            if group in ["vad", "ves", "vhm"] and not hosts_list:
                f.write("\n")

            for host in hosts_list:
                f.write(f"{host}\n")

            f.write("\n")

        f.write("#--------------------------------------------------\n")
        f.write("# children\n")
        f.write("#--------------------------------------------------\n")

        for group, children_list in children.items():
            f.write(f"[{group}]\n")

            for child in children_list:
                f.write(f"{child}\n")

            f.write("\n")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python generate_hosts.py <input_file> <output_file> <prefix>")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]
    prefix = sys.argv[3]

    generate_hosts_file(input_file, output_file, prefix)

