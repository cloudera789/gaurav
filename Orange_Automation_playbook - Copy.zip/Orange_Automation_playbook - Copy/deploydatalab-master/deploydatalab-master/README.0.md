deploy Spar Cluster
================
This playbook deploys a Spark cluster with 3 workers, one master node (edge) and one ipa master.
It installs
  - 3 spark workers
  - 1 spark master
  - 1 edge with
    - upyterhubj
    - sparkmaster UI
    - sparkhistory UI
    - sparkhistorycurrent UI : current job on port 4040
  - 1 ipa witch manages jupyter access and DNS
    - Jupyterhub.data.<clustername>
    - sparkmaster.data.<clustername>
    - sparkhistory.data.<clustername>
    - sparkhistorycurrent.data.<clustername>

A jenkins job is available to build a cluster using Terraform : https://jenkins.bigdata.intraorange:8443/view/04%20CICD/job/deploySparkCluster/

Example Playbook
----------------
    - hosts: all
      roles:
        - role: deploySparkCluster



Author Information
------------------
jerome.petitjean at orange.com


