#? /bin/bash
#set -x

#git submodule add git@gitlab.tech.orange:engineeringbigdata/ansible_hosts.git hosts
path=`pwd`
if [ -e ".gitmodules" ]; then
        git submodule init
        git submodule update
        for currentModulePath in $(egrep -iR '.*path.*=' .gitmodules |  cut -d"=" -f2); do
		branch="master"
                echo "          *** Update $currentModulePath ***"
                cd "${currentModulePath}"
		subpath=`echo $currentModulePath |cut -d "/" -f 2`
		git checkout $branch
                git pull
                cd "$path"
        done
        #git commit -a -m"[UPD] Commit des sousmodules"
	#git push
fi

