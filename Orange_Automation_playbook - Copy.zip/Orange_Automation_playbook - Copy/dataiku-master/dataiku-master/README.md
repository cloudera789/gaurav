This project contains all materials to deploy Dataiku DSS solution on clusters.

DSS is installed on an edge host defined in the hosts inventory file into the [dss] group.


## Usage Eg

>> Prerequisites

-	Add the dss host under [dss] grpup in the  inventory file
-	Set the DSS properties under common >defaults > main file

ansible-playbook -i ../ansible_hosts/fe_ikas/ deployDSS.yml --private-key=<key> -u cloud -e DSS_VERSION=<x.y.z>

Or

ansible-playbook -vvv -i ../ansible_hosts/fe_ikas / deployDSS.yml --private-key=/var/lib/jenkins/.ssh/KeyPair-mrs-sec.pem  -u cloud -e REMOVE_EXISTING=true -e DSS_USER=a_dss  -e DSS_INSTALL_DIR="/dataiku/dss" -e REMOVE_EXISTING=true -e DSS_HTTPS_PORT=8843 -e DSS_VERSION=8.0.2


These main parameters are defined under common >defaults > main file


>> When REMOVE_EXISTING is set to TRUE the installation will remove the current Dss  DATADIR if  the path is unchaged.



The playbook tasks implement installation procedure steps describe in Dataiku official documentation:
   - https://doc.dataiku.com/dss/latest/installation/new_instance.html#manual-dependency-installation
   - https://doc.dataiku.com/dss/latest/installation/new_instance.html
   - https://doc.dataiku.com/dss/latest/hadoop/installation.html
   - https://doc.dataiku.com/dss/latest/hadoop/secure-clusters.html
   - https://doc.dataiku.com/dss/latest/installation/custom_install.html#configuring-https
