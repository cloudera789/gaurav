Elasticsearch
=============

Installation guide : https://plazza.orange.com/docs/DOC-1411368

Administration guide : https://plazza.orange.com/docs/DOC-1470147
