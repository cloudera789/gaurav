#!/bin/sh

DIR_ROOT="/apps/elasticsearch"
DIR_LIST="logs"

for dir in $DIR_LIST; do
  dir_path=$DIR_ROOT/$dir
  echo $dir_path
  if [ -d $dir_path ]; then
    #find $dir_path -type f -name "*\.log\.*" -mtime +7 -ls
    #find $dir_path -regextype sed -regex ".*\.[0-9][0-9][0-9][0-9]\-[0-9][0-9]\-[0-9][0-9]\.log*" -mtime +7 -ls
    #find $dir_path -regextype sed -regex ".*\.log\.gz.*" -mtime +7 -ls
    find $dir_path -regextype sed -regex ".*\.log\.gz.*" -mtime +7 | xargs -P 4 -n 20 rm -f
  fi
done

