#!/bin/bash
# Post mattermost notification on ci channel
# param: message to post

if [[ -z $1 ]]
then
   echo "Param MESSAGE is needed, please give it."
   echo "Usage : $0 &lt;MESSAGE&gt;"
   exit 1;
fi

if [[ -z $2 ]]
then
   echo "Param CHANNEL is needed, please give it."
   echo "Usage : $0 &lt;&gt;"
   exit 1;
fi

MESSAGE="$1"
CHANNEL="$2"
TIMEOUT_CURL=30
# sqeg56fqkjd7tjkn5xsis6we3c -> GitReviewCode
MATTERMOST_HOOK=https://mattermost.tech.orange/hooks/$CHANNEL
FULL_MESSAGE="[${JOB_NAME}] ${MESSAGE}"

curl -m ${TIMEOUT_CURL} -s -i -k -XPOST --data 'payload={"username":"Jenkins","text":"'"${FULL_MESSAGE}"'"}' ${MATTERMOST_HOOK}
curl -i -X POST -H "Content-Type: application/json" -d "{ \"text\": \"Hello,this is some text\nThis is more text. :tada:\"}" ${MATTERMOST_HOOK}

