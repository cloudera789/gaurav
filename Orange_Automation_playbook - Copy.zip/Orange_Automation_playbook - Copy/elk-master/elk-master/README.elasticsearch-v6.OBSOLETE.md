Elasticsearch
=============

__Architecture hints__

- 1 Gb de RAM pour 32 Gb de données

- Taille mini d'un noeud elasticsearch

4 vCPU / 8 GB RAM
JVM size de elasticsearch = la moitié de la RAM du noeud, soit 4 GB si 8 GB RAM

- Réplication	

Avec 3 noeuds, mettre la réplication à 1 pour que le cluster reste up même si un noeud tombe
=> 1 shard primaire + 1 réplica

(sur EDH, la replication était à 2 ; 1 noeud est tombé ; plus rien ne rentrait)

Update replica
```
curl -XPUT -H 'Content-Type: application/json' 'http://127.0.0.1:9200/*/_settings' -d '
{
	"index" : {
		"number_of_replicas" : 1
	}
}'; echo
```

- Export des settings elasticsearch

curl -XGET -H 'Content-Type: application/json' 'http://127.0.0.1:9200/*/_settings'

- Liens utiles :

https://www.elastic.co/guide/en/elasticsearch/guide/current/replica-shards.html



__Case 1 : mutualized cluster (1 ELK cluster shared by several hadoop clusters - ex : EDH)__

- servers prerequisites :
```
        /etc/yum.repos.d
            centos7.repo :
                [centos7]
                baseurl=http://fehusvcp-vbt001/mirror/centos/7/os/x86_64
                enabled=True
                gpgcheck=False
                name=CentsOS 7.5
            
            centos7-updates.repo :
                [centos7-updates]
                name=CentsOS 7.5 Updates
                baseurl=http://fehusvcp-vbt001/mirror/centos/7/updates/x86_64
                enabled=True
```
        
- JDK installed in /usr/jdk64 
        
=> Cf. playbook :
```
ansible-playbook -vvv -i hosts/fca_elk_eng/ --private-key=/var/lib/jenkins/.ssh/operations-bdr.key -u admin deployJDK.yml --tags=jdk --list-tasks --list-hosts
``` 
    
- /etc/hosts : 
```
        FCA :
            + 10.238.117.18   obitsvcp-vbt001
            
            + 10.238.117.19   obitsvcp-vel001
            + 10.238.117.20   obitsvcp-vel002
            + 10.238.117.21   obitsvcp-vel003
        FE :
            + 10.71.4.197     fehusvcp-vbt001 fehusvcp-vbt001.novalocal     
```
    
- SSH connectivity to all nodes

- dedicated file systems

- EDH FCA
```
            /apps/elasticsearch/logs (idéalement FS dédié - 10 Gb)
            /apps/elasticsearch/data (idéalement FS dédié - 800 Gb sur EDH)
            =>
                  --- Volume group ---
                  VG Name               vg_elkdata
                  System ID
                  Format                lvm2
                  Metadata Areas        1
                  Metadata Sequence No  2
                  VG Access             read/write
                  VG Status             resizable
                  MAX LV                0
                  Cur LV                1
                  Open LV               1
                  Max PV                0
                  Cur PV                1
                  Act PV                1
                  VG Size               <800.00 GiB
                  PE Size               4.00 MiB
                  Total PE              204799
                  Alloc PE / Size       204799 / <800.00 GiB
                  Free  PE / Size       0 / 0
                  VG UUID               3mcTy8-Sc5U-0Ht3-EO4C-dBWW-DmDq-EgwY12

                  --- Volume group ---
                  VG Name               vg_elklogs
                  System ID
                  Format                lvm2
                  Metadata Areas        1
                  Metadata Sequence No  2
                  VG Access             read/write
                  VG Status             resizable
                  MAX LV                0
                  Cur LV                1
                  Open LV               1
                  Max PV                0
                  Cur PV                1
                  Act PV                1
                  VG Size               <10.00 GiB
                  PE Size               4.00 MiB
                  Total PE              2559
                  Alloc PE / Size       2559 / <10.00 GiB
                  Free  PE / Size       0 / 0
                  VG UUID               azGm88-881E-2VvB-OBnc-o64r-hP4o-rkQj6s
```

- FE (d2 flavor)

Create a dedicated file system in vg_extra volume group => Cf. playbook (lvm tag)

/!\ Check existence of this volume group ; if not present, contact Big Data ENG team that will have to find an alternative





__Case 2 : embedded ELK (ELK cluster is installed on the hosts of the customer cluster)__

__pre-requisites__

On each ELK node, /etc/hosts file must contain the entries of all elastic and kibana nodes

Check :
    cd /etc/sudoers.d
    ll
    vim 10_admin
    %admin ALL=(ALL) NOPASSWD: ALL

__ansible_hosts/hosts__

- set elasticnode tag
- set kibananode tag
- set cronelkindex tag

- ex (edh : 
```
        [el001]
        obitelkp-vel001 ansible_host=10.238.113.22 elasticnode=true cronelkindex=true kibananode=true

        [el002]
        obitelkp-vel002 ansible_host=10.238.113.23 elasticnode=true

        [el003]
        obitelkp-vel003 ansible_host=10.238.113.24 elasticnode=true

        [el004]
        obitelkp-vel004 ansible_host=10.238.113.25 elasticnode=true

        [el005]
        obitelkp-vel005 ansible_host=10.238.113.26 elasticnode=true

        [el006]
        obitelkp-vel006 ansible_host=10.238.113.27 elasticnode=true

        [mno:children]
        el001
        el002
        el003
        el004
        el005
        el006
        
        [edge:children]
        el001
        el002
        el003
        el004
        el005
        el006

```
    
- ex (talend) : 
```
        [mno]
        talenhdp-vhm001 ansible_host=10.102.16.4 IFCFG_ETH="ifcfg-eth0" elasticnode=true namenode=true cronelkindex=true
        talenhdp-vhm002 ansible_host=10.102.16.5 IFCFG_ETH="ifcfg-eth0" elasticnode=true namenode=true
        talenhdp-vhm003 ansible_host=10.102.16.6 IFCFG_ETH="ifcfg-eth0" elasticnode=true

        [edge]
        talenhdp-ves001 ansible_host=10.102.16.11 kibananode=true
```

- ex (cardif) : 
```
        [mno]
        cardaieu-vhm001 ansible_host=10.102.13.56 IFCFG_ETH="ifcfg-ens5" elasticnode=true namenode=true cronelkindex=true
        cardaieu-vhm002 ansible_host=10.102.13.110 IFCFG_ETH="ifcfg-ens5" elasticnode=true namenode=true
        cardaieu-vhm003 ansible_host=10.102.13.78 IFCFG_ETH="ifcfg-ens5" elasticnode=true kibananode=true
```

- ex (OBank prod) : 
```
        [mno]
        obdlkprd-vhm001 ansible_host=10.249.112.23 flavor_d2=d2_2x elasticnode=true cronelkindex=true
        obdlkprd-vhm002 ansible_host=10.249.112.24 flavor_d2=d2_2x elasticnode=true
        obdlkprd-vhm003 ansible_host=10.249.112.25 flavor_d2=d2_2x elasticnode=true kibananode=true
```

- ex (OBank lab) : 
```
        [mno]
        obdlklab-vhm001 ansible_host=10.249.113.130 IFCFG_ETH="ifcfg-eth0" elasticnode=true kibananode=true cronelkindex=true
        obdlklab-vhm002 ansible_host=10.249.113.131 IFCFG_ETH="ifcfg-eth0" elasticnode=true
```
    
        
__```ansible_hosts/<cluster>/group_vars/all/specific```__
    
Examples :

- EDH
```
        DOMAIN1: "data"
        DOMAIN2: "edh"

        SSH_USER: admin
        SSH_KEY: "operations-bdr.key"
        SSH_DIR: "/var/lib/jenkins/.ssh"

        ELASTIC_SERVER: "obitelkp-vel001"
        ELASTIC_SERVER_IP: "10.238.113.22"

        ELK_CLUSTER_NAME: "EDH_Monitoring_v2"
        ELK_CLUSTER_NODES: '"obitelkp-vel001","obitelkp-vel002","obitelkp-vel003","obitelkp-vel004","obitelkp-vel005","obitelkp-vel006"'
        ELASTIC_TARBALL: "elasticsearch-6.5.1.tar.gz"
        ELASTIC_DIR: "elasticsearch-6.5.1"
        KIBANA_TARBALL: "kibana-6.5.1-linux-x86_64.tar.gz"
        KIBANA_DIR: "kibana-6.5.1-linux-x86_64"

        JVM_SIZE: 22                                    <- less than the half of the total memory
```
    
- TALEND
```
        ELK_CLUSTER_NAME: "TALENHDP_Monitoring"
        ELK_CLUSTER_NODES: '"talenhdp-vhm001","talenhdp-vhm002","talenhdp-vhm003"'
        JVM_SIZE: 16                                    <- less than the half of the total memory
```

- CARDIF_PROD
```
        ELK_CLUSTER_NAME: "CARDIFPROD_Monitoring"
        ELK_CLUSTER_NODES: '"cardaieu-vhm001","cardaieu-vhm002","cardaieu-vhm003"'
        JVM_SIZE: 16                                    <- less than the half of the total memory
```

- OBAnk prod
```
ELK_CLUSTER_NAME: "OBANK_PROD_Monitoring"
ELK_CLUSTER_NODES: '"obdlkprd-vhm001","obdlkprd-vhm002","obdlkprd-vhm003"'
JVM_SIZE: 8
```

- OBAnk lab
```
ELK_CLUSTER_NAME: "OBANK_LAB_Monitoring"
ELK_CLUSTER_NODES: '"obdlklab-vhm001","obdlklab-vhm002"
JVM_SIZE: 4
```

        
__Ansible playbooks__

/!\ elasticsearch.yml & kibana.yml


- 1 : create the dedicated filesystems for elasticsearch

- 2 : create the elasticsearch cluster node by node

- 3 : install the kibana portal

- 4 : set the retention delays

- 5 : create the first elastic index manually

- 6 : checking


Samples :

- Edh : 
```
    Elasticsearch :
            vel001 
                ansible-playbook -i ../ansible_hosts_edh/fca_elk_prod elasticsearch.yml  --private-key=/var/lib/jenkins/.ssh/operations-bdr.key -u admin --skip-tags=lvm -e ELK_INDEX_NAME=edhprod -l obitelkp-vel001
            vel002 
                ansible-playbook -i ../ansible_hosts_edh/fca_elk_prod elasticsearch.yml  --private-key=/var/lib/jenkins/.ssh/operations-bdr.key -u admin --skip-tags=lvm -e ELK_INDEX_NAME=edhprod -l obitelkp-vel002
            vel003 
                ansible-playbook -i ../ansible_hosts_edh/fca_elk_prod elasticsearch.yml  --private-key=/var/lib/jenkins/.ssh/operations-bdr.key -u admin --skip-tags=lvm -e ELK_INDEX_NAME=edhprod -l obitelkp-vel003
            vel004 
                ansible-playbook -i ../ansible_hosts_edh/fca_elk_prod elasticsearch.yml  --private-key=/var/lib/jenkins/.ssh/operations-bdr.key -u admin --skip-tags=lvm -e ELK_INDEX_NAME=edhprod -l obitelkp-vel004
            vel005 
                ansible-playbook -i ../ansible_hosts_edh/fca_elk_prod elasticsearch.yml  --private-key=/var/lib/jenkins/.ssh/operations-bdr.key -u admin --skip-tags=lvm -e ELK_INDEX_NAME=edhprod -l obitelkp-vel005
            vel006 
                ansible-playbook -i ../ansible_hosts_edh/fca_elk_prod elasticsearch.yml  --private-key=/var/lib/jenkins/.ssh/operations-bdr.key -u admin --skip-tags=lvm -e ELK_INDEX_NAME=edhprod -l obitelkp-vel006

    kibana :
        /!\ vel001
                ansible-playbook -i ../ansible_hosts_edh/fca_elk_prod kibana.yml  --private-key=/var/lib/jenkins/.ssh/operations-bdr.key -u admin --skip-tags=lvm -e ELASTIC_SERVER=obitelkp-vel001 -l obitelkp-vel001
```

- Talend :

```
    cd /opt/ansible/Tools (or whatever path)
    
    LVM :
            vhm001 :
                ansible-playbook -i ../ansible_hosts/fe_talend elasticsearch.yml  --private-key=~/.ssh/TALEND_BG.pem -u bigdata_user --tags=lvm -e ELK_INDEX_NAME=talend -l talenhdp-vhm001 --list-tasks --list-hosts
            vhm002 :
                ansible-playbook -i ../ansible_hosts/fe_talend elasticsearch.yml  --private-key=~/.ssh/TALEND_BG.pem -u bigdata_user --tags=lvm -e ELK_INDEX_NAME=talend -l talenhdp-vhm002 --list-tasks --list-hosts
            vhm003 :
                ansible-playbook -i ../ansible_hosts/fe_talend elasticsearch.yml  --private-key=~/.ssh/TALEND_BG.pem -u bigdata_user --tags=lvm -e ELK_INDEX_NAME=talend -l talenhdp-vhm003 --list-tasks --list-hosts
            
    Elasticsearch :
            vhm001 :
                ansible-playbook -i ../ansible_hosts/fe_talend elasticsearch.yml  --private-key=~/.ssh/TALEND_BG.pem -u bigdata_user --skip-tags=lvm -e ELK_INDEX_NAME=talend -l talenhdp-vhm001 --list-tasks --list-hosts
            vhm002 :
                ansible-playbook -i ../ansible_hosts/fe_talend elasticsearch.yml  --private-key=~/.ssh/TALEND_BG.pem -u bigdata_user --skip-tags=lvm -e ELK_INDEX_NAME=talend -l talenhdp-vhm002 --list-tasks --list-hosts
            vhm003 :
                ansible-playbook -i ../ansible_hosts/fe_talend elasticsearch.yml  --private-key=~/.ssh/TALEND_BG.pem -u bigdata_user --skip-tags=lvm -e ELK_INDEX_NAME=talend -l talenhdp-vhm003 --list-tasks --list-hosts

    kibana :
        /!\ ves001 : 
            ansible-playbook -i ../ansible_hosts/fe_talend kibana.yml  --private-key=~/.ssh/TALEND_BG.pem -u bigdata_user -e ELASTIC_SERVER=talenhdp-vhm001 -l talenhdp-ves001 --list-tasks --list-hosts
```

- Cardif :

```
    LVM :
            vhm001 :
                ansible-playbook -i ../ansible_hosts/fe_cardif elasticsearch.yml  --private-key=~/.ssh/CARDAIEU_KEY_BD.pem -u bigdata_user --tags=lvm -e ELK_INDEX_NAME=cardaieu -l cardaieu-vhm001 --list-tasks --list-hosts
            vhm002 :
                ansible-playbook -i ../ansible_hosts/fe_cardif elasticsearch.yml  --private-key=~/.ssh/CARDAIEU_KEY_BD.pem -u bigdata_user --tags=lvm -e ELK_INDEX_NAME=cardaieu -l cardaieu-vhm002 --list-tasks --list-hosts
            vhm003 :
                ansible-playbook -i ../ansible_hosts/fe_cardif elasticsearch.yml  --private-key=~/.ssh/CARDAIEU_KEY_BD.pem -u bigdata_user --tags=lvm -e ELK_INDEX_NAME=cardaieu -l cardaieu-vhm003 --list-tasks --list-hosts
            
    Elasticsearch :
            vhm001 :
                ansible-playbook -i ../ansible_hosts/fe_cardif elasticsearch.yml  --private-key=~/.ssh/CARDAIEU_KEY_BD.pem -u bigdata_user --skip-tags=lvm -e ELK_INDEX_NAME=cardaieu -l cardaieu-vhm001 --list-tasks --list-hosts
            vhm002 :
                ansible-playbook -i ../ansible_hosts/fe_cardif elasticsearch.yml  --private-key=~/.ssh/CARDAIEU_KEY_BD.pem -u bigdata_user --skip-tags=lvm -e ELK_INDEX_NAME=cardaieu -l cardaieu-vhm002 --list-tasks --list-hosts
            vhm003 :
                ansible-playbook -i ../ansible_hosts/fe_cardif elasticsearch.yml  --private-key=~/.ssh/CARDAIEU_KEY_BD.pemm -u bigdata_user --skip-tags=lvm -e ELK_INDEX_NAME=cardaieu -l cardaieu-vhm003 --list-tasks --list-hosts

    kibana :
        /!\ vhm003 : 
            ansible-playbook -i ../ansible_hosts/fe_cardif kibana.yml  --private-key=~/.ssh/CARDAIEU_KEY_BD.pem -u bigdata_user -e ELASTIC_SERVER=cardaieu-vhm001 -l cardaieu-vhm003 --list-tasks --list-hosts
```

- OBank prod :

```    
    LVM :
            vhm001 :
                ansible-playbook -i ../ansible_hosts/fe_obkprod elasticsearch.yml  --private-key=~/.ssh/OBANK.pem -u bigdata_user --tags=lvm -e ELK_INDEX_NAME=obankprod -l obdlkprd-vhm001 --list-tasks --list-hosts
            vhm002 :
                ansible-playbook -i ../ansible_hosts/fe_obkprod elasticsearch.yml  --private-key=~/.ssh/OBANK.pem -u bigdata_user --tags=lvm -e ELK_INDEX_NAME=obankprod -l obdlkprd-vhm002 --list-tasks --list-hosts
            vhm003 :
                ansible-playbook -i ../ansible_hosts/fe_obkprod elasticsearch.yml  --private-key=~/.ssh/OBANK.pem -u bigdata_user --tags=lvm -e ELK_INDEX_NAME=obankprod -l obdlkprd-vhm003 --list-tasks --list-hosts
            
    Elasticsearch :
            vhm001 :
                ansible-playbook -i ../ansible_hosts/fe_obkprod elasticsearch.yml  --private-key=~/.ssh/OBANK.pem -u bigdata_user --skip-tags=lvm -e ELK_INDEX_NAME=obankprod -l obdlkprd-vhm001 --list-tasks --list-hosts
            vhm002 :
                ansible-playbook -i ../ansible_hosts/fe_obkprod elasticsearch.yml  --private-key=~/.ssh/OBANK.pem -u bigdata_user --skip-tags=lvm -e ELK_INDEX_NAME=obankprod -l obdlkprd-vhm002 --list-tasks --list-hosts
            vhm003 :
                ansible-playbook -i ../ansible_hosts/fe_obkprod elasticsearch.yml  --private-key=~/.ssh/OBANK.pem -u bigdata_user --skip-tags=lvm -e ELK_INDEX_NAME=obankprod -l obdlkprd-vhm003 --list-tasks --list-hosts

    kibana :
        /!\ vhm003 : 
            ansible-playbook -i ../ansible_hosts/fe_obkprod kibana.yml  --private-key=~/.ssh/OBANK.pem -u bigdata_user -e ELASTIC_SERVER=obdlkprd-vhm001 -l obdlkprd-vhm003 --list-tasks --list-hosts
```    

- OBank lab :

```    
    LVM :
            vhm001 :
                ansible-playbook -i ../ansible_hosts/fe_obklab elasticsearch.yml  --private-key=~/.ssh/OBANK.pem -u bigdata_user --tags=lvm -e ELK_INDEX_NAME=obankprod -l obdlklab-vhm001 --list-tasks --list-hosts
            vhm002 :
                ansible-playbook -i ../ansible_hosts/fe_obklab elasticsearch.yml  --private-key=~/.ssh/OBANK.pem -u bigdata_user --tags=lvm -e ELK_INDEX_NAME=obankprod -l obdlklab-vhm002 --list-tasks --list-hosts

    Elasticsearch :
            vhm001 :
                ansible-playbook -i ../ansible_hosts/fe_obklab elasticsearch.yml  --private-key=~/.ssh/OBANK.pem -u bigdata_user --skip-tags=lvm -e ELK_INDEX_NAME=obankprod -l obdlklab-vhm001 --list-tasks --list-hosts
            vhm002 :
                ansible-playbook -i ../ansible_hosts/fe_obklab elasticsearch.yml  --private-key=~/.ssh/OBANK.pem -u bigdata_user --skip-tags=lvm -e ELK_INDEX_NAME=obankprod -l obdlklab-vhm002 --list-tasks --list-hosts

    kibana :
        /!\ vhm001 : 
            ansible-playbook -i ../ansible_hosts/fe_obklab kibana.yml  --private-key=~/.ssh/OBANK.pem -u bigdata_user -e ELASTIC_SERVER=obdlklab-vhm001 -l obdlkprd-vhm001 --list-tasks --list-hosts
```    

__Configure the elasticsearch cluster (if not already done by the playbook or when a node is added)__

Update /etc/elasticsearch/elasticsearch.yml file on all the nodes of the cluster :

```
discovery.zen.ping.unicast.hosts: ["<host1>,<host2>,..."]
```

Then, restart all nodes of the elastic cluster

    
__Checking elasticsearch__


```
http://10.238.117.19:9200/
=>
{
  "name" : "obitsvcp-vel001",
  "cluster_name" : "EDH_Monitoring_v2",
  "cluster_uuid" : "k0jo1XuGSmSYASgsOgkNhA",
  "version" : {
    "number" : "6.5.1",
    "build_flavor" : "default",
    "build_type" : "rpm",
    "build_hash" : "8c58350",
    "build_date" : "2018-11-16T02:22:42.182257Z",
    "build_snapshot" : false,
    "lucene_version" : "7.5.0",
    "minimum_wire_compatibility_version" : "5.6.0",
    "minimum_index_compatibility_version" : "5.0.0"
  },
  "tagline" : "You Know, for Search"
}
```



__Checking elasticsearch topology__

```
http://10.238.117.19:9200/_cat/nodes?v
=> (1 node)
        ip            heap.percent ram.percent cpu load_1m load_5m load_15m node.role master name
        10.238.117.19            2          56   0    0.00    0.01     0.05 mdi       *      obitsvcp-vel001    

=> (3 nodes)
        ip            heap.percent ram.percent cpu load_1m load_5m load_15m node.role master name
        10.238.117.19            2          56  20    0.30    0.10     0.07 mdi       -      obitsvcp-vel001
        10.238.117.20            2          52   2    0.28    0.23     0.13 mdi       *      obitsvcp-vel002
        10.238.117.21            2          52   3    0.17    0.17     0.14 mdi       -      obitsvcp-vel003    

=> cardif_prod :
        ip            heap.percent ram.percent cpu load_1m load_5m load_15m node.role master name
        10.102.13.110            3          99   0    1.10    0.92     0.68 mdi       -      cardaieu-vhm002
        10.102.13.56             4          98   0    0.59    0.54     0.60 mdi       *      cardaieu-vhm001
        10.102.13.78             2         100   4    1.20    0.54     0.42 mdi       -      cardaieu-vhm003
```

    
__Checking kibana portal__
    
```
http://10.238.117.19:5601/app/kibana
```


__Post-config__


- Adjust retention delays :

```
/usr/share/elasticsearch.ocb/create_purge_indexes.sh :
    RETENTION_LOGS=15
    RETENTION_METRICS=1095
```


- Add to crontab the indexes creation and purge (should be done by the playbook) :

```
# creates new daily indice and purge older one
0 22 * * * cd /usr/share/elasticsearch.ocb; ./create_purge_indexes.sh <index_prefix>
```

        
- Create the first index
    
```
cd /usr/share/elasticsearch.ocb; ./create_purge_indexes.sh <index_prefix>
```

    

__ANNEXES__
        
/!\ erreur si "bootstrap.memory_lock: true" dans /etc/el.../el..yml
        memory locking requested for elasticsearch process but memory is not locked

/!\ Quand ajout de noeuds, mettre à jour /etc/el.../el...yml :
    discovery.zen.ping.unicast.hosts: ["<host1>,<host2>,..."]


__XPack postconfig__

Rk : /etc/elasticsearch/elasticsearch.yml file is pre-configured with xpack
     Missing config (CA + certificates) is done by following playbooks

- 1rst node

```
ansible-playbook  -i ../ansible_hosts/fe_esaelkv7/ --private-key=$HOME/.ssh/KeyPair-mrs-sec.pem -u cloud  elasticsearch.yml \
--vault-password-file $HOME/vault_pass/fe_esaelkv7_vault_pass \
--tags=ssl \
-e ELK_INDEX_NAME=esaelkv7 \             ?????????????
-e FIRST_NODE=true \
-l esaelkv7-vel001 \
--skip-tags=skiprestart \
--list-tasks --list-hosts
```
=> fetch of bundle.zip (CA + certificates) file, locally, in /tmp/{{groups['elasticsearch'][0]}}.bundle.zip file

- Additional node

```
ansible-playbook  -i ../ansible_hosts/fe_esaelkv7/ --private-key=$HOME/.ssh/KeyPair-mrs-sec.pem -u cloud  elasticsearch.yml \
--vault-password-file $HOME/vault_pass/fe_esaelkv7_vault_pass \
--tags=ssl \
-e ELK_INDEX_NAME=esaelkv7 \               ??????????????
-e ADDITIONAL_NODE=true \
-l esaelkv7-vel002 \
--skip-tags=skiprestart \
--list-hosts --list-tasks
```

=> Copy of /tmp/{{groups['elasticsearch'][0]}}.bundle.zip in /etc/elasticsearch/certs/bundle.zip ; then unzip

/!\ If synchro pb, during build phase, /apps/elasticsearch/data/nodes directory can be removed ; then restart elasticsearch

