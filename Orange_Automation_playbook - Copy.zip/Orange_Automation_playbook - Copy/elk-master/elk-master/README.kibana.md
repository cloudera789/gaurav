Kibana
======

Cf. README.elasticsearch.md
