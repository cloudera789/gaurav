# Kibana vizualize & dashboards to be imported manually

## yarn_vizualization.json
### Description
    Kibana vizualize based on ocbmetrics index

## yarn_dashboards.json
### Description
    Kibana dashboards based on [yarn_vizualization] vizualized


## Process of Import
    To import: 
    1- Go on Kibana > Management > Saved Objects
    2- Click on Import ( Vizualize must be imported first)

    When Importing Vizualize, you may have to select the index patter to be used if unknown
    
     