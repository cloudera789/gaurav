# deployEzmeral

Ping the hosts
```
ansible all -i hosts/fe_sahil --private-key=~/.ssh/KeyPair-mrs-sec.pem -u cloud -m ping
```
This will deploy an HPE Ezmeral Controller Plane
```
ansible-playbook -vvv -i hosts deployEzmeral.yml -u cloud --private-key=key.pem
```
