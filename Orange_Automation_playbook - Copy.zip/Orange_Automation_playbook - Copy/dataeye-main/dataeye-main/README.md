# DataEye

Developed by Thuy Tu (INSA trainee, 2023)

## Installation

### Server

ansible-playbook -i vco4, deploy.yml -t server --list-tasks

### dataeye

ansible-playbook -i vco4, deploy.yml -t dataeye,install --list-tasks

## Upgrade dataeye

- without components install:
  `ansible-playbook -i vco4, deploy.yml -t dataeye,upgrade --skip-tags=install --list-tasks`
- with components reinstall
  `ansible-playbook -i vco4, deploy.yml -t dataeye,upgrade --list-tasks`

## Author

MDO -July, 2023
