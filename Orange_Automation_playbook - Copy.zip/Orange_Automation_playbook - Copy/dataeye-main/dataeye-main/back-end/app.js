const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const auth = require('./middleware/auth');
const ctrl = require('./controller');

app.use(express.json());
//app.use(bodyParser.json());
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content, Accept, Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
  next();
});

//get clusters and their status
app.get('/api/clusters',auth.authenticateToken,ctrl.getClusters);


//get services of a cluster
app.get('/api/clusters/:clustername/services',auth.authenticateToken, ctrl.getServices);

//get a list of external service of a cluster
app.get('/api/clusters/:clustername/externalservices',auth.authenticateToken,ctrl.getExternalServices);

//get a list of components of an external service 
app.get('/api/externalservices/:externalservice/components',auth.authenticateToken,ctrl.getComponentsExternalServices);

//get health of an external service of a cluster
app.get('/api/clusters/:clustername/externalservices/:externalservice',auth.authenticateToken,ctrl.getAnExternalService);

//get url, info of external services
app.get('/api/externalservices/info',auth.authenticateToken,ctrl.getInfoExternalServices);

// get component of a service
app.get('/api/clusters/:clustername/services/:servicename/components',auth.authenticateToken, ctrl.getComponents);

//get message of a component 
app.get('/api/clusters/:clustername/services/:servicename/messages',auth.authenticateToken, ctrl.getMsg);

app.get('/api/customers',auth.authenticateToken,ctrl.getCustomers);

app.post('/api/post/customer',auth.authenticateToken,auth.authorizeSuperUser,ctrl.addCustomer);

app.delete('/api/delete/customer/:customername/:roleId',auth.authenticateToken,auth.authorizeSuperUserForDel,ctrl.delCustomer);

app.patch('/api/patch/customer',auth.authenticateToken,auth.authorizeSuperUser,ctrl.updateCustomer);

//get all projects and their customers
app.get('/api/projects',auth.authenticateToken,ctrl.getProjects);

//get all clusters and their projects
app.get('/api/clusters/projects',auth.authenticateToken,ctrl.getClustersProjects);

app.post('/api/post/project',auth.authenticateToken,auth.authorizeSuperUser,ctrl.addProject);

app.patch('/api/patch/project',auth.authenticateToken,auth.authorizeSuperUser,ctrl.updateProject);

app.patch('/api/patch/realize',auth.authenticateToken,auth.authorizeSuperUser,ctrl.updateRealize);

app.delete('/api/delete/project/:projectname/:roleId',auth.authenticateToken,auth.authorizeSuperUserForDel,ctrl.delProject);

app.delete('/api/delete/ishosted/:roleId',auth.authenticateToken,auth.authorizeSuperUserForDel,ctrl.delIsHosted);

app.post('/api/post/ishosted',auth.authenticateToken,auth.authorizeSuperUser,ctrl.addIsHosted);

app.patch('/api/patch/clusters/:clustername/username',auth.authenticateToken,auth.authorizeSuperUser,ctrl.updateUsernameCluster);
app.patch('/api/patch/clusters/:clustername/pwd',auth.authenticateToken,auth.authorizeSuperUser,ctrl.updatePwdCluster);
app.patch('/api/patch/clusters/:clustername/adr',auth.authenticateToken,auth.authorizeSuperUser,ctrl.updateAdrCluster);
app.patch('/api/patch/clusters/:clustername/threshold',auth.authenticateToken,auth.authorizeSuperUser,ctrl.updateThresholdCluster);

app.post('/api/post/cluster',auth.authenticateToken,auth.authorizeSuperUser,ctrl.addCluster);
app.get('/api/types',auth.authenticateToken,ctrl.getTypes);
app.delete('/api/delete/cluster/:clustername/:roleId',auth.authenticateToken,auth.authorizeSuperUserForDel,ctrl.delCluster);

app.get('/api/history/clusters/:clustername',auth.authenticateToken,ctrl.getHistoryCluster);
app.get('/api/history/services/:clustername',auth.authenticateToken,ctrl.getHistoryServices);
app.post('/api/post/history/service',auth.authenticateToken,ctrl.addServiceHistory); //add history_service
app.post('/api/post/component',auth.authenticateToken,ctrl.addComponent); //add history_component
app.post('/api/post/externalcomponent',auth.authenticateToken,ctrl.addExternalComponent); //add history_external_component
app.get('/api/history/components/:clustername/:servicename',auth.authenticateToken,ctrl.getHistoryComponents);

//get only one cluster and it status
app.get('/api/clusters/:clustername',auth.authenticateToken,ctrl.getACluster);

//external service
app.post('/api/post/externalservices/url',auth.authenticateToken,auth.authorizeSuperUser,ctrl.addUrlExternalService);
app.delete('/api/delete/externalservices/url/:exurl/externalcomponent/:excomponentname/cluster/:clustername/:roleId',auth.authenticateToken,auth.authorizeSuperUserForDel,ctrl.delUrlExternalService);
app.patch('/api/patch/externalservices/:externalservicename/threshold',auth.authenticateToken,auth.authorizeSuperUser,ctrl.updateThresholdExternalService);
app.patch('/api/patch/externalservices/:externalservicename/threshold',auth.authenticateToken,auth.authorizeSuperUser,ctrl.updateThresholdExternalService);
app.patch('/api/patch/externalservices/url',auth.authenticateToken,auth.authorizeSuperUser,ctrl.updateUrlExternalService); //change url, suppose that each url is unique
app.post('/api/post/externalservices/cluster',auth.authenticateToken,auth.authorizeSuperUser,ctrl.addClusterExternalService);

//auth
app.post('/api/post/token',ctrl.getToken);


//user management
app.get('/api/users/:roleId',auth.authenticateToken,auth.authorizeAdmin,ctrl.getUsers);
app.post('/api/post/user/:roleId',auth.authenticateToken,auth.authorizeAdmin,ctrl.addUser);
app.delete('/api/delete/user/:username/:roleId',auth.authenticateToken,auth.authorizeAdmin,ctrl.delUser);
app.patch('/api/patch/password/:roleId',auth.authenticateToken,auth.authorizeAdmin,ctrl.updatePwdUser);

//refresh time
app.get('/api/refreshtime',auth.authenticateToken,ctrl.getRefreshTime);
app.patch('/api/patch/refreshtime/:time/:roleId',auth.authenticateToken,auth.authorizeSuperUserForDel,ctrl.updateRefreshTime);

//mail
app.get('/api/mail',auth.authenticateToken,ctrl.getMails);
app.delete('/api/delete/mail/:mail/:roleId',auth.authenticateToken,auth.authorizeSuperUserForDel,ctrl.delMail);
app.post('/api/post/mail',auth.authenticateToken,auth.authorizeSuperUser,ctrl.addMail);

module.exports = app;