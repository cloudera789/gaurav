const urls = require('./models/urls');
const queries = require('./models/queries');
const mysql = require('mysql2');
const externalApi = require('./services/externalAPI');
const config = require('./config/env.config');
const jwt = require('jsonwebtoken');
const MailMessage = require('nodemailer/lib/mailer/mail-message');

const pool = mysql.createPool({
  connectionLimit: 10,
  host: config.HOST_DATABASE,
  user: config.USER_DATABASE,
  password: config.PASSWORD_DATABASE,
  database: config.DATABASE
});

exports.getCustomers =(req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_customer, 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          console.log("Call customer");
          res.status(200).json(results);
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.getUsers =(req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_user, 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          console.log("Call user");
          res.status(200).json(results);
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.getInfoExternalServices =(req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_info_external_services, 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          const transformedJson = [];

          for (const item of results) {
            const existingService = transformedJson.find(service => service.exservice_name === item.exservice_name);
            if (existingService) {
              const existingCluster = existingService.clusters.find(cluster => cluster.cluster_name === item.cluster_name);
              if (existingCluster) {
                const existingComponent = existingCluster.components.find(component => component.excomponent_name === item.excomponent_name);
                if (existingComponent) {
                  existingComponent.exurl_host.push(item.exurl_host);
                } else {
                  existingCluster.components.push({
                    excomponent_name: item.excomponent_name,
                    exurl_host: [item.exurl_host]
                  });
                }
              } else {
                existingService.clusters.push({
                  cluster_name: item.cluster_name,
                  components: [
                    {
                      excomponent_name: item.excomponent_name,
                      exurl_host: [item.exurl_host]
                    }
                  ]
                });
              }
            } else {
              transformedJson.push({
                exservice_name: item.exservice_name,
                exservice_threshold: item.exservice_threshold,
                clusters: [
                  {
                    cluster_name: item.cluster_name,
                    components: [
                      {
                        excomponent_name: item.excomponent_name,
                        exurl_host: [item.exurl_host]
                      }
                    ]
                  }
                ]
              });
            }
          }
          
          console.log("Call external services info");
        
          
          res.status(200).json(transformedJson);
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.getProjects =(req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_projects_customer, 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          console.log("Call customer project");
          res.status(200).json(results);
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};


exports.getExternalServices =(req, res) => {
  const clusterName = req.params.clustername;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_cluster_external_services(clusterName), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          console.log("Call cluster external services");
          res.status(200).json(results);
        }
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.getAnExternalService =(req, res) => {
  const clusterName = req.params.clustername;
  const externalService = req.params.externalservice;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_cluster_an_external_service(clusterName,externalService), 
        async (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          nbHealthyHost = 0;
          combinedStr = [];
          let statusExternalService;
          let statusMsgExternalService;
          try{
          for(let item of results){
            try{
            let statusComponent = await new Promise((resolve, reject) => 
                externalApi.callExternalComponent(item['exurl_host'], (error, str) => error ? reject(error) : resolve(str))
            );
            //console.log("From ctrl "+statusComponent);
            if (statusComponent == "true") nbHealthyHost++;
            if (statusComponent != "true") statusComponent = false;
            const pattern = /\/\/([^\/:]+:\d+)/; // Regular expression pattern to match the desired substring
            const match = item['exurl_host'].match(pattern);
            str = {
              componentName : item['excomponent_name'],
              hostName : match[1],
              status : statusComponent ? "GREEN" : "RED",
              statusMsg : statusComponent ? "OK" : "KO"
            };
            combinedStr.push(str);
            //console.log(str);
            }catch(e) {
              console.error(`Error for host ${item['exurl_host']}: ${error}`);
              const pattern = /\/\/([^\/:]+:\d+)/;
              const match = item['exurl_host'].match(pattern);
              str = {
                componentName: item['excomponent_name'],
                hostName: match[1],
                status: "RED",
                statusMsg: "KO"
              };
              combinedStr.push(str);
            }
          }
          // }catch(e){
          //   const pattern = /\/\/([^\/:]+:\d+)/; // Regular expression pattern to match the desired substring
          //   const match = item['exurl_host'].match(pattern);
          //   str = {
          //     componentName : item['excomponent_name'],
          //     hostName : match[1],
          //     status : "RED",
          //     statusMsg : "KO"
          //   };
          //   combinedStr.push(str);
          // }
          if (nbHealthyHost == results.length) {statusExternalService = 'GREEN'; statusMsgExternalService = 'OK';}
            else if (nbHealthyHost >= results.length * (results[0]['exservice_threshold']/100)) {statusExternalService = 'ORANGE'; statusMsgExternalService = 'WARNING';}
              else {statusExternalService = 'RED'; statusMsgExternalService = 'CRITICAL'};
          resService = {
            clusterName : clusterName,
            externalServiceId : results[0]['exservice_id'],
            externalServiceName : externalService,
            statusService : statusExternalService,
            statusMsgService : statusMsgExternalService,
            date : new Date().toLocaleString('jw-FR'),
            components : combinedStr
          }
          console.log('Call an external service')
          res.status(200).json(resService);
          connection.query(
            queries.insert_history_exservice(resService.clusterName, resService.externalServiceName, resService.statusService,resService.date, resService.statusMsgService),
            (error) => {
              if(error){
                console.error('Error executing query:', error);        
              }else{
                console.log('Add history external service');
              }
            }
          ) 
        }catch(e){
            console.error(`Cant get status of external service ${externalService} from cluster ${clusterName}`);
            console.error(e);
        }
          // resService['components'].forEach((s) => {
          //   connection.query(
          //     queries.insert_history_excomponent(clusterName,externalService, s.status,s.statusMsg,s.date, s.message),
          //     (error) => {
          //       if(error){
          //         console.error('Error executing query:', error);        
          //       }else{
          //         console.log('Add history service');
          //       }
          //     }
          //   ) 
          // });
        }
        // resService.forEach((s) => {
          
        // });


          

        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.getClustersProjects =(req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_cluster_project, 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          console.log(`[${new Date().toLocaleString('jw-FR')}] Call cluster project`);
          console.log(results);
          const combiendResults = Object.values(results.reduce((acc, obj) => {
            const { cluster_name, project_name, ...rest } = obj;
            if (!acc[cluster_name]) {
                acc[cluster_name] = { cluster_name, projects: [], ...rest };
            }
            acc[cluster_name].projects.push(project_name);
            return acc;
        }, {}));

          console.log('Called clusters projects');
          res.status(200).json(combiendResults);
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.getClusters = async (req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_clusters_type_project, 
        async (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          console.log(`[${new Date().toLocaleString('jw-FR')}] Call cluster type project`);
          
          const combiendResults = Object.values(results.reduce((acc, obj) => {
            const { cluster_name, project_name, ...rest } = obj;
            if (!acc[cluster_name]) {
                acc[cluster_name] = { cluster_name, projects: [], ...rest };
            }
            acc[cluster_name].projects.push(project_name);
            return acc;
          }, {}));
          var combinedStr = [];
          for (let result of combiendResults){
            const url_host = result['url_host']
              .replace('{addressIP}',result['cluster_adr'])
              .replace('{clusterName}',result['cluster_name'])
              .replace('{endpoint}',result['endpoint']);
            //console.log(url_host);
            //console.log(result.projects);
            //url_id =1 is cluster ambari
            try{
            if (result['url_id'] == 1) {
              const str = await new Promise((resolve, reject) => 
                  externalApi.callClusterAmbari(url_host, result['cluster_user'], result['cluster_pwd'], result['cluster_threshold'], result['projects'], (error, str) => error ? reject(error) : resolve(str))
              );
              combinedStr.push(str); 
            } else if (result['url_id'] == 2) { //if not, it is cluster CM
              const str = await new Promise((resolve, reject) => 
                  externalApi.callClusterCM(url_host, result['cluster_user'], result['cluster_pwd'], result['cluster_threshold'], result['projects'], (error, str) => error ? reject(error) : resolve(str))
              );
              combinedStr.push(str); 
              
            }else{
              console.error("Invalid url_id :"+result['url_id']);
            }
            //console.log(combinedStr[combinedStr.length-1].date);
            connection.query(
              queries.insert_history_cluster(combinedStr[combinedStr.length-1].clusterName,combinedStr[combinedStr.length-1].status,combinedStr[combinedStr.length-1].date),
              (error) => {
                if(error){
                  console.error('Error executing query:', error);
        
                }else{
                  //console.log("Add history cluster");
                }
              }
            )}catch(e){
              console.error(`Cant get status of cluster ${result['cluster_name']}`);
              continue;
            }
          }
          
          res.status(200).json(combinedStr);
        }
        
        // Release the connection back to the pool
        connection.release();
      });
      
    }
  });
};

exports.getACluster = async (req, res) => {
  const clusterName = req.params.clustername;
  //console.log(clusterName);
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_a_cluster_type_project(clusterName), 
        async (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          console.log("Call  a cluster type project");
          console.log(results);
          const combiendResults = Object.values(results.reduce((acc, obj) => {
            const { cluster_name, project_name, ...rest } = obj;
            if (!acc[cluster_name]) {
                acc[cluster_name] = { cluster_name, projects: [], ...rest };
            }
            acc[cluster_name].projects.push(project_name);
            return acc;
          }, {}));
            const url_host = combiendResults[0]['url_host']
            .replace('{addressIP}',combiendResults[0]['cluster_adr'])
            .replace('{clusterName}',combiendResults[0]['cluster_name'])
            .replace('{endpoint}',combiendResults[0]['endpoint']);
            //console.log(url_host);
          //console.log(result.projects);
          //url_id =1 is cluster ambari
        
          let str;
          if (results[0]['url_id'] == 1) {
             str = await new Promise((resolve, reject) => 
                externalApi.callClusterAmbari(url_host, combiendResults[0]['cluster_user'], combiendResults[0]['cluster_pwd'], combiendResults[0]['cluster_threshold'], combiendResults[0]['projects'], (error, str) => error ? reject(error) : resolve(str))
            );
            //console.log(str);
          } else { //if not, it is cluster CM
             str = await new Promise((resolve, reject) => 
                externalApi.callClusterCM(url_host, combiendResults[0]['cluster_user'], combiendResults[0]['cluster_pwd'], combiendResults[0]['cluster_threshold'], combiendResults[0]['projects'], (error, str) => error ? reject(error) : resolve(str))
            );         
            //console.log(str);   
          }
         
          connection.query(
            queries.insert_history_cluster(str.clusterName,str.status,str.date),
            (error) => {
              if(error){
                console.error('Error executing query:', error);
      
              }else{
                //console.log("Add history a cluster");
              }
            }
          ) 
          
          
          res.status(200).json(str);
          
         
        
        // Release the connection back to the pool
        connection.release();
        }});
        
    }
  });
};


exports.getServices = (req, res) => {
  const clustername = req.params.clustername;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_cluster_services(clustername), 
        async (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          //console.log('Query results:', results);
          const url_service = results[0]['url_service']
              .replace('{addressIP}',results[0]['cluster_adr'])
              .replace('{clusterName}',results[0]['cluster_name'])
              .replace('{endpoint}',results[0]['endpoint']);
          //console.log(url_service);
          var str;
          switch (results[0]['url_id']){
            case (1) : //if cluster is ambari
              str = await new Promise((resolve, reject) => 
                  externalApi.callServiceAmbari(url_service,clustername, results[0]['cluster_user'],results[0]['cluster_pwd'], (error, str) => error ? reject(error) : resolve(str)));
              break;
            case (2) : //cluster CM
              str =  await new Promise((resolve, reject) => 
                  externalApi.callServiceCM(url_service,clustername, results[0]['cluster_user'],results[0]['cluster_pwd'], (error, str) => error ? reject(error) : resolve(str)));
              break;
          }              
          // str.forEach((s) => {
          //   connection.query(
          //     queries.select_exist_service(s.serviceName, s.clusterName),
          //     (error,results) => {
          //       if(error){
          //         console.error('Error executing query:', error);        
          //       }else{
          //         if (results[0].exist == 0){
          //           // console.log(s.serviceName);
          //           connection.query(
          //             queries.insert_service(s.serviceName, s.clusterName),
          //             (error) => {
          //               if(error){
          //                 console.error('Error executing query:', error);        
          //               }else{
          //                 console.log('Add new service');
          //               }
          //             }
          //           ) 
          //         };
          //         connection.query(
          //           queries.insert_history_service(s.clusterName, s.serviceName, s.status,s.date, s.message),
          //           (error) => {
          //             if(error){
          //               console.error('Error executing query:', error);        
          //             }else{
          //               console.log('Add history service');
          //             }
          //           }
          //         ) 
          //       }
          //     }
          //   ) 
          // });
          res.status(200).json(str);
        }
        // Release the connection back to the pool
        connection.release();
      });
    }
  });

}

exports.getComponents = (req, res) => {
  const clustername = req.params.clustername;
  var servicename = req.params.servicename;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_cluster_components(clustername), 
        async (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          //console.log('Query results:', results);
          const url_component = results[0]['url_component']
              .replace('{addressIP}',results[0]['cluster_adr'])
              .replace('{clusterName}',results[0]['cluster_name'])
              .replace('{serviceName}',servicename)
              .replace('{endpoint}',results[0]['endpoint']);
          //console.log(url_component);
          var str;
          switch (results[0]['url_id']){
            case (1) : //if cluster is ambari
              str = await new Promise((resolve, reject) => 
                  externalApi.callComponentAmbari(url_component,clustername, results[0]['cluster_user'],results[0]['cluster_pwd'], (error, str) => error ? reject(error) : resolve(str)));
              break;
            case (2) : //cluster CM
              str =  await new Promise((resolve, reject) => 
                  externalApi.callComponentCM(url_component,clustername, results[0]['cluster_user'],results[0]['cluster_pwd'], (error, str) => error ? reject(error) : resolve(str)));
              break;
            default : 
              console.error('Invalid url_id : '+results[0]['url_id']);
              break;
          }
          res.status(200).json(str);
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.getMsg = (req, res) => {
  const clustername = req.params.clustername;
  var servicename = req.params.servicename;

  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_cluster_messages(clustername), 
        async (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          //console.log('Query results:', results);
          const url_msg = results[0]['url_message']
              .replace('{addressIP}',results[0]['cluster_adr'])
              .replace('{clusterName}',results[0]['cluster_name'])
              .replace('{serviceName}',servicename)
              .replace('{endpoint}',results[0]['endpoint']);
          //console.log(url_msg);
          var str;
          switch (results[0]['url_id']){
            case (1) : //if cluster is ambari
              str = await new Promise((resolve, reject) => 
                  externalApi.callMsgAmbari(url_msg,clustername, results[0]['cluster_user'],results[0]['cluster_pwd'], (error, str) => error ? reject(error) : resolve(str)));
              break;
            case (2) : //cluster CM
              str =  await new Promise((resolve, reject) => 
                  externalApi.callMsgCM(url_msg,clustername, results[0]['cluster_user'],results[0]['cluster_pwd'], (error, str) => error ? reject(error) : resolve(str)));
              break;
          }
          res.status(200).json(str);
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
}

exports.testAmbari = (req, res) => {
    const request = require('request');
    const options = {
      url: urls.urlHostAmbari,
      proxy: 'socks5://127.0.0.1:8118', //require privoxy
      rejectUnauthorized: false,
      auth: {
        user: urls.userTestCM,
        password: urls.pwdTestCM
      }
    };
    request.get(options, (error, response, body) => {
      if (error) {
        console.error(error);
      } else {
        const json = JSON.parse(body);
    
        //Variables to count number of HEALTH/UNHEALTHY hosts 
        var nbHealthyHost = 0;

        for(const item of json['items']){
            if (item['Hosts']['host_name'] == 'HEALTHY') nbHealthyHost+=1; 
            //console.log(item['Hosts']['host_name']);
            //console.log(item['Hosts']['host_status']);
        }

        console.log(nbHealthyHost+ ' healthy hosts in '+json['items'].length +' hosts');
        var statusCluster ='';
        if (nbHealthyHost == json['items'].length) statusCluster = 'GREEN';
        else{
            if (nbHealthyHost >= json['items'].length/2) statusCluster = 'ORANGE';
            else statusCluster = 'RED';
        };
        res.json({
            projectName : 'DataEye',
            clusterName : json['items'][0]['Hosts']['cluster_name'],
            status : statusCluster
        });
        //console.log(body);
      }
    });
};

exports.addCustomer =(req, res) => {
  const customerName = req.body['customer_name'];
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.insert_customer(customerName), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
            res.status(201).json({
              message: 'Added new customer'
            });
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.delCustomer =(req, res) => {
  const customerName = req.params.customername;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.delete_customer(customerName), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404).json({
            message: 'Cannot delete customer'
          });
        } else {
            res.status(200).json({
              message: 'Deleted customer'
            });
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.updateCustomer =(req, res) => {
  const oldName = req.body.old_name;
  const newName = req.body.new_name;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.update_customer(oldName,newName), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404).json({
            message: 'Cannot find customer'
          });;
        } else {
            res.status(200).json({
              message: 'Changed name of customer'
            });
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.updateThresholdExternalService =(req, res) => {
  const externalServiceName = req.params.externalservicename;
  const newThreshold = req.body.threshold;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.update_threshold_external_service(externalServiceName,newThreshold), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404).json({
            message: 'Cannot find external service'
          });;
        } else {
            res.status(200).json({
              message: 'Changed threshold of external service'
            });
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.updateUrlExternalService =(req, res) => {
  const newUrl = req.body.new_url;
  const oldUrl = req.body.old_url;
  const exccomponentName = req.body.excomponent_name;
  const clusterName = req.body.cluster_name;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.update_url_external_service(oldUrl,newUrl,exccomponentName,clusterName), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404).json({
            message: 'Cannot find url external service'
          });;
        } else {
            res.status(200).json({
              message: 'Changed url of external service'
            });
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.addProject =(req, res) => {
  const projectName = req.body['project_name'];
  const customerName = req.body['customer_name'];
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.insert_project(projectName), 
        (error) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404);
          connection.release;
        } else {
            connection.query(
              queries.link_project_customer(projectName,customerName),
              (error) => {
                if(error){
                  console.error('Error executing query:', error);
                  res.status(404);
                  connection.release;
                }else{
                  res.status(201).json({
                    message: 'Added new project'
                  });
                }
              }

            )
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.updateProject =(req, res) => {
  const oldName = req.body.old_name;
  const newName = req.body.new_name;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.update_project(oldName,newName), 
        (error) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404).json({
            message: 'Cannot find project'
          });;
        } else {
            res.status(200).json({
              message: 'Changed name of project'
            });
        }
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.updateRealize =(req, res) => {
  const projectName = req.body.project_name;
  const oldCustomerName = req.body.old_customer_name;
  const newCustomerName = req.body.new_customer_name;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.update_realize(projectName, oldCustomerName, newCustomerName), 
        (error) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404).json({
            message: 'Cannot find customer'
          });;
        } else {
            res.status(200).json({
              message: 'Changed customer name of project'
            });
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.delProject =(req, res) => {
  const projectName = req.params.projectname;
  
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.if_is_hosted(projectName), 
        (error,results) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404);
          connection.release;
        } else {
            if(results.length == 0){
              connection.query(
                queries.delete_realize(projectName),
                (error) => {
                  if(error){
                    console.error('Error executing query:', error);
                    res.status(404);
                    connection.release;
                  }else{
                    connection.query(
                      queries.delete_project(projectName),
                      (error) => {
                        if(error){
                          console.error('Error executing query:', error);
                          res.status(404);
                          connection.release;
                        }else{
                          res.status(200).json({
                            message: 'Deleted project'
                          });
                        }
                      }
                    )
                  }
                }
              )
            }else{
              res.status(404).json({
                message: 'Cannot delete project'
              });
            }
            
        }
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.delIsHosted =(req, res) => {
  const projectName = req.body.project_name;
  const clusterName = req.body.cluster_name;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.delete_ishosted(projectName, clusterName), 
        (error) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404).json({
            message: 'Cannot delete link between project and cluster in table is_hosted'
          });
        } else {
            res.status(200).json({
              message: 'Deleted link between project and cluster in table is_hosted'
            });
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.addIsHosted =(req, res) => {
  const projectName = req.body['project_name'];
  const clusterName = req.body['cluster_name'];
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.insert_ishosted(projectName,clusterName), 
        (error) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
            res.status(201).json({
              message: 'Added link between project and cluster in table is_hosted'
            });
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.updateUsernameCluster =(req, res) => {
  const clusterName = req.params.clustername;
  const newName = req.body.new_name;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.update_username_cluster(clusterName,newName), 
        (error) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404).json({
            message: 'Cannot find cluster'
          });;
        } else {
            res.status(200).json({
              message: 'Changed username of cluster'
            });
        }
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.updatePwdCluster =(req, res) => {
  const clusterName = req.params.clustername;
  const newName = req.body.new_name;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.update_pwd_cluster(clusterName,newName), 
        (error) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404).json({
            message: 'Cannot find cluster'
          });;
        } else {
            res.status(200).json({
              message: 'Changed password of cluster'
            });
        }
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.updateAdrCluster =(req, res) => {
  const clusterName = req.params.clustername;
  const newName = req.body.new_name;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.update_adr_cluster(clusterName,newName), 
        (error) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404).json({
            message: 'Cannot find cluster'
          });;
        } else {
            res.status(200).json({
              message: 'Changed address IP of cluster'
            });
        }
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.updateThresholdCluster =(req, res) => {
  const clusterName = req.params.clustername;
  const newName = req.body.new_name;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.update_threshold_cluster(clusterName,newName), 
        (error) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404).json({
            message: 'Cannot find cluster'
          });;
        } else {
            res.status(200).json({
              message: 'Changed threshold of cluster'
            });
        }
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.addCluster =(req, res) => {
  const clusterName = req.body['cluster_name'];
  const clusterUsername = req.body['cluster_user'];
  const clusterPwd = req.body['cluster_pwd'];
  const clusterAdr = req.body['cluster_adr'];
  const clusterType = req.body['cluster_type'];
  const clusterThreshold = req.body['cluster_threshold'];
  const clusterEndpoint = req.body['endpoint'];
  const projects = req.body['projects'];

  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.insert_cluster(clusterName,clusterUsername,clusterPwd,clusterAdr,clusterThreshold,clusterEndpoint), 
        (error) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404);
          connection.release;
        } else {
            connection.query(
              queries.link_type_cluster(clusterType,clusterName),
              (error) => {
                if(error){
                  console.error('Error executing query:', error);
                  res.status(404);
                  connection.release;
                }else{
                  projects.forEach((project) => {
                   
                  
                    connection.query(
                      queries.link_project_cluster(project, clusterName),
                      (error) => {
                        if (error) {
                          console.error('Error executing query:', error);
                          res.status(404);
                          connection.release;
                        } else {
                          // Successfully linked project to the cluster
                          console.log(`Linked project ${project} to cluster ${clusterName}`);
                        }
                      }
                    );
                  });
                  
                  res.status(201).json({
                    message: 'Added new cluster'
                  });
                }
              }
            )
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.getTypes =(req, res) => {
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_types, 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
            res.status(200).json(results);
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.delCluster =(req, res) => {
  const clusterName = req.params.clustername;
  console.log(clusterName); 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.del_link_project_cluster(clusterName), 
        (error,results) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404);
          connection.release;
        } else {
              console.log("del link project");
              connection.query(
                queries.del_link_type_cluster(clusterName),
                (error) => {
                  if(error){
                    console.error('Error executing query:', error);
                    res.status(404);
                    connection.release;
                  }else{
                    console.log("del link type");
                    connection.query(
                      queries.delete_cluster(clusterName),
                      (error) => {
                        if(error){
                          console.error('Error executing query:', error);
                          res.status(404);
                          connection.release;
                        }else{
                          console.log("del cluster");
                          res.status(200).json({
                            message: 'Deleted cluster'
                          });
                        }
                      }
                    )
                  }
                }
              )   
        }
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.getHistoryCluster =(req, res) => {
  const clusterName = req.params.clustername;
  //console.log(clusterName);
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_history_cluster(clusterName), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
            //console.log('Call history cluster');
            //console.log(results);
            res.status(200).json(results);
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.getHistoryServices =(req, res) => {
  const clusterName = req.params.clustername;
  //console.log(clusterName);
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_history_services(clusterName), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
            //console.log('Call history services');
            //console.log(results);
            res.status(200).json(results);
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

//for adding history 
exports.addComponent =(req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      for(let elt of req.body){
        const clusterName = elt.cluster_name;
        const componentName = elt.component_name;
        const serviceName = elt.service_name;
        const status = elt.status;
        const statusMsg = elt.status_msg;
        const msg = elt.msg;
        const date = elt.date;
        connection.query(
          queries.select_exist_component(clusterName, serviceName, componentName),
          (error,results) => {
            if(error){
              console.error('Error executing query:', error);
                  
            }else{
              if (results[0].exist == 0){
                // console.log(s.serviceName);
                connection.query(
                  queries.insert_component(clusterName, serviceName, componentName),
                  (error) => {
                    if(error){
                      console.error('Error executing query:', error);        
                    }else{
                      console.log('Add new component');
                    }
                  }
                ) 
              };
              connection.query(
                queries.insert_history_component(clusterName, serviceName,componentName,status,statusMsg,msg,date),
                (error) => {
                  if(error){
                    console.error('Error executing query:', error);        
                    
                  }else{
                    console.log('Add history component');
                    
                  }
                }
              ) 
            }
          }
        ) 
      };
      connection.release();
      res.status(201).json({
        message: 'Added new history component'
      });
    }
  });
};

exports.addExternalComponent =(req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      for(let elt of req.body){
        const clusterName = elt.cluster_name;
        const componentName = elt.component_name;
        const serviceName = elt.service_name;
        const status = elt.status;
        const statusMsg = elt.status_msg;
        const msg = elt.msg;
        const date = elt.date;
        connection.query(
          queries.insert_history_excomponent(clusterName, serviceName,componentName,status,statusMsg,msg,date),
          (error) => {
            if(error){
              console.error('Error executing query:', error);        
            }else{
              //console.log('Add history external component');
            }
          }
        ) 
      };
      connection.release();
      res.status(201).json({
        message: 'Added new history external component'
      });
    }
  });
};

exports.getHistoryComponents  =(req, res) => {
  const clusterName = req.params.clustername;
  const serviceName = req.params.servicename;
  //console.log(clusterName);
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_history_component(clusterName,serviceName), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
            if(results.length != 0){
              //console.log('Call history services');
              res.status(200).json(results);
            }else{
              connection.query(
                queries.select_history_excomponent(clusterName,serviceName), 
                (error, results) => {
                  if (error) {
                    console.error('Error executing query:', error);
                  } else {
                    res.status(200).json(results);
                  
                  }
                }
              )
            } 
            //console.log(results[1].component_msg);
            //console.log(results);
            
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.addUrlExternalService =(req, res) => {
  const clusterName = req.body['cluster_name'];
  const exserviceName = req.body['exservice_name'];
  const excomponentName = req.body['excomponent_name'];
  const url = req.body['url'];
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      
            connection.query(
              queries.insert_url_external_servie(clusterName,exserviceName,excomponentName,url),
              (error) => {
                if(error){
                  console.error('Error executing query:', error);
                  res.status(404);
                  connection.release;
                }else{
                  res.status(201).json({
                    message: 'Added new url external service'
                  });
                }
              }

            )
        
          
        // Release the connection back to the pool
        connection.release();
    
    }
  });
};

exports.delUrlExternalService =(req, res) => {
  const exUrl = decodeURIComponent(req.params.exurl);
  const excomponentName = req.params.excomponentname;
  const clusterName = req.params.clustername;
  //console.log(req.params.exUrl);
  //console.log(exUrl);
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.delete_url_external_service(exUrl,excomponentName,clusterName), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404).json({
            message: 'Cannot delete url exser'
          });
        } else {
            res.status(200).json({
              message: 'Deleted url external service'
            });
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.getComponentsExternalServices = (req, res) => {
  const exserviceName = req.params.externalservice;
  //console.log(exserviceName);
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_components_external_service(exserviceName), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          //console.log("Call list component of exser");
          //console.log(results);
          res.status(200).json(results);
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.addClusterExternalService =(req, res) => {
  const clusterName = req.body['cluster_name'];
  const exserviceName = req.body['exservice_name'];
  const components = req.body['components'];

  // console.log('addclusterExternalSer');
  // console.log(clusterName);
  // console.log(exserviceName);
  // console.log(components);
  // console.log(components[0].excomponent_name);
  // console.log(components[0].exurl_host);
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
            connection.query(
              queries.link_cluster_external_service(clusterName,exserviceName),
              (error) => {
                if(error){
                  console.error('Error executing query:', error);
                  res.status(404);
                  connection.release;
                }else{
                  components.forEach((component) => {
                    connection.query(
                      queries.insert_url_external_servie(clusterName,exserviceName,component.excomponent_name,component.exurl_host),
                      (error) => {
                        if(error){
                          console.error('Error executing query:', error);
                          res.status(404);
                          connection.release;
                        }
                      }
                    )
                  });
                  res.status(201).json({
                    message: 'Added new cluster in external service'
                  });
                  
                }
              }
            )

            
        // Release the connection back to the pool
        connection.release();
    
    }
  });
};

exports.addServiceHistory =(req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      for(let elt of req.body){
        const clusterName = elt.cluster_name;
        const serviceName = elt.service_name;
        const status = elt.status;
        const msg = elt.msg;
        const date = elt.date;
        connection.query(
          queries.select_exist_service(serviceName, clusterName),
          (error,results) => {
            if(error){
              console.error('Error executing query:', error);
                  
            }else{
              if (results[0].exist == 0){
                // console.log(s.serviceName);
                connection.query(
                  queries.insert_service(serviceName, clusterName),
                  (error) => {
                    if(error){
                      console.error('Error executing query:', error);        
                    }else{
                      console.log('Add new service');
                    }
                  }
                ) 
              };
              connection.query(
                queries.insert_history_service(clusterName, serviceName,status,date,msg),
                (error) => {
                  if(error){
                    console.error('Error executing query:', error);        
                    
                  }else{
                    console.log('Add history service');
                    
                  }
                }
              ) 
            }
          }
        ) 
      };
      connection.release();
      res.status(201).json({
        message: 'Added new history service'
      });
    }
  });
};

exports.getToken =(req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_username_password(username), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
            //res.status(200).json(results);
            if (password == undefined ||results.length == 0 || results[0].password != password ) {
              res.status(401).json({ error : 'Password is not correct'});
            }else{
              res.status(200).json({
                roleId : results[0].role_id,
                token : jwt.sign(
                  { userId : results[0].user_id },
                  'RANDOM_TOKEN_SECRET',
                  { expiresIn : config.TOKEN_DURATION}
                )
              })
            }
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.addUser =(req, res) => {
  const username = req.body.username;
  const pwd = req.body.password;
  const role = req.body.roleId;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.insert_user(username,pwd,role), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          connection.query(
            queries.insert_has_role(username,role), 
            (error, results) => {
            if (error) {
              console.error('Error executing query:', error);
            } else {
              res.status(201).json({
                message: 'Added new user'
              });
          
            }
            })}
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.delUser =(req, res) => {
  const username = req.params.username;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.delete_has_role(username), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          connection.query(
            queries.delete_user_account(username), 
            (error, results) => {
            if (error) {
              console.error('Error executing query:', error);
            } else {
              res.status(201).json({
                message: 'Delete user'
              });
          
            }
            })}
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.updatePwdUser = (req, res) => {
  const username = req.body.username;
  const newpwd = req.body.newpwd;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.update_password_user(username,newpwd), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404).json({
            message: 'Cannot find user'
          });;
        } else {
            res.status(200).json({
              message: 'Changed pwd of user'
            });
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.getRefreshTime =(req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_refresh_time, 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          console.log(`[${new Date().toLocaleString('jw-FR')}] "Call refresh time"`);
          res.status(200).json(results);
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.updateRefreshTime =(req, res) => {
  
  const newTime = req.params.time;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.update_refresh_time(newTime), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
          res.status(404).json({
            message: 'Cannot find refreshti'
          });;
        } else {

            res.status(200).json({
              message: 'Changed refresh time'
            });
            console.log(`[${new Date().toLocaleString('jw-FR')}] "Change refresh time to : "+newTime+ " miliseconds"`);
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.getMails =(req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.select_mail, 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
          console.log("Call mail");
          res.status(200).json(results);
        }       
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.delMail =(req, res) => {
  const mail = req.params.mail;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.delete_mail(mail), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {   
          res.status(201).json({
            message: 'Delete mail'
          });           
        }     
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};

exports.addMail =(req, res) => {
  const newMail = req.body.new_mail;
 
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('Error getting connection from pool:', error);
    } else {
      //console.log('Got a connection from the pool!');
      // Execute a query
      connection.query(
        queries.insert_mail(newMail), 
        (error, results) => {
        if (error) {
          console.error('Error executing query:', error);
        } else {
            res.status(201).json({
              message: 'Added new mail'
            });
        }
        
        // Release the connection back to the pool
        connection.release();
      });
    }
  });
};
