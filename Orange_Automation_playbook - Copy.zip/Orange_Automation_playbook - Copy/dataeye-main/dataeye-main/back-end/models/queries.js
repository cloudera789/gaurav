exports.select_projects_customer = 
    'SELECT project_name, customer_name FROM project p, customer c, realize r WHERE c.customer_id = r.customer_id AND p.project_id = r.project_id';
exports.select_customer = 
    'SELECT customer_name FROM customer';
exports.select_cluster_project = 
    // 'SELECT c.cluster_name, c.cluster_user, c.cluster_pwd, c.cluster_adr, h.url_id, url_type, project_name FROM project p, cluster c, is_hosted i, has_type h, url u WHERE h.url_id = u.url_id AND h.cluster_id = c.cluster_id AND c.cluster_id = i.cluster_id AND p.project_id = i.project_id ORDER BY cluster_name';
    'SELECT c.cluster_name, c.cluster_user, c.cluster_pwd, c.cluster_adr, c.cluster_threshold, c.endpoint, h.url_id, url_type, project_name FROM cluster c LEFT JOIN is_hosted i ON c.cluster_id = i.cluster_id LEFT JOIN project p ON p.project_id = i.project_id LEFT JOIN has_type h ON h.cluster_id = c.cluster_id LEFT JOIN url u ON h.url_id = u.url_id ORDER BY c.cluster_name';

exports.select_cluster_services = function(clusterName) {
    return `SELECT c.*, url_type, h.url_id, url_service FROM cluster c, url u, has_type h WHERE c.cluster_id = h.cluster_id AND u.url_id = h.url_id AND cluster_name = '${clusterName}'`;
  };
exports.select_cluster_components = function(clusterName) {
    return `SELECT c.*, url_type, h.url_id, url_component FROM cluster c, url u, has_type h WHERE c.cluster_id = h.cluster_id AND u.url_id = h.url_id AND cluster_name = '${clusterName}'`;
  };

exports.select_cluster_messages = function(clusterName) {
    return `SELECT c.*, url_type, h.url_id, url_message FROM cluster c, url u, has_type h WHERE c.cluster_id = h.cluster_id AND u.url_id = h.url_id AND cluster_name = '${clusterName}'`;
  };
exports.select_cluster_type = 
  'SELECT DISTINCT c.*, h.url_id, url_host FROM cluster c, url u, is_hosted i, has_type h WHERE h.cluster_id = c.cluster_id AND h.url_id = u.url_id AND i.cluster_id = c.cluster_id';
exports.select_clusters_type_project = 
   'SELECT c.*, h.url_id, url_host, project_name FROM cluster c, url u, has_type h, project p, is_hosted i WHERE h.cluster_id = c.cluster_id AND h.url_id = u.url_id AND i.project_id = p.project_id AND i.cluster_id = c.cluster_id';
exports.select_a_cluster_type_project = function(clusterName){
   return `SELECT c.*, h.url_id, url_host, project_name FROM cluster c, url u, has_type h, project p, is_hosted i WHERE h.cluster_id = c.cluster_id AND h.url_id = u.url_id AND i.project_id = p.project_id AND i.cluster_id = c.cluster_id AND cluster_name = '${clusterName}'`;
}
exports.select_clusters_project = 
    'SELECT cluster_name, project_name FROM cluster c, project p, is_hosted i WHERE i.project_id = p.project_id AND i.cluster_id = c.cluster_id';
exports.insert_customer = function(customerName){
    return `INSERT INTO customer (customer_name) VALUES ('${customerName}')`;
}
exports.delete_customer = function(customerName){
  return `DELETE FROM customer WHERE customer_name = '${customerName}'`;
}
exports.update_customer = function(oldName, newName){
  return `UPDATE customer SET customer_name = '${newName}' WHERE customer_name = '${oldName}'`;
}
exports.insert_project = function(projectName){
  return `INSERT INTO project (project_name) VALUES ('${projectName}')`;
}
exports.link_project_customer = function(projectName,customerName){
  return `INSERT INTO realize SELECT customer_id, project_id FROM customer, project WHERE customer_name = '${customerName}' AND project_name= '${projectName}'`;
}
exports.update_project = function(oldName, newName){
  return `UPDATE project SET project_name = '${newName}' WHERE project_name = '${oldName}'`;
}
exports.update_realize = function(projectName, oldCustomerName, newCustomerName){
  return `UPDATE realize SET customer_id = (SELECT customer_id FROM customer WHERE customer_name = '${newCustomerName}') WHERE customer_id = (SELECT customer_id FROM customer WHERE customer_name = '${oldCustomerName}') AND project_id = (SELECT project_id FROM project WHERE project_name = '${projectName}');`;
}
exports.delete_project = function(projectName){
  return `DELETE FROM project WHERE project_name = '${projectName}'`;
}
exports.delete_realize = function(projectName){
  return `DELETE FROM realize WHERE project_id = (SELECT project_id FROM project WHERE project_name = '${projectName}')`;
}
// exports.delete_is_hosted = function(projectName){
//   return `DELETE FROM is_hosted WHERE project_id = (SELECT project_id FROM project WHERE project_name = '${projectName}')`;
// }
exports.if_is_hosted = function(projectName){
  return `SELECT i.project_id FROM project p, is_hosted i WHERE p.project_name = '${projectName}' AND p.project_id = i.project_id`;
}
exports.delete_ishosted = function(projectName, clusterName){
return ` DELETE FROM is_hosted WHERE project_id = (SELECT project_id FROM project p WHERE p.project_name = '${projectName}') AND cluster_id = (SELECT cluster_id FROM cluster c WHERE c.cluster_name = '${clusterName}' );`;
}
exports.insert_ishosted = function(projectName,clusterName){
  return `INSERT INTO is_hosted SELECT project_id, cluster_id FROM cluster, project WHERE cluster_name = '${clusterName}' AND project_name= '${projectName}'`;
}
exports.update_username_cluster = function(clusterName,newName){
  return `UPDATE cluster SET cluster_user = '${newName}' WHERE cluster_name = '${clusterName}'`; 
}
exports.update_pwd_cluster = function(clusterName,newName){
  return `UPDATE cluster SET cluster_pwd = '${newName}' WHERE cluster_name = '${clusterName}'`; 
}
exports.update_adr_cluster = function(clusterName,newName){
  return `UPDATE cluster SET cluster_adr = '${newName}' WHERE cluster_name = '${clusterName}'`; 
}
exports.update_threshold_cluster = function(clusterName,newName){
  return `UPDATE cluster SET cluster_threshold = '${newName}' WHERE cluster_name = '${clusterName}'`; 
}
exports.select_types = 'SELECT url_type FROM url';
exports.insert_cluster = function(clusterName,clusterUsername,clusterPwd,clusterAdr,clusterThreshold,clusterEndpoint){
  return `INSERT INTO cluster (cluster_name,cluster_user,cluster_pwd,cluster_adr,cluster_threshold,endpoint) VALUES ('${clusterName}','${clusterUsername}','${clusterPwd}','${clusterAdr}','${clusterThreshold}','${clusterEndpoint}')`;
}
exports.link_project_cluster = function(projectName,clusterName){
  return `INSERT INTO is_hosted SELECT project_id, cluster_id FROM cluster, project WHERE cluster_name = '${clusterName}' AND project_name= '${projectName}'`;
}
exports.link_type_cluster = function(type,clusterName){
  return `INSERT INTO has_type SELECT cluster_id, url_id FROM cluster, url WHERE cluster_name = '${clusterName}' AND url_type= '${type}'`;
}

exports.del_link_project_cluster = function(clusterName){
  return `DELETE FROM is_hosted WHERE cluster_id = (SELECT cluster_id FROM cluster WHERE cluster_name = '${clusterName}')`;
}

exports.del_link_type_cluster = function(clusterName){
  return `DELETE FROM has_type WHERE cluster_id = (SELECT cluster_id FROM cluster WHERE cluster_name = '${clusterName}')`;
}

exports.delete_cluster = function(clusterName){
  return `DELETE FROM cluster WHERE cluster_name = '${clusterName}'`;
}

exports.insert_history_cluster = function(clusterName, status, date){
  return `INSERT INTO history_cluster (cluster_status, cluster_date, cluster_id) VALUES ('${status}',STR_TO_DATE('${date}', '%d-%m-%Y, %H:%i:%s'), (SELECT cluster_id FROM cluster WHERE cluster_name='${clusterName}'))`;
}

exports.select_history_cluster = function(clusterName){
  return `SELECT cluster_name, cluster_status, DATE_ADD(h.cluster_date, INTERVAL 2 HOUR) AS cluster_date FROM cluster c, history_cluster h WHERE c.cluster_id = h.cluster_id AND cluster_name = '${clusterName}' ORDER BY cluster_date DESC`;
}

exports.select_exist_service = function(serviceName, clusterName){
  return `SELECT COUNT(*) as exist FROM service s, cluster c WHERE service_name='${serviceName}' AND c.cluster_id = s.cluster_id AND cluster_name = '${clusterName}'`;
}

// exports.select_exist_exservice = function(serviceName, clusterName){
//   return `SELECT COUNT(*) as exist FROM external_service s, cluster c, has_external_service h WHERE exservice_name='${serviceName}' AND s.exservice_id = h.exservice_id AND c.cluster_id = h.cluster_id AND cluster_name = '${clusterName}';`;
// }

exports.insert_service = function(serviceName,clusterName){
  return `INSERT INTO service (service_name,cluster_id) VALUES ('${serviceName}',(SELECT cluster_id FROM cluster WHERE cluster_name = '${clusterName}'));`;
}

exports.insert_history_service = function(clusterName, serviceName, status, date, msg){
  return `INSERT INTO history_service (service_status, service_date, service_message, service_id) VALUES ('${status}',STR_TO_DATE('${date}', '%d-%m-%Y, %H:%i:%s'), '${msg}', (SELECT service_id FROM service s, cluster c WHERE service_name='${serviceName}' AND c.cluster_id = s.cluster_id AND cluster_name = '${clusterName}'))`;
}

exports.insert_history_exservice = function(clusterName, serviceName, status, date, msg){
  return `INSERT INTO history_external_service (exservice_status, exservice_date, exservice_message, cluster_id, exservice_id) VALUES ('${status}',STR_TO_DATE('${date}', '%d-%m-%Y, %H:%i:%s'), '${msg}', (SELECT cluster_id FROM cluster WHERE cluster_name='${clusterName}'), (SELECT exservice_id FROM external_service WHERE exservice_name='${serviceName}'))`;
}

exports.select_history_services = function(clusterName){
  //return `SELECT cluster_name, service_name, service_status, service_message, service_date from history_service, service, cluster where cluster.cluster_id = service.cluster_id and service.service_id = history_service.service_id and cluster_name = '${clusterName}' ORDER BY service_date DESC`;
  return `SELECT
  cluster_name,
  service_name,
  service_status,
  service_message,
  DATE_ADD(service_date, INTERVAL 2 HOUR) AS service_date
FROM
  history_service hs
  INNER JOIN service s ON hs.service_id = s.service_id
  INNER JOIN cluster c ON s.cluster_id = c.cluster_id
WHERE
  cluster_name = '${clusterName}'
UNION
SELECT
  cluster_name,
  exservice_name AS service_name,
  exservice_status AS service_status,
  exservice_message AS service_message,
  DATE_ADD(exservice_date, INTERVAL 2 HOUR) AS service_date
FROM
  history_external_service hes
  INNER JOIN has_external_service hes1 ON hes.exservice_id = hes1.exservice_id AND hes.cluster_id = hes1.cluster_id
  INNER JOIN external_service es ON hes.exservice_id = es.exservice_id
  INNER JOIN cluster c ON hes1.cluster_id = c.cluster_id
WHERE
  cluster_name = '${clusterName}'
ORDER BY service_date DESC;`;
}


exports.insert_component = function(clusterName, serviceName,componentName){
  return `INSERT INTO component (component_name, service_id) VALUES ('${componentName}',(SELECT service_id FROM service s, cluster c WHERE service_name = '${serviceName}' AND s.cluster_id = c.cluster_id AND cluster_name = '${clusterName}'))`;
}

exports.select_exist_component = function(clusterName, serviceName, componentName){
  return `SELECT COUNT(*) as exist FROM service s, component cmp, cluster clt WHERE clt.cluster_id = s.cluster_id AND cmp.service_id = s.service_id AND service_name='${serviceName}' AND cluster_name='${clusterName}' AND component_name = '${componentName}'`;
}

exports.insert_history_component = function(clusterName, serviceName, componentName, status, statusMsg, msg, date){
  return `INSERT INTO history_component (component_status, component_status_msg, component_msg, component_date, component_id) VALUES ('${status}','${statusMsg}','${msg}',STR_TO_DATE('${date}', '%d-%m-%Y, %H:%i:%s'),(SELECT component_id FROM service s, component cmp, cluster clt WHERE component_name='${componentName}' AND cmp.service_id = s.service_id AND service_name = '${serviceName}' AND cluster_name = '${clusterName}' AND clt.cluster_id = s.cluster_id))`;
}

exports.insert_history_excomponent = function(clusterName, serviceName, componentName, status, statusMsg, msg, date){
  return `INSERT INTO history_external_component (excomponent_status, excomponent_status_msg, excomponent_msg, excomponent_date, cluster_id, excomponent_id) VALUES ('${status}','${statusMsg}','${msg}',STR_TO_DATE('${date}', '%d-%m-%Y, %H:%i:%s'),(SELECT cluster_id FROM cluster WHERE cluster_name = '${clusterName}'),(SELECT excomponent_id FROM external_service s, external_component cmp, cluster clt, has_external_service h WHERE excomponent_name='${componentName}' AND cmp.exservice_id = s.exservice_id AND exservice_name = '${serviceName}' AND cluster_name = '${clusterName}' AND clt.cluster_id = h.cluster_id AND s.exservice_id = h.exservice_id))`;
}

exports.select_history_component = function(clusterName,serviceName){
  return `SELECT cluster_name, service_name, component_name, component_status, component_status_msg, component_msg, DATE_ADD(component_date, INTERVAL 2 HOUR) AS component_date FROM cluster clt, service s, component cmp, history_component h WHERE h.component_id = cmp.component_id AND cluster_name = '${clusterName}' AND service_name ='${serviceName}' and s.service_id = cmp.service_id AND s.cluster_id = clt.cluster_id ORDER BY component_date DESC`;
}

exports.select_history_excomponent = function(clusterName,serviceName){
  return `SELECT cluster_name, exservice_name as service_name, excomponent_name as component_name, excomponent_status as component_status, excomponent_status_msg as component_status_msg, excomponent_msg as component_msg, DATE_ADD(excomponent_date, INTERVAL 2 HOUR) component_date FROM cluster clt, external_service s, external_component cmp, has_external_service hes, history_external_component hec WHERE clt.cluster_id = hes.cluster_id AND s.exservice_id = hes.exservice_id AND s.exservice_id = cmp.exservice_id AND cmp.excomponent_id = hec.excomponent_id AND cluster_name = '${clusterName}' AND exservice_name ='${serviceName}' AND clt.cluster_id = hec.cluster_id ORDER BY component_date DESC`;
}

exports.select_cluster_external_services = function(clusterName){
  return `SELECT cluster_name, exservice_name, s.exservice_id FROM external_service s, cluster c, has_external_service h WHERE h.cluster_id = c.cluster_id and cluster_name ='${clusterName}'`;
}

exports.select_cluster_an_external_service = function(clusterName,externalService){
  return `SELECT cluster_name, exurl_host, excomponent_name, exservice_name, s.exservice_id, exservice_threshold FROM external_url u, external_service s, external_component c, cluster WHERE  u.cluster_id = cluster.cluster_id and  u.excomponent_id = c.excomponent_id AND s.exservice_id = c.exservice_id AND cluster_name = '${clusterName}' AND exservice_name = '${externalService}'`;
}

exports.select_info_external_services = `SELECT cluster_name, exservice_name, excomponent_name, exurl_host, exservice_threshold FROM cluster c, external_service es, external_url eu, external_component ec, has_external_service hes WHERE c.cluster_id = eu.cluster_id AND eu.excomponent_id = ec.excomponent_id AND ec.exservice_id = es.exservice_id AND hes.cluster_id = c.cluster_id AND hes.exservice_id = es.exservice_id ORDER BY excomponent_name`;

exports.update_threshold_external_service = function(externalServiceName,newThreshold){
  return `UPDATE external_service SET exservice_threshold = '${newThreshold}' where exservice_name = '${externalServiceName}'`;
}

exports.update_url_external_service = function(oldUrl,newUrl,cmp,clt){
  return ` UPDATE external_url SET exurl_host = '${newUrl}' WHERE exurl_host = '${oldUrl}' and cluster_id = (SELECT cluster_id FROM cluster WHERE cluster_name = '${clt}') and excomponent_id = (SELECT excomponent_id FROM external_component WHERE excomponent_name = '${cmp}')`;
}

exports.insert_url_external_servie = function(clusterName,exserviceName,excomponentName,url){
  return ` INSERT INTO external_url (exurl_host,cluster_id, excomponent_id) VALUES ('${url}',(SELECT cluster_id FROM cluster WHERE cluster_name ='${clusterName}'),(SELECT excomponent_id FROM external_component ec, external_service es WHERE excomponent_name = '${excomponentName}' AND ec.exservice_id = es.exservice_id AND exservice_name = '${exserviceName}'))`;
}

exports.delete_url_external_service = function(exUrl,cmp,clt){
  return `DELETE FROM external_url WHERE exurl_host = '${exUrl}' and cluster_id = (SELECT cluster_id FROM cluster WHERE cluster_name = '${clt}') and excomponent_id = (SELECT excomponent_id FROM external_component WHERE excomponent_name = '${cmp}')`;
}

exports.select_components_external_service = function(exserviceName){
  return `SELECT excomponent_name FROM external_component c, external_service s WHERE s.exservice_id = c.exservice_id AND exservice_name='${exserviceName}'`;
}

exports.link_cluster_external_service = function(clusterName,exserviceName){
  return `INSERT INTO has_external_service VALUES ((SELECT cluster_id FROM cluster WHERE cluster_name='${clusterName}'),(SELECT exservice_id FROM external_service WHERE exservice_name='${exserviceName}'))`;
}

exports.select_user = 
    'SELECT username, role_name FROM user_account u, role r, has_role h WHERE u.user_id = h.user_id AND r.role_id = h.role_id';

exports.select_username_password = function(username){
  return `SELECT * FROM user_account u, role r, has_role h WHERE username = '${username}' AND u.user_id = h.user_id AND r.role_id = h.role_id `;
}

exports.insert_user = function(username,pwd){
  return `INSERT INTO user_account (username,password) VALUES ('${username}','${pwd}')`;
}

exports.insert_has_role = function(username,role){
  return `INSERT INTO has_role VALUES ((SELECT user_id FROM user_account WHERE username = '${username}'
  ), ${role});`;
}

exports.delete_has_role = function(username){
  return `DELETE FROM has_role WHERE user_id = (SELECT user_id FROM user_account WHERE username = '${username}')`;
}

exports.delete_user_account = function(username){
  return `DELETE FROM user_account WHERE username = '${username}'`;
}

exports.update_password_user = function(username,newpwd){
  return `UPDATE user_account SET password='${newpwd}' WHERE username ='${username}'`;
}

exports.select_refresh_time = 
  'SELECT refresh_time FROM settings_time';

exports.update_refresh_time = function(newTime){
  return `UPDATE settings_time SET refresh_time = '${newTime}'`;
}

exports.select_mail = 
  'SELECT mail FROM mail';

exports.delete_mail = function(mail){
  return `DELETE FROM mail WHERE mail = '${mail}'`;
}

exports.insert_mail = function(mail){
  return `INSERT INTO mail (mail) VALUES ('${mail}')`;
}