exports.urlHostAmbari = 'https://10.102.11.76:8083/api/v1/clusters/tle/hosts?fields=Hosts/host_status';
//exports.urlTestAmbari = 'https://10.102.11.76:8083//api/v1/clusters/tle/hosts?fields=Hosts/host_status';
exports.urlServiceAmbari = 'https://10.102.11.76:8083/api/v1/clusters/tle/services?fields=ServiceInfo/state';
exports.urlComponentAmbari = function(servicename) {
    return `https://10.102.11.76:8083/api/v1/clusters/tle/services/${servicename}/components?fields=ServiceComponentInfo/state`;
  };
exports.urlMsgAmbari = function(servicename) {
    return `https://tle-vhm003.data.tle:8083/api/v1/clusters/tle/services/${servicename}/alerts?Alert/state.in(CRITICAL,WARNING,OK)&fields=Alert/component_name,Alert/text,Alert/label`;
}
exports.userTestAmbari = 'admin';
exports.pwdTestAmbari = 'admin';

exports.urlHostCM = 'https://10.235.81.20/api/v51/clusters/cdpedh/hosts?view=FULL_WITH_HEALTH_CHECK_EXPLANATION';
exports.urlServiceCM = 'https://10.235.81.20/api/v51/clusters/cdpedh/services?view=FULL_WITH_HEALTH_CHECK_EXPLANATION';
exports.urlComponentCM = function(servicename) {
    return `https://10.235.81.20/api/v51/clusters/cdpedh/services/${servicename}/roles`;
  };
exports.urlMsgCM = function(servicename) {
    return `https://10.235.81.20/api/v51/clusters/cdpedh/services/${servicename}?view=FULL_WITH_HEALTH_CHECK_EXPLANATION`;
};
exports.userTestCM = 'admin';
exports.pwdTestCM = 'admin';

// https://{addressIP}/{endpoint}/clusters/{clusterName}/hosts?fields=Hosts/host_status
//  https://{addressIP}/{endpoint}/clusters/{clusterName}/services/{serviceName}/alerts?Alert/state.in(CRITICAL,WARNING,OK)&fields=Alert/component_name,Alert/text,Alert/label
// https://{addressIP}/{endpoint}/clusters/{clusterName}/services/{serviceName}/components?fields=ServiceComponentInfo/state
// https://{addressIP}/{endpoint}/clusters/{clusterName}/services?fields=ServiceInfo/state

// https://{addressIP}/{endpoint}/clusters/{clusterName}/hosts?view=FULL_WITH_HEALTH_CHECK_EXPLANATION
// https://{addressIP}/{endpoint}/clusters/{clusterName}/services?view=FULL_WITH_HEALTH_CHECK_EXPLANATION
// https://{addressIP}/{endpoint}/clusters/{clusterName}/services/{serviceName}/roles
// https://{addressIP}/{endpoint}/clusters/{clusterName}/services/{serviceName}?view=FULL_WITH_HEALTH_CHECK_EXPLANATION