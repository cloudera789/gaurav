const PROD_MODE = false; //change here

const PORT_SERVER = 3000;
const HOST_SERVER = 'localhost';
const HOST_DATABASE = 'localhost';
const USER_DATABASE = 'root';
const PASSWORD_DATABASE = PROD_MODE ? '?Adminadmin2' : '?Adminadmin2';
const DATABASE = 'dataeye';
const TOKEN_DURATION = '7h';
const MAIL_SERVER = PROD_MODE ? '10.71.4.166' : '10.98.78.70';
const MAIL_PORT = 25;


module.exports = {
    PROD_MODE,
    PORT_SERVER,
    HOST_SERVER,
    HOST_DATABASE,
    USER_DATABASE,
    PASSWORD_DATABASE,
    DATABASE,
    TOKEN_DURATION,
    MAIL_SERVER,
    MAIL_PORT
};
