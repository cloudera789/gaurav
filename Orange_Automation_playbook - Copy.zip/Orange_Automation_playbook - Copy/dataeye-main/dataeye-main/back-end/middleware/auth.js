const jwt = require('jsonwebtoken');
 
exports.authenticateToken = (req, res, next) => {
   try {
       const authHeader = req.headers.authorization;

       if (!authHeader) {
           return res.status(401).json({ error: 'Unauthorized: Missing Authorization Header' });
       }

       const token = authHeader.split(' ')[1];
       const decodedToken = jwt.verify(token, 'RANDOM_TOKEN_SECRET');
       const userId = decodedToken.userId;
       req.auth = {
           userId: userId
       };
       next();
   } catch(error) {
       console.error(error);
       res.status(401).json({ error: 'Unauthorized' });
   }
};


exports.authorizeSuperUser = (req, res, next) => {
    const userRole = req.body.roleId;
    //console.log(userRole);
    if(userRole == "2" || userRole == "1") next();
    else res.status(403).json({ error : 'You do not have permission' });
}

exports.authorizeAdmin = (req, res, next) => {
    const userRole = req.params.roleId;
    if(userRole == 1) next();
    else res.status(403).json({ error : 'You do not have permission' });
}

//same with authorizeSuperUser but get roleId from URL not from body
exports.authorizeSuperUserForDel = (req, res, next) => {
    const userRole = req.params.roleId;
    //console.log(userRole);
    if(userRole == "2" || userRole == "1") next();
    else res.status(403).json({ error : 'You do not have permission' });
}