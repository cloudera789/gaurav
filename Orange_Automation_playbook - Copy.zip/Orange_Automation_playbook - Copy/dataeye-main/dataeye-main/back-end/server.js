const http = require('http');

const app = require('./app');

const config = require('./config/env.config');

const ctrl = require('./services/autoCall');

app.set('port', config.PORT_SERVER);
const server = http.createServer(app);

var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
    host: config.MAIL_SERVER, 
    port: config.MAIL_PORT,
    secure: false, // dont Use SSL/TLS
    ignoreTLS : true
});

let oldMsg = "";


//AUTO CALL PART
async function fetchData() {
  try {
    let newMsg= ""; //newMsg for one time per day from 8h to 9h
    let newMsgRegular = ""; //newMsgRegular for msg when we call autoCall 
    const resClt = await ctrl.getClusters();
    for(const clt of resClt){
      if(clt.status !== 'GREEN'){
        newMsgRegular += clt.infoHosts+'. Status : '+clt.status+'\n';
      }
    }
    //console.log(resClt);
    let listClusterName = resClt.map( (elt) => elt.clusterName);
    //console.log(listClusterName);
    for(const clt of listClusterName) {
        //******NORMAL SERVICES**************//
        let resSer =await ctrl.getServices(clt);
        //console.log(resSer);
        //let listServiceName = resSer.map( (elt) => elt.serviceName);
        //console.log(clt+' '+listServiceName);
        for(const serviceInfo of resSer){
            let resCmp = await ctrl.getComponents(clt,serviceInfo.serviceName);
            
            //console.log(listComponentName);
            let resCmpCopy = []; //we reduce list component name
            //Process for CM cluster
            for(const cmp of resCmp){
              const c = resCmpCopy.find(((lc) => lc.componentName == cmp.componentName ));
              if(c){  //if find c exists already in resCmpCopy and if it has property host_name means CM cluster, we just need add msg in to this cmp
                //console.log("find c in listComponentName");
                if(cmp.hasOwnProperty('hostName')){
                  //console.log("cmp has hostname");
                  if (cmp['statusMsg'].includes('CONCERNING')) { 
                    c.status = 'orange'; 
                    c.statusMsg = cmp['statusMsg']; 
                    newMsg += "\n- "+clt+"/"+serviceInfo.serviceName+"/"+cmp.componentName + ' : '+cmp.hostName+' is '+cmp.statusMsg;
                  }else{
                    if (cmp['statusMsg'].includes('BAD')) { 
                      c.status = 'red'; c.statusMsg = cmp['statusMsg'];
                      newMsg += "\n- "+clt+"/"+serviceInfo.serviceName+"/"+cmp.componentName + ' : '+cmp.hostName+' is '+cmp.statusMsg;
                    }
                  };
                  if(c.hasOwnProperty('msg')){
                    //console.log("cmp has msg");
                    c.msg += "/endMsg/" + cmp.componentName + ' in '+cmp.hostName+' : '+cmp.statusMsg;
                    
                  }else{
                    //console.log("c has no msg");
                    c.msg = cmp.componentName + ' in '+cmp.hostName+' : '+cmp.statusMsg;
                  }
                }              
              }else{
                if(cmp.hasOwnProperty('hostName')) cmp.msg = cmp.componentName + ' in '+cmp.hostName+' : '+cmp.statusMsg;
                else cmp.msg = "";
                resCmpCopy.push(cmp);
                //console.log(cmp);
              }
            }
            //console.log(clt+' '+serviceInfo.serviceName);
            //console.log(resCmp);
            
            let resMsg = await ctrl.getMsg(clt,serviceInfo.serviceName);
            for(const msg of resMsg){    
              const cmp = resCmpCopy.find((cmp) => cmp.componentName == msg.componentName);
              //console.log(cmp);
              if (cmp) {
                //console.log("It has component aleready");
                if (cmp.hasOwnProperty('msg')) {
                  cmp.msg += "/endMsg/" + msg.message.replaceAll("'", " ");
                } else {
                  cmp.msg = msg.message.replaceAll("'", " ");
                }
              } else {
                //console.log("It has NOT component aleready");
                const supCmp = resCmp.find((cmp) => cmp.componentName == 'Additional information');
                if (supCmp){
                  supCmp.msg += "/endMsg/" + msg.message.replaceAll("'", " ");
                }else{
                  resCmpCopy.push({
                    "clusterName" : clt,
                    "serviceName" : serviceInfo.serviceName,
                    "componentName" : "Additional information",
                    "status" : "GREY",
                    "statusMsg" : "",
                    "date" : new Date().toLocaleString('jw-FR'),
                    "msg" : msg.message
                  })
                }    
                //console.log(cmp);
                //console.log(msg);
                // Handle the case when a matching component is not found in resCmp
                //create a component "" and add it to resCmp here.
              }

              //for mail
              if (msg.message.includes("BAD") || msg.message.includes("CRITICAL") || msg.message.includes("CONCERNING") || msg.message.includes("WARNING")){
                newMsg += "\n- "+clt+"/"+serviceInfo.serviceName+"/"+msg.componentName + ' : ' +msg.message;
                
              }

            };
            //console.log("cmp final");
            //console.log(resCmp);
            for(const cmp of resCmpCopy){
                if(typeof cmp.msg === 'string'){if ( (cmp.msg.includes('BAD') || cmp.msg.includes('CRITICAL'))) {
                  cmp.status = "RED";
                  newMsgRegular +="\n- "+clt+"/"+serviceInfo.serviceName+"/"+cmp.componentName + ' : '+cmp.status;

                } else {
                  if ( (cmp.msg.includes('CONCERNING') || cmp.msg.includes('WARNING'))) {
                    cmp.status = "ORANGE";
                    newMsgRegular +="\n- "+clt+"/"+serviceInfo.serviceName+"/"+cmp.componentName + ' : '+cmp.status;
                  } 
                }}              
              }
            ;
            //console.log(resCmp);

            ctrl.addComponent(resCmpCopy);
            for (const item of resCmpCopy) {
              //console.log(item.status);
              if (item.status === "RED") {
                serviceInfo.status = "RED";
                break; // Exit the loop early if red is found
              } else if (item.status === "ORANGE") {
                serviceInfo.status = "ORANGE";
                //console.log(serviceInfo.serviceName);
                break;
                
              } 
            }
            //console.log("fin loop");
            //console.log(serviceInfo.status);
            
          }
        ;
        //console.log(resSer);
        await ctrl.addServiceHistory(resSer);
        
        //******EXTERNAL SERVICES**************//
        let listExSer = await ctrl.getExternalServices(clt);
        for(const e of listExSer){
          let exSer = await ctrl.getAnExternalService(clt,e.exservice_name);
          //console.log(exSer);
          let exCmpCopy = []; //we reduce list component name
          //Process for CM cluster
          for(const cmp of exSer.components){
            const c = exCmpCopy.find(((lc) => lc.componentName == cmp.componentName ));
            if(c){  //if find c exists already in exCmpCopy and if it has property host_name means CM cluster, we just need add msg in to this cmp
              //console.log("find c in listComponentName");
              if(cmp.hasOwnProperty('hostName')){
                //console.log("cmp has hostname");
                if (cmp['status'] =='RED') { 
                  c.status = 'red'; 
                  c.statusMsg = cmp['statusMsg']; 
                  newMsg += "\n- "+clt+"/"+serviceInfo.serviceName+"/"+cmp.componentName + ' : ' +cmp.hostName+' is '+cmp.statusMsg;
                  newMsgRegular +="\n- "+clt+"/"+serviceInfo.serviceName+"/"+cmp.componentName + ' : ' +cmp.hostName+' is '+cmp.statusMsg;
                } 
                if(c.hasOwnProperty('msg')){
                  //console.log("cmp has msg");
                  c.msg += "/endMsg/" + cmp.componentName + ' in '+cmp.hostName+' : '+cmp.statusMsg;
                }else{
                  //console.log("c has no msg");
                  c.msg = cmp.componentName + ' in '+cmp.hostName+' : '+cmp.statusMsg;
                }
              }              
            }else{
              if(cmp.hasOwnProperty('hostName')) cmp.msg = cmp.componentName + ' in '+cmp.hostName+' : '+cmp.statusMsg;
              else cmp.msg = "";
              cmp.clusterName = clt;
              cmp.serviceName = exSer.externalServiceName;
              cmp.date = exSer.date;
              if (cmp.status == "GREEN") cmp.status = 'green';
              if (cmp.status == 'RED') {
                cmp.status = 'red';
                newMsg += "\n- "+clt+"/"+e.exservice_name+"/"+cmp.componentName + ' : ' +cmp.hostName+' is '+cmp.statusMsg;
                newMsgRegular += "\n- "+clt+"/"+e.exservice_name+"/"+cmp.componentName + ' : ' +cmp.hostName+' is '+cmp.statusMsg;
              }
              exCmpCopy.push(cmp);
              //console.log(cmp);
            }
          }
          //console.log(exCmpCopy);
          await ctrl.addExternalComponent(exCmpCopy);
          
        }
        //console.log(listExSer);
        newMsg+="\n\n";
      }
      ;
    console.log(`[${new Date().toLocaleString('jw-FR')}] Call API automatically`);

    // console.log("Old Msg : "+oldMsg);
    // console.log("New Msg : "+newMsg);
    // //FOR MAIL
      // Get the current date and time
    const currentDate = new Date();
    // Create two Date objects for 8 AM and 9 AM
    const eightAM = new Date();
    eightAM.setHours(8, 0, 0, 0);
    const nineAM = new Date();
    nineAM.setHours(9, 0, 0, 0);
    //console.log(currentDate+" ; Hour interval : "+eightAM+" - "+nineAM);
    // Check if the current time is after 8 AM and before 9 AM
    if (currentDate >= eightAM && currentDate < nineAM){ sendEmail(newMsg);
    }else{
      if(oldMsg !== newMsgRegular) {
        sendEmail(newMsgRegular);
        oldMsg = newMsgRegular;
      }
    }
    
  } catch (error) {
    console.error('Error fetching data:', error);
  }
}

let intervalMs = 1000 * 60 * 60;
//console.log("valeur pris : "+intervalMs);

// // Function to check and update the interval
async function updateInterval() {
  let newInterval = await ctrl.getRefreshTime();
  //console.log("Old interval : "+intervalMs+", newInterval : "+newInterval);
  if(newInterval == 0) clearInterval(intervalHandler);
  if (newInterval !== intervalMs) {
    console.log(`[${new Date().toLocaleString('jw-FR')}] "Changed refresh time. Restart loop with new refresh time"`);
    intervalMs = newInterval;
    
    clearInterval(intervalHandler);
    intervalHandler = setInterval(fetchData, intervalMs);
  }
}

// Set an initial interval and start fetching data
intervalHandler = setInterval(fetchData, intervalMs);

// Periodically check for changes in conf.INTERVAL
setInterval(updateInterval, 1000*30);

//let intervalMs = 1 * 20 * 1000;
//setInterval(fetchData,intervalMs);

//END AUTO CALL

async function sendEmail(newMsg){
  let list = await ctrl.getMail();
  var mailOptions = {
    from: 'noreply@gmessaging.net', 
    to: list,
    subject: 'Alert from DataEye',
    text: newMsg
  };

  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
    console.log(error);
    } else {
    console.log('Email sent: ' + info.response);
    }
  }); 
} ;




server.listen(config.PORT_SERVER, () => {
  console.log("Listening on port "+config.PORT_SERVER);
});