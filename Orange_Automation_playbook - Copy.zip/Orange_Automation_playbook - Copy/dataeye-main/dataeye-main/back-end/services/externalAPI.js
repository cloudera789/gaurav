const config = require('../config/env.config');
const PROD_MODE = config.PROD_MODE;
exports.callClusterAmbari = function(urlClt, userClt, pwdClt, thresClt, projectsClt, callback){
    const request = require('request');
    const options = PROD_MODE ?
    {
      url: urlClt,
      rejectUnauthorized: false,
      auth: {
          user: userClt,
          password: pwdClt
      },
      timeout: 270000
    } : //using dev mode
    {
        url: urlClt,
        proxy: 'socks5://127.0.0.1:8118', //require privoxy
        rejectUnauthorized: false,
        auth: {
            user: userClt,
            password: pwdClt
        },
        timeout: 270000 
    };
    
  try{ 
    request.get(options, (error, response, body) => {
    if (error) {
    console.error(error);
    callback(error, null); // Invoke callback with error parameter
    } else {
    const json = JSON.parse(body);

    var nbHealthyHost = json['items'].length;
    var nbUnhealthyHost = 0;
    for (const item of json['items']) {
        if (item['Hosts']['host_status'] == 'UNHEALTHY') { nbHealthyHost -= 1; nbUnhealthyHost+=1;}
    }
    //need to modify 
    ////console.log(json['items'][0]['Hosts']['cluster_name']+' : '+nbUnhealthyHost + ' unhealthy host(s) in ' + json['items'].length + ' hosts');
    var statusCluster = '';
    if (nbHealthyHost == json['items'].length) statusCluster = 'GREEN';
    else if (nbHealthyHost >= json['items'].length * (thresClt/100)) statusCluster = 'ORANGE';
    else statusCluster = 'RED';

    body = { 
        clusterName : json['items'][0]['Hosts']['cluster_name'],
        projects : projectsClt,
        type : 1, 
        status : statusCluster,
        date : new Date().toLocaleString('jw-FR'),
        infoHosts : json['items'][0]['Hosts']['cluster_name']+' : '+nbUnhealthyHost + ' unhealthy host(s) in ' + json['items'].length + ' hosts'
    };
        // '{ projectName : ' + projectNameClt + ', clusterName : ' + json['items'][0]['clusterRef']['clusterName'] + ', status : ' + statusCluster + ' }';
    
    ////console.log('Call Ambari cluster');
    callback(null, body); // Invoke callback with body parameter
    }
    });
  }catch(e){
      console.error('Error occurred during request:', e);
      callback(e, null); // Invoke callback with error parameter
  };
};

exports.callClusterCM = function(urlClt, userClt, pwdClt, thresClt, projectsClt, callback) {
    const request = require('request');
    const options = {
        url: urlClt,
        rejectUnauthorized: false,
        auth: {
            user: userClt,
            password: pwdClt
        },
        timeout: 270000
        
    };
    
    try{
      request.get(options, (error, response, body) => {
        if (error) {
        console.error(error);
        callback(error, null); // Invoke callback with error parameter
        } else {
        const json = JSON.parse(body);

        var nbHealthyHost = 0;
        for (const item of json['items']) {
            if (item['healthSummary'] == 'GOOD') nbHealthyHost += 1;
        }
        var nbUnhealthyHost = json['items'].length - nbHealthyHost;

        //console.log(json['items'][0]['clusterRef']['clusterName']+' : '+nbUnhealthyHost + ' unhealthy host(s) in ' + json['items'].length + ' hosts');
        var statusCluster = '';
        if (nbHealthyHost == json['items'].length) statusCluster = 'GREEN';
        else if (nbHealthyHost >= json['items'].length * (thresClt/100)) statusCluster = 'ORANGE';
        else statusCluster = 'RED';

        body = { 
            clusterName : json['items'][0]['clusterRef']['clusterName'], 
            projects : projectsClt,
            type : 2,
            status : statusCluster,
            date : new Date().toLocaleString('jw-FR'),
            infoHosts : json['items'][0]['clusterRef']['clusterName']+' : '+nbUnhealthyHost + ' unhealthy host(s) in ' + json['items'].length + ' hosts'
        };
           // '{ projectName : ' + projectNameClt + ', clusterName : ' + json['items'][0]['clusterRef']['clusterName'] + ', status : ' + statusCluster + ' }';
        
        //console.log('Called CM cluster');
        callback(null, body); // Invoke callback with body parameter
        }
      });
    }catch(e){
      console.error('Error occurred during request:', e);
      callback(e, null); // Invoke callback with error parameter
  }
};

exports.callServiceAmbari = function(urlService, nameClt, userClt, pwdClt, callback) {
  const request = require('request');
    const options = PROD_MODE ?
    {
      url: urlService,
      rejectUnauthorized: false,
      auth: {
          user: userClt,
          password: pwdClt
      },
      timeout: 270000
    } : //using dev mode
    { 
      url: urlService,
      proxy: 'socks5://127.0.0.1:8118', //require privoxy
      rejectUnauthorized: false,
      auth: {
        user: userClt,
        password: pwdClt
      },
      timeout: 270000
    };

    request.get(options, (error, response, body) => {
      if (error) {
        console.error(error);
        callback(error, null); // Invoke callback with error parameter
      } else {
        const json = JSON.parse(body);
        concat = [];
        for(const item of json['items']){
            var statusService = '';
            if(item['ServiceInfo']['state'] == 'STARTED') statusService = 'GREEN';
            else{
              if(item['ServiceInfo']['state'] == 'INSTALLED' || item['ServiceInfo']['state'] == 'INSTALLED') statusService = 'GREY';
              else statusService = 'RED';
            };
            concat.push({
              clusterName : nameClt,
              serviceName : item['ServiceInfo']['service_name'],
              status : statusService,
              message : item['ServiceInfo']['state'],
              date : new Date().toLocaleString('jw-FR')
            })
        }
        
        //console.log('Called ambari services ');
        callback(null, concat); // Invoke callback with body parameter
      }
    });
};

exports.callServiceCM = function(urlService, nameClt, userClt, pwdClt, callback) {
  const request = require('request');
  const options = {
      url: urlService,
      rejectUnauthorized: false,
      auth: {
          user: userClt,
          password: pwdClt
      },
      timeout: 270000
  };
  request.get(options, (error, response, body) => {
    if (error) {
      console.error(error);
      callback(error, null); // Invoke callback with error parameter
    } else {
      const json = JSON.parse(body);
      concat = [];
      for(const item of json['items']){
          var statusService = '';
          if(item['healthSummary'] == 'GOOD') statusService = 'GREEN';
          else{
            if(item['healthSummary'] == 'CONCERNING' || item['healthSummary'] == 'DISABLE') statusService = 'ORANGE';
            else{
              if(item['healthSummary'] == 'BAD') statusService = 'RED';
              else statusService = 'GREY';
            }
          };
          concat.push({
            clusterName : nameClt,
            serviceName : item['name'],
            status : statusService,
            message : item['serviceState']+' - '+item['healthSummary'],
            date : new Date().toLocaleString('jw-FR')
          })
      }
      //console.log('Call CM services');
      callback(null, concat); // Invoke callback with body parameter
    }
  });
};
  
exports.callComponentAmbari = function(urlComponent, nameClt, userClt, pwdClt, callback) {
  const request = require('request');
    const options = PROD_MODE ?
    {
      url: urlComponent,
      rejectUnauthorized: false,
      auth: {
          user: userClt,
          password: pwdClt
      },
      timeout: 270000 
    } :
    {
      url: urlComponent,
      proxy: 'socks5://localhost:8118', //require privoxy
      rejectUnauthorized: false,
      auth: {
        user: userClt,
        password: pwdClt
      },
      timeout: 270000
    };

    request.get(options, (error, response, body) => {
      if (error) {
        console.error(error);
        callback(error, null); // Invoke callback with error parameter
      } else {
        const json = JSON.parse(body);
        concat = [];
        for(const item of json['items']){
            // //console.log(item['ServiceInfo']['service_name']);
            // //console.log(item['ServiceInfo']['state']);
            var statusComponent = '';
            if(item['ServiceComponentInfo']['state'] == 'STARTED') statusComponent = 'GREEN';
            else{
              if(item['ServiceComponentInfo']['state'] == 'INSTALLED' || item['ServiceComponentInfo']['state'] == 'DISABLED') statusComponent = 'GREY';
              else statusComponent = 'RED';
            };
            concat.push({
              clusterName : nameClt,
              serviceName : item['ServiceComponentInfo']['service_name'],
              componentName : item['ServiceComponentInfo']['component_name'],
              status : statusComponent,
              statusMsg : item['ServiceComponentInfo']['state'],
              date : new Date().toLocaleString('jw-FR')
            })
        }
        //console.log('Call ambari componants');
        callback(null, concat); // Invoke callback with body parameter
       
      }
    });
};

exports.callComponentCM = function(urlComponent, nameClt, userClt, pwdClt, callback) {
  const request = require('request');
  const options = {
      url: urlComponent,
      rejectUnauthorized: false,
      auth: {
          user: userClt,
          password: pwdClt
      },
      timeout: 270000
  };
  request.get(options, (error, response, body) => {
    if (error) {
      console.error(error);
      callback(error, null); // Invoke callback with error parameter
    } else {
      const json = JSON.parse(body);
      concat = [];
      for(const item of json['items']){
          var statusComponent = '';
          if(item['healthSummary'] == 'GOOD') statusComponent = 'GREEN';
          else{
            if(item['healthSummary'] == 'CONCERNING') statusComponent = 'ORANGE';
            else{
              if(item['healthSummary'] == 'BAD') statusComponent = 'RED';
              else statusComponent = 'GREY';
            }
          };
          //compName = item['type'] + ' - ' +item['hostRef']['hostname'];
          concat.push({
            clusterName : nameClt,
            serviceName : item['serviceRef']['serviceName'],
            hostName : item['hostRef']['hostname'],
            componentName : item['type'],
            status : statusComponent,
            statusMsg : item['roleState']+' - '+item['healthSummary'],
            date : new Date().toLocaleString('jw-FR')
            
          })
      }
      ////console.log('Call CM services');
      callback(null, concat); // Invoke callback with body parameter
    }
  });
};

exports.callMsgAmbari = function(urlMsg, nameClt, userClt, pwdClt, callback) {
  const request = require('request');
    const options = PROD_MODE ?
    {
      url: urlMsg,
      rejectUnauthorized: false,
      auth: {
          user: userClt,
          password: pwdClt
      },
      timeout: 270000   
    } :
    {
      url: urlMsg,
      proxy: 'socks5://127.0.0.1:8118', //require privoxy
      rejectUnauthorized: false,
      auth: {
        user: userClt,
        password: pwdClt
      },
      timeout: 270000
    };

    request.get(options, (error, response, body) => {
      if (error) {
        console.error(error);
        callback(error, null); // Invoke callback with error parameter
      } else {
        const json = JSON.parse(body);
        concat = [];
        for(const item of json['items']){
            msg = item['Alert']['label'] +' : '+ item['Alert']['state']+' - ' + item['Alert']['text'];
            concat.push({
              clusterName : nameClt,
              serviceName : item['Alert']['service_name'],
              componentName : item['Alert']['component_name'],
              message : msg
            })
        };
        
        ////console.log('Get msg component of ambari service');
        callback(null, concat); // Invoke callback with body parameter
       
      }
    });
};

exports.callMsgCM = function(urlMsg, nameClt, userClt, pwdClt, callback) {
  const request = require('request');
  const options = {
      url: urlMsg,
      rejectUnauthorized: false,
      auth: {
          user: userClt,
          password: pwdClt
      },
      timeout: 270000
  };
  request.get(options, (error, response, body) => {
    if (error) {
      console.error(error);
      callback(error, null); // Invoke callback with error parameter
    } else {
      const json = JSON.parse(body);
      concat = [];
      servicename = body['name'];
      for(const item of json['healthChecks']){
        concat.push({
          clusterName : nameClt,
          serviceName : servicename,
          componentName : null,
          message : item['name']+' : '+item['summary']+ ' - ' +item['explanation']
        })
      };
      ////console.log('Call CM services');
      callback(null, concat); // Invoke callback with body parameter
    }
  });
};

exports.callExternalComponent = function(urlC, callback) {
  const request = require('request');
  const options = PROD_MODE ?
  {
    url: urlC,
    rejectUnauthorized: true,
    timeout: 270000
  } : //using dev mode
  {
    url: urlC,
    proxy: 'http://127.0.0.1:8118', //require privoxy
    rejectUnauthorized: true,
    timeout: 270000
  };
  request.get(options, (error, response, body) => {
      if (error) {
      console.error(error);
      callback(error, null); // Invoke callback with error parameter
      } else {    
      //const json = JSON.parse(body); 
      ////console.log('Called External Component');
      //////console.log(urlC+' '+body);
      callback(null, body); // Invoke callback with body parameter
      }
  });
};