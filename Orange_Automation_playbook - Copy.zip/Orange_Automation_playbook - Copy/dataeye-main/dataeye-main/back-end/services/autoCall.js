const queries = require('../models/queries');
const mysql = require('mysql2');
const externalApi = require('./externalAPI');
const config = require('../config/env.config');

const pool = mysql.createPool({
  connectionLimit: 10,
  host: config.HOST_DATABASE,
  user: config.USER_DATABASE,
  password: config.PASSWORD_DATABASE,
  database: config.DATABASE
});

exports.getClusters = async () => {
  return new Promise((resolve, reject) => {
    pool.getConnection((error, connection) => {
      if (error) {
        console.error('Error getting connection from pool:', error);
        reject(error);
      } else {
        connection.query(queries.select_clusters_type_project, async (error, results) => {
          if (error) {
            console.error('Error executing query:', error);
            connection.release();
            reject(error);
          } else {
            ////console.log("Call cluster type project");
            
            const combiendResults = Object.values(results.reduce((acc, obj) => {
              const { cluster_name, project_name, ...rest } = obj;
              if (!acc[cluster_name]) {
                acc[cluster_name] = { cluster_name, projects: [], ...rest };
              }
              acc[cluster_name].projects.push(project_name);
              return acc;
            }, {}));
            
            var combinedStr = [];
            
            const processResults = async () => {
              for (let result of combiendResults) {
                const url_host = result['url_host']
                  .replace('{addressIP}', result['cluster_adr'])
                  .replace('{clusterName}', result['cluster_name'])
                  .replace('{endpoint}', result['endpoint']);
                
                try {
                  if (result['url_id'] == 1) {
                    const str = await new Promise((resolve, reject) => 
                      externalApi.callClusterAmbari(url_host, result['cluster_user'], result['cluster_pwd'], result['cluster_threshold'], result['projects'], (error, str) => error ? reject(error) : resolve(str))
                    );
                    combinedStr.push(str); 
                  } else { //if not, it is cluster CM
                    const str = await new Promise((resolve, reject) => 
                      externalApi.callClusterCM(url_host, result['cluster_user'], result['cluster_pwd'], result['cluster_threshold'], result['projects'], (error, str) => error ? reject(error) : resolve(str))
                    );
                    combinedStr.push(str); 
                  }
                  connection.query(
                    queries.insert_history_cluster(combinedStr[combinedStr.length-1].clusterName, combinedStr[combinedStr.length-1].status, combinedStr[combinedStr.length-1].date),
                    (error) => {
                      if (error) {
                        console.error('Error executing query:', error);
                      } else {
                        ////console.log("Add history cluster");
                      }
                    }
                  );
                } catch (e) {
                  console.error(`Can't get status of cluster ${result['cluster_name']}`);
                  continue;
                }
              }
              
              // Release the connection back to the pool
              connection.release();
              resolve(combinedStr);
            };
            
            processResults().catch((error) => {
              connection.release();
              reject(error);
            });
          }
        });
      }
    });
  });
};
  
exports.getServices = (clustername) => {
  return new Promise((resolve, reject) => {
    pool.getConnection((error, connection) => {
      if (error) {
        console.error('Error getting connection from pool:', error);
        reject(error);
      } else {
        connection.query(queries.select_cluster_services(clustername), async (error, results) => {
          if (error) {
            console.error('Error executing query:', error);
            connection.release();
            reject(error);
          } else {
            const url_service = results[0]['url_service']
              .replace('{addressIP}', results[0]['cluster_adr'])
              .replace('{clusterName}', results[0]['cluster_name'])
              .replace('{endpoint}', results[0]['endpoint']);
            
            try {
              var str;
              switch (results[0]['url_id']) {
                case 1: //if cluster is ambari
                  str = await new Promise((resolve, reject) => 
                    externalApi.callServiceAmbari(url_service, clustername, results[0]['cluster_user'], results[0]['cluster_pwd'], (error, str) => error ? reject(error) : resolve(str))
                  );
                  break;
                case 2: //cluster CM
                  str = await new Promise((resolve, reject) => 
                    externalApi.callServiceCM(url_service, clustername, results[0]['cluster_user'], results[0]['cluster_pwd'], (error, str) => error ? reject(error) : resolve(str))
                  );
                  break;
                default:
                  reject(new Error('Invalid url_id'));
                  break;
              }
              connection.release();
              resolve(str);
            } catch (e) {
              console.error(`Can't get service information for cluster ${clustername}`);
              connection.release();
              reject(e);
            }
          }
        });
      }
    });
  });
};

exports.getComponents = (clustername, servicename) => {
  return new Promise((resolve, reject) =>{  
    pool.getConnection((error, connection) => {
      if (error) {
        console.error('Error getting connection from pool:', error);
        reject(error);
      } else {
        ////console.log('Got a connection from the pool!');
        // Execute a query
        connection.query(
          queries.select_cluster_components(clustername), 
          async (error, results) => {
          if (error) {
            console.error('Error executing query:', error);
            connection.release();
            reject(error);
          } else {
            ////console.log('Query results:', results);
            const url_component = results[0]['url_component']
                .replace('{addressIP}',results[0]['cluster_adr'])
                .replace('{clusterName}',results[0]['cluster_name'])
                .replace('{serviceName}',servicename)
                .replace('{endpoint}',results[0]['endpoint']);
            ////console.log(url_component);
            try{  
              var str;
              switch (results[0]['url_id']){
                case (1) : //if cluster is ambari
                  str = await new Promise((resolve, reject) => 
                      externalApi.callComponentAmbari(url_component,clustername, results[0]['cluster_user'],results[0]['cluster_pwd'], (error, str) => error ? reject(error) : resolve(str)));
                  break;
                case (2) : //cluster CM
                  str =  await new Promise((resolve, reject) => 
                      externalApi.callComponentCM(url_component,clustername, results[0]['cluster_user'],results[0]['cluster_pwd'], (error, str) => error ? reject(error) : resolve(str)));
                  break;
                default:
                  reject(new Error('Invalid url_id'));
                  break;
              }
              connection.release();
              resolve(str);
            } catch (e) {
              console.error(`Can't get service information for cluster ${clustername}`);
              connection.release();
              reject(e);
            }
          }
        });
      }
    });
  });
};

exports.getMsg = (clustername, servicename) => {

  return new Promise((resolve, reject) =>{   
    pool.getConnection((error, connection) => {
      if (error) {
        console.error('Error getting connection from pool:', error);
        reject(error);
      } else {
        ////console.log('Got a connection from the pool!');
        // Execute a query
        connection.query(
          queries.select_cluster_messages(clustername), 
          async (error, results) => {
          if (error) {
            console.error('Error executing query:', error);
            connection.release();
            reject(error);
          } else {
            ////console.log('Query results:', results);
            const url_msg = results[0]['url_message']
                .replace('{addressIP}',results[0]['cluster_adr'])
                .replace('{clusterName}',results[0]['cluster_name'])
                .replace('{serviceName}',servicename)
                .replace('{endpoint}',results[0]['endpoint']);
            ////console.log(url_msg);
            try{  
              var str;
              switch (results[0]['url_id']){
                case (1) : //if cluster is ambari
                  str = await new Promise((resolve, reject) => 
                      externalApi.callMsgAmbari(url_msg,clustername, results[0]['cluster_user'],results[0]['cluster_pwd'], (error, str) => error ? reject(error) : resolve(str)));
                  break;
                case (2) : //cluster CM
                  str =  await new Promise((resolve, reject) => 
                      externalApi.callMsgCM(url_msg,clustername, results[0]['cluster_user'],results[0]['cluster_pwd'], (error, str) => error ? reject(error) : resolve(str)));
                  break;
                default:
                  reject(new Error('Invalid url_id'));
                  break;
              }
              connection.release();
              resolve(str);
            }catch (e) {
            console.error(`Can't get service information for cluster ${clustername}`);
            connection.release();
            reject(e);
            }
          }
        });
      }
    });
  });
}

exports.addComponent = (requestData) => {
  return new Promise((resolve, reject) => {
    pool.getConnection((error, connection) => {
      if (error) {
        console.error('Error getting connection from pool:', error);
        reject(error);
      } else {
        const promises = [];

        for (let elt of requestData) {
          const clusterName = elt.clusterName;
          const componentName = elt.componentName;
          const serviceName = elt.serviceName;
          const status = elt.status == 'GREEN' ? 'green' : elt.status == 'ORANGE' ? 'orange' : elt.status == 'RED' ? 'red' : 'grey';
          const statusMsg = elt.statusMsg;
          const msg = elt.msg;
          const date = elt.date;

          const selectQuery = queries.select_exist_component(clusterName, serviceName, componentName);
          const insertComponentQuery = queries.insert_component(clusterName, serviceName, componentName);
          const insertHistoryQuery = queries.insert_history_component(clusterName, serviceName, componentName, status, statusMsg, msg, date);

          promises.push(
            new Promise((innerResolve, innerReject) => {
              connection.query(selectQuery, (error, results) => {
                if (error) {
                  console.error('Error executing query:', error);
                  innerReject(error);
                } else {
                  if (results[0].exist == 0) {
                    connection.query(insertComponentQuery, (error) => {
                      if (error) {
                        console.error('Error executing query:', error);
                        innerReject(error);
                      } else {
                        ////console.log('Add new component');
                        innerResolve();
                      }
                    });
                  } else {
                    connection.query(insertHistoryQuery, (error) => {
                      if (error) {
                        console.error('Error executing query:', error);
                        innerReject(error);
                      } else {
                        ////console.log('Add new history');
                        innerResolve();
                      }
                    });
                  }
                }
              });
            })
          );

        }

        Promise.all(promises)
          .then(() => {
            connection.release();
            resolve({ message: 'Added new history component' });
          })
          .catch((error) => {
            connection.release();
            reject(error);
          });
      }
    });
  });
};

exports.addServiceHistory = (requestData) => {
  return new Promise((resolve, reject) => {
    pool.getConnection((error, connection) => {
      if (error) {
        console.error('Error getting connection from pool:', error);
        reject(error);
      } else {
        const promises = [];

        for (let elt of requestData) {
          const clusterName = elt.clusterName;
          const serviceName = elt.serviceName;
          const status = elt.status;
          const msg = elt.message;
          const date = elt.date;

          const selectQuery = queries.select_exist_service(serviceName, clusterName);
          const insertServiceQuery = queries.insert_service(serviceName, clusterName);
          const insertHistoryQuery = queries.insert_history_service(clusterName, serviceName, status, date, msg);

          promises.push(
            new Promise((innerResolve, innerReject) => {
              connection.query(selectQuery, (error, results) => {
                if (error) {
                  console.error('Error executing query:', error);
                  innerReject(error);
                } else {
                  if (results[0].exist == 0) {
                    connection.query(insertServiceQuery, (error) => {
                      if (error) {
                        console.error('Error executing query:', error);
                        innerReject(error);
                      } else {
                        //console.log('Add new service');
                        innerResolve();
                      }
                    });
                  } else {
                    connection.query(insertHistoryQuery, (error) => {
                      if (error) {
                        console.error('Error executing query:', error);
                        innerReject(error);
                      } else {
                        //console.log('Add history service');
                        innerResolve();
                      }
                    });
                  }
                }
              });
            })
          );
        }

        Promise.all(promises)
          .then(() => {
            connection.release();
            resolve({ message: 'Added new history service' });
          })
          .catch((error) => {
            connection.release();
            reject(error);
          });
      }
    });
  });
};

exports.getExternalServices = (clusterName) => {
  return new Promise((resolve, reject) => {
    pool.getConnection((error, connection) => {
      if (error) {
        console.error('Error getting connection from pool:', error);
        reject(error);
      } else {
        connection.query(queries.select_cluster_external_services(clusterName), (error, results) => {
          if (error) {
            console.error('Error executing query:', error);
            connection.release();
            reject(error);
          } else {
            //console.log("Call cluster external services");
            connection.release();
            resolve(results);
          }
        });
      }
    });
  });
};

exports.getAnExternalService = (clusterName, externalService) => {
  return new Promise((resolve, reject) => {
    pool.getConnection((error, connection) => {
      if (error) {
        console.error('Error getting connection from pool:', error);
        reject(error);
      } else {
        connection.query(
          queries.select_cluster_an_external_service(clusterName, externalService),
          async (error, results) => {
            if (error) {
              console.error('Error executing query:', error);
              connection.release();
              reject(error);
            } else {
              let nbHealthyHost = 0;
              const combinedStr = [];
              let statusExternalService;
              let statusMsgExternalService;
              try {
                for (let item of results) {
                  try {
                    let statusComponent = await new Promise((resolve, reject) =>
                      externalApi.callExternalComponent(item['exurl_host'], (error, str) =>
                        error ? reject(error) : resolve(str)
                      )
                    );

                    if (statusComponent === "true") nbHealthyHost++;
                    if (statusComponent != "true") statusComponent = false;
                    const pattern = /\/\/([^\/:]+:\d+)/;
                    const match = item['exurl_host'].match(pattern);
                    const str = {
                      componentName: item['excomponent_name'],
                      hostName: match[1],
                      status: statusComponent ? "GREEN" : "RED",
                      statusMsg: statusComponent ? "OK" : "KO",
                    };
                    combinedStr.push(str);
                  } catch (e) {
                    console.error(`Error for host ${item['exurl_host']}: ${e}`);
                    const pattern = /\/\/([^\/:]+:\d+)/;
                    const match = item['exurl_host'].match(pattern);
                    const str = {
                      componentName: item['excomponent_name'],
                      hostName: match[1],
                      status: "RED",
                      statusMsg: "KO",
                    };
                    combinedStr.push(str);
                  }
                }

                if (nbHealthyHost === results.length) {
                  statusExternalService = 'GREEN';
                  statusMsgExternalService = 'OK';
                } else if (nbHealthyHost >= results.length * (results[0]['exservice_threshold'] / 100)) {
                  statusExternalService = 'ORANGE';
                  statusMsgExternalService = 'WARNING';
                } else {
                  statusExternalService = 'RED';
                  statusMsgExternalService = 'CRITICAL';
                }

                const resService = {
                  clusterName: clusterName,
                  externalServiceId: results[0]['exservice_id'],
                  externalServiceName: externalService,
                  statusService: statusExternalService,
                  statusMsgService: statusMsgExternalService,
                  date: new Date().toLocaleString('jw-FR'),
                  components: combinedStr,
                };

                //console.log('Call an external service');
                resolve(resService);

                connection.query(
                  queries.insert_history_exservice(
                    resService.clusterName,
                    resService.externalServiceName,
                    resService.statusService,
                    resService.date,
                    resService.statusMsgService
                  ),
                  (error) => {
                    if (error) {
                      console.error('Error executing query:', error);
                    } else {
                      //console.log('Add history external service');
                    }
                    connection.release();
                  }
                );
              } catch (e) {
                console.error(`Can't get status of external service ${externalService} from cluster ${clusterName}`);
                console.error(e);
                reject(e);
                connection.release();
              }
            }
          }
        );
      }
    });
  });
};

exports.addExternalComponent = (requestData) => {
  return new Promise((resolve, reject) => {
    pool.getConnection((error, connection) => {
      if (error) {
        console.error('Error getting connection from pool:', error);
        reject(error);
      } else {
        const promises = [];

        for (let elt of requestData) {
          const clusterName = elt.clusterName;
          const componentName = elt.componentName;
          const serviceName = elt.serviceName;
          const status = elt.status;
          const statusMsg = elt.statusMsg;
          const msg = elt.msg;
          const date = elt.date;

          const insertQuery = queries.insert_history_excomponent(
            clusterName,
            serviceName,
            componentName,
            status,
            statusMsg,
            msg,
            date
          );

          promises.push(
            new Promise((innerResolve, innerReject) => {
              connection.query(insertQuery, (error) => {
                if (error) {
                  console.error('Error executing query:', error);
                  innerReject(error);
                } else {
                  innerResolve();
                }
              });
            })
          );
        }

        Promise.all(promises)
          .then(() => {
            connection.release();
            resolve({ message: 'Added new history external component' });
          })
          .catch((error) => {
            connection.release();
            reject(error);
          });
      }
    });
  });
};

exports.getRefreshTime = () => {
  return new Promise((resolve, reject) => {
    pool.getConnection((error, connection) => {
      if (error) {
        console.error('Error getting connection from pool:', error);
        reject(error);
      } else {
        connection.query(queries.select_refresh_time, (error, results) => {
          if (error) {
            console.error('Error executing query:', error);
            connection.release();
            reject(error);
          } else {
            ////console.log("Call refresh time");
            connection.release();
            
            resolve(results[0].refresh_time);
          }
        });
      }
    });
  });
};

exports.getMail= () => {
  return new Promise((resolve, reject) => {
    pool.getConnection((error, connection) => {
      if (error) {
        console.error('Error getting connection from pool:', error);
        reject(error);
      } else {
        connection.query(queries.select_mail, (error, results) => {
          if (error) {
            console.error('Error executing query:', error);
            connection.release();
            reject(error);
          } else {
            ////console.log("Call refresh time");
            connection.release();
            let listMail = [];
            for(const mail of results){
              listMail.push(mail.mail);
            }
            resolve(listMail);
          }
        });
      }
    });
  });
};
