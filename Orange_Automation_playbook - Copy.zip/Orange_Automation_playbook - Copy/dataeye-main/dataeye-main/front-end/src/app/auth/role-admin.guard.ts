import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const roleAdminGuard: CanActivateFn = (route, state) => {
  const roleId = localStorage.getItem('roleId');
  const router = inject(Router);
  if (roleId == '1') return true; 
  else{
    router.navigate(['']);
    return false;
  } 
};
