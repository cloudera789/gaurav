import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MainserviceService } from '../services/mainservice.service';
import { Cluster } from '../models/cluster';
import { ComponentService } from '../models/component';
import { ServiceCluster } from '../models/service';

@Component({
  selector: 'app-cluster',
  templateUrl: './cluster.component.html',
  styleUrls: ['./cluster.component.css']
})
export class ClusterComponent implements OnInit {
  constructor(
    private _Activatedroute: ActivatedRoute,
    private _router: Router,
    public mainservice : MainserviceService
  ) { }
  clustername! : string | null;
  cluster! : Cluster;
  sub! : any;

  msg! : string[];
  selectedComponent="";


  async ngOnInit(): Promise<void> {
    this.sub = this._Activatedroute.paramMap.subscribe((params) => {
      console.log(params);
      this.clustername = params.get('cluster-name');
      let list_clusters = this.mainservice.getClusters();
      const clt = list_clusters.find((p) => p.clusterName == this.clustername);
      if (clt != undefined) this.cluster=clt;
    });
    //console.log(localStorage.getItem('token'));
    await this.mainservice.getServices(this.cluster);
    await this.mainservice.getExternalServices(this.cluster);

    //await this.mainservice.initHome();
    // const parts = this._router.url.split('/');
    // this.clustername = parts[2];
    // //console.log(parts[2]);
    // const clt = await this.mainservice.getClusters().find((p) => p.clusterName == this.clustername);
    // if (clt != undefined) this.cluster=clt;
    // console.log(this.cluster.clusterName);
    // this.mainservice.getServices(this.cluster);
    
  }
 
  ngOnDestroy() {
    if (this.sub) this.sub.unsubscribe();
  }
 
  onBack(): void {
    this._router.navigate(['home']);
  }

  getMsgComponent(item : ComponentService){
    this.msg = item.msg;
    this.selectedComponent = item.componentName;
  }

  async refreshAll(): Promise<void> {
    this.cluster.delServices();
    await this.mainservice.getServices(this.cluster);
    await this.mainservice.getExternalServices(this.cluster);
    //console.log('from clt : length of services'+this.cluster.services.length);
    //console.log('from clt : length of services'+this.cluster.services[0].date);
 
  }
}
