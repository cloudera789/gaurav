import { NgModule } from "@angular/core";
import { HomeComponent } from "./home/home.component";
import { LoginComponent } from "./login/login.component";
import { RouterModule, Routes } from "@angular/router";
import { HistoryComponent } from "./history/history.component";
import { SettingsComponent } from "./settings/settings.component";
import { ClusterComponent } from "./cluster/cluster.component";
import { UsersComponent } from "./users/users.component";
import { AuthClassGuard } from "./auth/auth-class.guard";
import { roleAdminGuard } from "./auth/role-admin.guard";

const routes : Routes = [
    { path : '', component : LoginComponent, pathMatch : 'full'},
    { path : 'home', component : HomeComponent, canActivate: [AuthClassGuard] },
    { path : 'history', component : HistoryComponent, canActivate: [AuthClassGuard] },
    { path : 'settings', component : SettingsComponent, canActivate: [AuthClassGuard] },
    { path : 'home/:cluster-name', component : ClusterComponent, canActivate: [AuthClassGuard]},
    { path : 'users', component : UsersComponent, canActivate: [AuthClassGuard,roleAdminGuard] },
];

@NgModule({
    imports : [
        RouterModule.forRoot(routes)
    ],
    exports : [
        RouterModule
    ]
})
export class AppRoutingModule {

}