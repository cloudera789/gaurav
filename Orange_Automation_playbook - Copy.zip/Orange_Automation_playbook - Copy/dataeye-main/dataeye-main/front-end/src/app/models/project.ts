import { Cluster } from "./cluster";

export class Project{
    private _projectName : string;
    private _customerName : string;
    private _clusters : Cluster[];

    public constructor(projectName : string, customerName : string){
        this._projectName = projectName;
        this._customerName = customerName;
        this._clusters = [];

    }

    get projectName() : string{ return this._projectName; }
    get customerName() : string{ return this._customerName; }
    get clusters() : Cluster[]{ return this._clusters; }

    addCluster(cluster : Cluster){ this._clusters.push(cluster); }

    
} 