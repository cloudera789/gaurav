import { Color } from "./color";

export class ComponentService{
    private _componentName : string;
    private _serviceName! : string;
    private _status : Color;
    private _statusMsg : string;
    private _msg : string[];

    

    // public constructor(componentName : string){
    //     this._componentName = componentName;
    // }

    public constructor(componentName : string, serviceName : string, status : string, statusMsg : string){
        this._componentName = componentName;
        this._serviceName = serviceName;
        switch (status) {
            case 'GREEN':
              this._status = Color.green;
              break;
            case 'ORANGE':
              this._status = Color.orange;
              break;
            case 'RED':
              this._status = Color.red;
              break;
            default:
              this._status = Color.grey;
              break;
          }
        this._statusMsg = statusMsg;
        this._msg = [];
    }

    set status(color : Color){ this._status = color; }

    get status() : Color { return this._status; }

    get componentName() : string { return this._componentName; }

    //set serviceName(servicename : string ) { this._serviceName = servicename; }
    
    get serviceName() : string { return this._serviceName; }

    addMsg(msg : string) { this._msg.push(msg); }

    get msg() : string[] { return this._msg; }

    get statusMsg() : string { return this._statusMsg; }
    set statusMsg(m : string ){ this._statusMsg = m; }
}