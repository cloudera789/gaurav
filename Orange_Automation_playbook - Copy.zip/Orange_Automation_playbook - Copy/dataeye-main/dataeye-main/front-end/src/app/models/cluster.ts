import { Color } from "./color";
import { ServiceCluster } from "./service";

export class Cluster{
    private _clusterName : string;
    private _projects : string[];
    private _status : Color | null;
    private _type : number;
    private _typeName! : string;
    private _date : string | null;
    private _services : ServiceCluster[];
    private _username! : string;
    private _pwd! : string;
    private _adrIP! : string;
    private _threshold! : number;
    private _endpoint! : string;
    private _hosts! : string;
    

    public constructor(clusterName : string, type : number, status : string | null, date : string | null){
        this._clusterName = clusterName;
        this._projects = [];
        this._type = type;
        this._services = [];
        this._date = date;
        switch (status) {
            case 'GREEN':
              this._status = Color.green;
              break;
            case 'ORANGE':
              this._status = Color.orange;
              break;
            case 'RED':
              this._status = Color.red;
              break;
            default:
              this._status = Color.grey;
              break;
          }
          
    }

    //set status(color : Color){ this._status = color; }

    get date() : string | null { return this._date; }
    set date(d : string | null) { this._date = d; }

    get hosts() : string { return this._hosts; }
    set hosts(h : string) { this._hosts = h; }

    get status() : Color | null { return this._status; }
    set status(status : string | null) { switch (status) {
      case 'GREEN':
        this._status = Color.green;
        break;
      case 'ORANGE':
        this._status = Color.orange;
        break;
      case 'RED':
        this._status = Color.red;
        break;
      default:
        this._status = Color.grey;
        break;
    } }

    get projects() : string[] { return this._projects; }

    get clusterName() : string { return this._clusterName; }

    get services() : ServiceCluster[] { return this._services; }

    get type() : number { return this._type; }

    get typeName() : string { return this._typeName; }
    set typeName(str : string) { this._typeName = str; }

    get username() : string { return this._username; }
    set username(str : string){ this._username = str; }

    get pwd() : string { return this._pwd; }
    set pwd(str : string) { this._pwd = str; }

    get adrIP() : string { return this._adrIP; }
    set adrIP(str : string) { this._adrIP = str; }

    get threshold() : number { return this._threshold; }
    set threshold(n : number) { this._threshold = n; }

    get endpoint() : string { return this._endpoint; }
    set endpoint(e : string) { this._endpoint = e; }
    

    delServices(){
      this._services = [];
    }

    addService(service : ServiceCluster){ 
        this._services.push(service); 
    }

    addProject(projectName : string){
      this._projects.push(projectName);
    }

}