import { Color } from './color'
export class Host{
    private _hostName : string;
    private _status! : Color;

    public constructor(hostName : string){
        this._hostName = hostName;
    }

    set status(color : Color){ this._status = color; }

    get status() : Color { return this._status; }

    get hostName() : string { return this._hostName; }
}