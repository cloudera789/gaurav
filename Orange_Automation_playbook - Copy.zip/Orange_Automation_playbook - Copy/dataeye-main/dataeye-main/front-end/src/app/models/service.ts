import { Color } from "./color";
import { ComponentService } from "./component";

export class ServiceCluster{
    private _serviceName : string;
    private _clusterName : string;
    private _clusterType : number;
    private _status : Color;
    private _msg : string;
    private _date : string;
    private _components : ComponentService[];
    

    public constructor(serviceName : string, clusterName : string, clusterType : number, status : string, msg : string, date : string){
        this._serviceName = serviceName;
        this._clusterName = clusterName;
        this._clusterType = clusterType;
        switch (status) {
            case 'GREEN':
              this._status = Color.green;
              break;
            case 'ORANGE':
              this._status = Color.orange;
              break;
            case 'RED':
              this._status = Color.red;
              break;
            default:
              this._status = Color.grey;
              break;
        };
        this._msg = msg;
        this._date = date;
        this._components = [];

    }

    //set status(color : Color){ this._status = color; }

    get status() : Color { return this._status; }
    set status(color : Color){ this._status = color; }

    get serviceName() : string { return this._serviceName; }

    //set clusterName(clustername : string ) { this._clusterName = clustername; }
    
    get clusterName() : string { return this._clusterName; }

    //set msg(msg : string){ this._msg = msg; }

    get msg() : string { return this._msg; }
    
    get date() : string { return this._date; }

    get components() : ComponentService[] { return this._components; }

    get clusterType() : number |null { return this._clusterType; }

    addComponents(c : ComponentService) { this._components.push(c); }

    //add methode addComponent later

}