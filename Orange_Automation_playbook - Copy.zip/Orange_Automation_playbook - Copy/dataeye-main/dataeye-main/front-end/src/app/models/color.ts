export enum Color{
    green = "green",
    orange = "orange",
    red = "red",
    grey = "grey"
}