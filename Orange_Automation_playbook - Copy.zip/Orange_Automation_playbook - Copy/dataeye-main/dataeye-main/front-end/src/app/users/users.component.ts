import { Component, OnInit } from '@angular/core';
import { MainserviceService } from '../services/mainservice.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  currentUsername! : string | null;
  users: {key : string;value : string}[];
  editedUser : boolean = false; 
  roles = ['admin','super user','user'];
  
  //Add new user modal
  newUsername! : string;
  newPassword! : string;
  selectedRole! : string;

  //Delete user modal 
  oldUser! : string;

  //Change pwd user modal
  newPwdUser! : string;


  constructor(public mainservice : MainserviceService, private snackBar : MatSnackBar){
    this.users = []
  }
  async ngOnInit(): Promise<void> {
    await this.mainservice.callUsers();
    this.users = this.mainservice.getUsers();
    this.currentUsername = localStorage.getItem('username');
  }

  editUser(){
    this.editedUser = true;
  }

  closeUser(){
    this.editedUser = false;
  }

  async addUser(){
    //console.log('new username : '+this.newUsername);
    //console.log(this.users.some(obj => obj.key == this.newUsername));

    if(this.newUsername != '' && this.newPassword != '' && this.users.some(obj => obj.key == this.newUsername)){
      alert('Username already exists. Please try with another one !')
    }
      
    else{
      const data = {
        username : this.newUsername,
        password : this.newPassword,
        roleId : parseInt(this.selectedRole)
      }
      await this.mainservice.postUser(data);
      this.newPassword = '';
      this.newUsername = '';
      this.selectedRole = 'Choose a role';
      setTimeout(async () => {
        await this.mainservice.callUsers();
        this.users = this.mainservice.getUsers();
      }, 100);
    } 
    //console.log(this.newUsername+' '+this.newPassword+' '+this.selectedRole+' '+parseInt(this.selectedRole));
  }

  setOldUser(username : string){
    this.oldUser = username;
  }

  async delUser(){
    var status: number;
    const result = await this.mainservice.delUser(this.oldUser);
    if (result !== undefined) {
        status = result;
        //console.log('status code :'+status);
        if (status == 404) alert("Can not delete this user");
    }
    setTimeout(async () => {
      await this.mainservice.callUsers();
      this.users = this.mainservice.getUsers();
    }, 200);
  }

  async changePwdUser(){
    console.log(this.oldUser + ' ' +this.newPwdUser);
    var status: number;
    const result = await this.mainservice.updatePwdUser(this.oldUser,this.newPwdUser);
    if (result !== undefined) {
        status = result;
        //console.log('status code :'+status);
        if (status == 404) alert("Can not change password of this user"); 
        else this.openSnackBar();
    }
    
  }

  openSnackBar(){
    this.snackBar.open('Password has been changed successfully', 'Close', {
      horizontalPosition: 'center',
      verticalPosition: 'top',
    });
  };

}


