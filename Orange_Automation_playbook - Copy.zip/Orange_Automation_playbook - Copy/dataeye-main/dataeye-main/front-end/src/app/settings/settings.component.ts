import { Component, OnInit } from '@angular/core';
import { MatSliderModule } from '@angular/material/slider';
import { MainserviceService } from '../services/mainservice.service';
import { Project } from '../models/project';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Cluster } from '../models/cluster';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {
  checkRefreshTime :boolean = false;
  checkListCustomer : boolean = false;
  checkListProject : boolean = false;
  checkListCluster : boolean = false;
  checkListMail : boolean = false;
  checkListExternalService : boolean = false; 

  selectedTime! : number; //selected time in slider
  customers! : string[];
  projects! : Project[];
  clusters! : Cluster[];
  exservices! : any[];
  newCustomer! : string;
  newProject! : string;
  newUrlExternalService! : string;
  listComponentExternalService! : string[];
  componentsExternalService! : any[];

  newNameCustomer! : string; //for change name customer
  oldNameCustomer! : string; // for change name customer

  newNameProject! : string; //for change name project
  oldNameProject! : string; //for change name project

  selectedCustomerProject : string; //for set name customer of new project
  selectedChangedCustomer! : string[]; //for change customer in an existing project
  selectedExternalService! : string;
  selectedUrl! : string;
  selectedClusterExternalService! : string;
  selectedComponentExternalService! : string;

  newUsernameCluster! : string; //for change user name cluster
  newPwdCluster! : string; //for change Pwd cluster
  newAdrCluster! : string; //for change Address IPAddress IP cluster
  newThresholdCluster! : string;
  newThresholdExternalService! : string;
 
  clusterNameToUpdate! : string; //for change username, pwd, address ip cluster
  clusterNameToDelete!  : string; //for delete cluster
 
  //for add new cluster
  createNameCluster! : string;
  createUsernameCluster! : string; 
  createPwdCluster! : string; 
  createAdrCluster! : string; 
  createListProjectsCluster : string[];
  createThresholdCluster! : number;
  selectedTypeCluster! : string;
  createEndpointCluster! : string;

  newMail! : string; //for add a new mail

  editedTime : boolean = false; //for opening window to edit
  editedProject : boolean = false;
  editedCustomer : boolean = false;
  editedCluster : boolean = false;
  editedMail : boolean = false;
  editedExternalService : boolean = false;
  isSuperUser! : boolean;
  urlInputs: string[] = [];

  constructor(public mainservice : MainserviceService, private _snackBar: MatSnackBar){
    this.selectedTime = mainservice.refreshTime;
    this.selectedCustomerProject = "Choose a customer";
    this.selectedComponentExternalService = "Choose a component that you want to add URL";
    this.createListProjectsCluster = [];
    this.listComponentExternalService = [];
    this.selectedClusterExternalService = "Choose a cluster";
  }
  async ngOnInit(): Promise<void> {
    await this.mainservice.callRefreshTime();
    await this.mainservice.callClustersProjects();
    await this.mainservice.callCustomers();
    await this.mainservice.updateTypes();
    await this.mainservice.callRefreshTime();
    await this.mainservice.callMail();
    this.selectedTime = this.mainservice.refreshTime/1000/60; //in minutes
    this.exservices = await this.mainservice.callInfoExternalServices();
    this.customers = this.mainservice.getCustomers();
    this.projects = this.mainservice.getProjects();
    this.clusters = this.mainservice.getClusters();
    if(localStorage.getItem('roleId') == '1' || localStorage.getItem('roleId') == '2' ) this.isSuperUser = true; else this.isSuperUser = false;
    //console.log(this.exservices);
    //console.log(this.exservices[0]['exservice_name']);
    
    // console.log(this.mainservice.getCustomers().length);
    // console.log(this.customers.length);
  }

  showRefreshTime(){
    this.checkRefreshTime = true;
    this.checkListCluster = false;
    this.checkListMail = false;
    this.checkListCustomer = false;
    this.checkListProject = false;
    this.checkListExternalService = false;
    //console.log(this.checkRefreshTime);
  }
  
  editTime(){
    if(localStorage.getItem('roleId') == '1' || localStorage.getItem('roleId') == '2' ) this.editedTime = true; 
  }

  editCustomer(){ if(localStorage.getItem('roleId') == '1' || localStorage.getItem('roleId') == '2' ) this.editedCustomer = true; }

  editProject() { if(localStorage.getItem('roleId') == '1' || localStorage.getItem('roleId') == '2' ) this.editedProject = true; }

  editCluster(){
    if(localStorage.getItem('roleId') == '1' || localStorage.getItem('roleId') == '2' ) this.editedCluster = true;
  }

  editMail(){
    if(localStorage.getItem('roleId') == '1' || localStorage.getItem('roleId') == '2' ) this.editedMail = true;
  }

  editExternalService(){
    if(localStorage.getItem('roleId') == '1' || localStorage.getItem('roleId') == '2' ) this.editedExternalService = true;
  }

  showListCustomers(){
    this.checkRefreshTime = false;
    this.checkListCluster = false;
    this.checkListMail = false;
    this.checkListCustomer = true;
    this.checkListProject = false;
    this.checkListExternalService = false;
  }

  showListProjects(){
    this.checkRefreshTime = false;
    this.checkListCluster = false;
    this.checkListMail = false;
    this.checkListCustomer = false;
    this.checkListProject = true;
    this.checkListExternalService = false;
  }

  showListClusters(){
    this.checkRefreshTime = false;
    this.checkListCluster = true;
    this.checkListMail = false;
    this.checkListCustomer = false;
    this.checkListProject = false;
    this.checkListExternalService = false;
  }

  showListExternalServices(){
    this.checkRefreshTime = false;
    this.checkListCluster = false;
    this.checkListMail = false;
    this.checkListCustomer = false;
    this.checkListProject = false;
    this.checkListExternalService = true;
  }

  showListMails(){
    this.checkRefreshTime = false;
    this.checkListCustomer = false;
    this.checkListProject = false;
    this.checkListCluster = false;
    this.checkListMail = true;
    this.checkListExternalService = false;
  }

  formatThreshold(value: number): string {
    // if (value >= 1000) {
    //   return Math.round(value / 1000) + 'k';
    // }
    return `${value}` +'%';
  }

  formatLabel(value: number): string {
    // if (value >= 1000) {
    //   return Math.round(value / 1000) + 'k';
    // }
    return `${value}` +'mn';
  }



  async updateTime(){
    this.editedTime = false;
    //console.log(this.selectedTime);
    await this.mainservice.updateRefreshTime(this.selectedTime*1000*60);
    this.mainservice.refreshTime = this.selectedTime*1000*60;
    
  }

  
  //need to add sth
  updateMail(){
    this.editedMail = false;
  }

  cancelTime(){
    this.editedTime = false;
    this.selectedTime = this.mainservice.refreshTime;
  }

  closeCustomer(){
    this.editedCustomer = false;
  }

  closeProject(){
    this.editedProject = false;
  }

  closeCluster(){
    this.editedCluster = false;
  }

  closeExternalService(){
    this.editedExternalService = false;
  }

  async addCustomer() {
    await this.mainservice.postCustomer(this.newCustomer);
    //arrive pas à faire synchroniser les 2 fonctions. donc laisse 2e fonction attend 0.5s => à trouver autre moyen
    setTimeout(async () => {
      await this.mainservice.callCustomers();
      this.customers = this.mainservice.getCustomers();
    }, 200);

  }

  async addProject(){
    console.log('Selected customer project : '+this.selectedCustomerProject);
    await this.mainservice.postProject(this.newProject,this.selectedCustomerProject);
    //arrive pas à faire synchroniser les 2 fonctions. donc laisse 2e fonction attend 0.5s => à trouver autre moyen
    setTimeout(async () => {
      await this.mainservice.callClustersProjects();
      this.projects = this.mainservice.getProjects();
    }, 100);
  }

  async addCluster(){
    //console.log(this.createUsernameCluster);
    await this.mainservice.postCluster(this.createNameCluster,this.createUsernameCluster,this.createPwdCluster,this.createAdrCluster,this.selectedTypeCluster,this.createThresholdCluster, this.createEndpointCluster,this.createListProjectsCluster);
    //arrive pas à faire synchroniser les 2 fonctions. donc laisse 2e fonction attend 0.5s => à trouver autre moyen
    setTimeout(async () => {
      await this.mainservice.callClustersProjects();
      this.clusters = this.mainservice.getClusters();
    }, 100);
  }

  async addMail() {
    await this.mainservice.postMail(this.newMail);
    //arrive pas à faire synchroniser les 2 fonctions. donc laisse 2e fonction attend 0.5s => à trouver autre moyen
    setTimeout(async () => {
      await this.mainservice.callMail();
      
    }, 200);

  }

  async deleteCustomer(name : string){
    var status: number;
    const result = await this.mainservice.delCustomer(name);
    if (result !== undefined) {
        status = result;
        //console.log('status code :'+status);
        if (status == 404) this.openSnackBarCustomer();
    }
    setTimeout(async () => {
      await this.mainservice.callCustomers();
      this.customers = this.mainservice.getCustomers();
    }, 200);
  }

  async deleteProject(nameProj : string){
    var status: number;
    const result = await this.mainservice.delProject(nameProj);
    if (result !== undefined) {
        status = result;
        //console.log('status code :'+status);
        if (status == 404) this.openSnackBarProject();
    }
    setTimeout(async () => {
      await this.mainservice.callClustersProjects();
      this.projects = this.mainservice.getProjects();
    }, 100);
  }

  async deleteMail(name : string){
    await this.mainservice.delMail(name);

    setTimeout(async () => {
      this.mainservice.listMails =[];
      await this.mainservice.callMail();
    }, 200);
  }

  async changeNameCustomer() {
    await this.mainservice.updateCustomer(this.oldNameCustomer, this.newNameCustomer);

    //arrive pas à faire synchroniser les 2 fonctions. donc laisse 2e fonction attend 0.5s => à trouver autre moyen
    setTimeout(async () => {
      await this.mainservice.callClustersProjects();
      await this.mainservice.callCustomers();
      this.customers = this.mainservice.getCustomers();
      this.projects = this.mainservice.getProjects();
    }, 200);
    //this.oldName = '';
  }

  async changeNameProject(){
    await this.mainservice.updateProject(this.oldNameProject, this.newNameProject);
    //arrive pas à faire synchroniser les 2 fonctions. donc laisse 2e fonction attend 0.1s => à trouver autre moyen
    setTimeout(async () => {
      await this.mainservice.callClustersProjects();
      this.projects = this.mainservice.getProjects();
      this.clusters = this.mainservice.getClusters();
    }, 100);
    this.oldNameProject ='';
  }

  async changeUsernameCluster(){
    await this.mainservice.updateUsernameCluster(this.clusterNameToUpdate, this.newUsernameCluster);
    setTimeout(async () => {
      await this.mainservice.callClustersProjects();
      this.clusters = this.mainservice.getClusters();
    }, 100);
  }

  async changePwdCluster(){
    await this.mainservice.updatePwdCluster(this.clusterNameToUpdate, this.newPwdCluster);
    setTimeout(async () => {
      await this.mainservice.callClustersProjects();
      this.clusters = this.mainservice.getClusters();
    }, 100);
  }
  
  async changeAdrCluster(){
    await this.mainservice.updateAdrCluster(this.clusterNameToUpdate, this.newAdrCluster);
    setTimeout(async () => {
      await this.mainservice.callClustersProjects();
      this.clusters = this.mainservice.getClusters();
    }, 100);
  }  

  async changeThresholdCluster(){
    await this.mainservice.updateThresholdCluster(this.clusterNameToUpdate, this.newThresholdCluster);
    setTimeout(async () => {
      await this.mainservice.callClustersProjects();
      this.clusters = this.mainservice.getClusters();
    }, 100);
  }  

  async changeThresholdExternalService(){
    await this.mainservice.updateThresholdExternalService(this.selectedExternalService,this.newThresholdExternalService);
    setTimeout(async () => {
      this.exservices = await this.mainservice.callInfoExternalServices();
    }, 100);
  } 

  setSelectedUrl(url : string, cmp : string, cluster : string) { this.selectedUrl = url; this.selectedComponentExternalService = cmp; this.selectedClusterExternalService = cluster; }

  async changeUrlExternalService(){
    await this.mainservice.updateUrlExternalService(this.selectedUrl,this.newUrlExternalService,this.selectedComponentExternalService,this.selectedClusterExternalService);
    setTimeout(async () => {
      this.exservices = await this.mainservice.callInfoExternalServices();
    }, 100);
  }

  async updateRealize(projectName : string, oldCustomerName : string, newCustomerName : any ){
    console.log('You selected : '+newCustomerName.target.value);
    await this.mainservice.updateRealize(projectName, oldCustomerName, newCustomerName.target.value);
    //arrive pas à faire synchroniser les 2 fonctions. donc laisse 2e fonction attend 0.5s => à trouver autre moyen
    setTimeout(async () => {
      await this.mainservice.callClustersProjects();
      this.projects = this.mainservice.getProjects();
    }, 200);
  }

  setOldNameCustomer(old_name : string){ this.oldNameCustomer = old_name; }

  setOldNameProject(old_name : string){ this.oldNameProject = old_name; }

  setExService(exservice_name : string){ this.selectedExternalService = exservice_name;}

  async getComponents(selected_exservice : string) { 
    this.componentsExternalService = await this.mainservice.callListComponentsExternalService(selected_exservice);
    this.selectedExternalService = selected_exservice;
    console.log(this.componentsExternalService);
  }

  setClusterToUpdate(cluster : string){  this.clusterNameToUpdate = cluster; }

  setClusterToDelete(cluster : string){  this.clusterNameToDelete = cluster; }


  openSnackBarCustomer() {
    this._snackBar.open('Cannot delete this customer !! This customer belongs to an existing project. You need to remove the link between the customer and the project first.', 'Close', {
      horizontalPosition: 'center',
      verticalPosition: 'top',
    });
  }

  openSnackBarProject(){
    this._snackBar.open('Cannot delete this project !! This project belongs to an existing cluster. You need to remove the link between the project and the cluster first.', 'Close', {
      horizontalPosition: 'center',
      verticalPosition: 'top',
    });
  };

  async changeProjectsCluster(cluster : Cluster, projectName :string){
    console.log("change in cluster : "+cluster.clusterName+" with project : "+projectName);
    if(cluster.projects.find((p) => p == projectName )){
      console.log("you've unchecked");
      await this.mainservice.delIsHosted(projectName, cluster.clusterName);
      setTimeout(async () => {
        await this.mainservice.callClustersProjects();       
        this.clusters = this.mainservice.getClusters();
      }, 200);
    }else{
      //console.log("you've checked. It means added a project");
      await this.mainservice.postIsHosted(projectName, cluster.clusterName);
      setTimeout(async () => {
        await this.mainservice.callClustersProjects();
        this.clusters = this.mainservice.getClusters();
      }, 200);
    } 
  }

  selectProjectsCluster(projectName : string){
    if(this.createListProjectsCluster.find((p) => p == projectName)){
      this.createListProjectsCluster = this.createListProjectsCluster.filter(item => item !== projectName);
      console.log("You've un checked. Length list : "+this.createListProjectsCluster.length);
    
    }else{
      this.createListProjectsCluster.push(projectName);
      console.log("Added project into lists. Length list : "+this.createListProjectsCluster.length);
    }
    
  }

  selectType(type : string){
    this.selectedTypeCluster = type;
    console.log(this.selectedTypeCluster);
  }

  async deleteCluster(){
    var status: number;
    console.log(this.clusterNameToDelete);
    const result = await this.mainservice.delCluster(this.clusterNameToDelete);
    if (result !== undefined) {
        status = result;
        //console.log('status code :'+status);
        if (status == 404) this.openSnackBarProject();
    }
    setTimeout(async () => {
      await this.mainservice.callClustersProjects();
      this.clusters = this.mainservice.getClusters();
    }, 100);
  }

  async deleteUrlExternalService(){
    var status: number;
    const result = await this.mainservice.delUrlExternalService(this.selectedUrl,this.selectedComponentExternalService,this.selectedClusterExternalService);
    if (result !== undefined) {
        status = result;
        //console.log('status code :'+status);
        if (status == 404) console.log("Cant not delete URL");
    }
    setTimeout(async () => {
      this.exservices = await this.mainservice.callInfoExternalServices();
      
    }, 100);
  }

  setForAddUrlInExternalService(exservice_name : string, cluster_name : string, components : any[]){
    this.listComponentExternalService = [];
    this.selectedExternalService = exservice_name;
    this.selectedClusterExternalService = cluster_name;
    components.forEach( (p) => this.listComponentExternalService.push(p.excomponent_name));
  }

  async addUrlExternalServie(url : string){
    await this.mainservice.postUrlExternalService(this.selectedClusterExternalService, this.selectedExternalService, this.selectedComponentExternalService, url);
    //arrive pas à faire synchroniser les 2 fonctions. donc laisse 2e fonction attend 0.5s => à trouver autre moyen
    setTimeout(async () => {
      this.exservices = await this.mainservice.callInfoExternalServices();
    
    }, 200);
  }

  async addClusterExternalService(){
    await this.mainservice.postClusterExternalService(this.selectedClusterExternalService, this.selectedExternalService, this.componentsExternalService, this.urlInputs);
    //arrive pas à faire synchroniser les 2 fonctions. donc laisse 2e fonction attend 0.5s => à trouver autre moyen
    setTimeout(async () => {
      this.exservices = await this.mainservice.callInfoExternalServices();   
    }, 200);
    console.log(this.selectedClusterExternalService+' '+this.selectedExternalService+' '+this.componentsExternalService+' '+this.urlInputs);
  }
  
}
