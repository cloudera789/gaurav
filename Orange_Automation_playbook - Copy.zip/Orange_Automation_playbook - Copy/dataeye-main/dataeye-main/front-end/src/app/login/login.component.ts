import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MainserviceService } from '../services/mainservice.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent {
  username! : string;
  password! : string;
  invalide :boolean = false;
  constructor(private router: Router, public mainservice : MainserviceService) { }
  async checkLogin() {
    //this.mainservice.initHome();
    // console.log(this.username+' '+this.password);
    if(await this.mainservice.getToken(this.username,this.password)){
      localStorage.setItem('username',this.username);
      this.router.navigate(['/home']);
      console.log('Token is valide');
      this.invalide = false;
    }else{
      this.invalide = true;
      console.log('Pwd incorrect');
      localStorage.setItem('token','');
      localStorage.setItem('roleId','');
    }
  }

  
}
