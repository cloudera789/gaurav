import { Component, OnInit } from '@angular/core';
import { MainserviceService } from '../services/mainservice.service';
import {MatPaginatorModule} from '@angular/material/paginator';
import { Cluster } from '../models/cluster';
import { ServiceCluster } from '../models/service';
import { ThemePalette } from '@angular/material/core';
import { Observable, of } from 'rxjs';
import { Color } from '../models/color';

export interface Task {
  name: string;
  completed: boolean;
  color: ThemePalette;
  subtasks?: Task[];
}

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit{
  
  services : string[]; //display list of service in select
  components : string[];
  historyService : any[]; //service info in history
  filterService : any[];
  historyCluster : any[];
  filterCluster : any[];
  historyComponent : any[];
  filterComponent : any[];
  pCluster : number =1; //number of page for cluster table
  pService : number =1;
  pComp : number =1;
  filteredDataCluster: any[] = [];
  constructor(public mainservice : MainserviceService){
    this.historyCluster = [];
    this.filterCluster = [];
    this.services = [];
    this.historyService = [];
    this.historyComponent = [];
    this.components = [];
    this.filterService = [];
    this.filterComponent = [];
  }
  ngOnInit(): void {
    this.mainservice.callClustersProjects();
  }

  clusterNameSelected! : string;
  clusterSelected! : Cluster;

  serviceNameSelected! : string;
  componentNameSelected! : string;

  status: Task = {
    name: 'status',
    completed: false,
    color: 'primary',
    subtasks: [
      {name: 'Status OK', completed: true, color: 'primary'},
      {name: 'Status WARNING', completed: true, color: 'primary'},
      {name: 'Status CRITICAL', completed: true, color: 'primary'},
      {name: 'Status DISABLED', completed: true, color: 'primary'},
    ],
  };

  allComplete: boolean = true;

  async chooseCluster(){
    this.serviceNameSelected = '';
    this.componentNameSelected = '';
    this.historyCluster = [];
    this.services =[];
    this.historyService = [];
    if (this.clusterNameSelected){
      this.historyCluster = await this.mainservice.callHistoryCluster(this.clusterNameSelected);
      this.filterCluster = this.historyCluster;
      var foundClt = this.mainservice.getClusters().find((c) => c.clusterName == this.clusterNameSelected);
      if (foundClt != undefined) this.clusterSelected = foundClt;
      this.historyService = await this.mainservice.callHistoryServices(this.clusterNameSelected);
      this.historyService.forEach((s) => {if(!this.services.includes(s.service_name)) this.services.push(s.service_name) } ) ;
      
    }
    //console.log(this.services.length);
  }

  async chooseService(){
    this.componentNameSelected = '';
    this.historyComponent = [];
    this.components = [];
    if (this.serviceNameSelected){
      this.filterService = this.historyService.filter(item => item.service_name == this.serviceNameSelected);
      this.historyComponent = await this.mainservice.callHistoryComponent(this.clusterNameSelected,this.serviceNameSelected);
      this.historyComponent.forEach((s) => {if(!this.components.includes(s.component_name)) this.components.push(s.component_name) } ) ;
    }
    this.historyComponent.forEach((h) => { h.component_msg = h.component_msg.split("/endMsg/"); });
   //this.filterComponent = this.historyComponent;
  }

  chooseComponent(){
    this.filterComponent = this.historyComponent.filter(item => item.component_name == this.componentNameSelected);
    
  console.log("history length : "+this.historyComponent.length+" ; filtre lenght : "+this.filterComponent.length);
    
  }

  splitAndConcatenate(arr: string): string[] {
    const result: string[] = arr.split(",");
    
    for (let i = result.length - 1; i >= 0; i--) {
      const currentElement = result[i];
      const nextElement = result[i + 1];
    
      if (nextElement && nextElement.startsWith(' ')) {
        const combinedElement = currentElement + nextElement;
        result[i] = combinedElement;
        result.splice(i + 1, 1); // Remove the next element from the array
      }
    }
    
    return result;
  }

  updateAllComplete() {
    this.allComplete = this.status.subtasks != null && this.status.subtasks.every(t => t.completed);

    if (this.componentNameSelected) this.filterDataComponent();
    else if(this.serviceNameSelected) this.filterDataService();
    else if (this.clusterNameSelected) this.filterDataCluster();

    // this.filterDataCluster();
    // this.filterDataService();
    //this.filterDataComponent();
    
  }

  someComplete(): boolean {
    if (this.status.subtasks == null) {
      return false;
    }

    if (this.componentNameSelected) this.filterDataComponent();
    else if(this.serviceNameSelected) this.filterDataService();
    else if (this.clusterNameSelected) this.filterDataCluster();
    // this.filterDataCluster();
    // this.filterDataService();
    // this.filterDataComponent();
    return this.status.subtasks.filter(t => t.completed).length > 0 && !this.allComplete;
  }

  setAll(completed: boolean) {
    this.allComplete = completed;
    if (this.status.subtasks == null) {
      return;
    }
    this.status.subtasks.forEach(t => (t.completed = completed));

    if (this.componentNameSelected) this.filterDataComponent();
    else if(this.serviceNameSelected) this.filterDataService();
    else if (this.clusterNameSelected) this.filterDataCluster();
    // this.filterDataCluster();
    // this.filterDataService();
    //this.filterDataComponent();
  }

filterDataCluster() {

  this.filterCluster = this.historyCluster.filter(item => {
    // Find the corresponding status object based on cluster_status
    const num = this.getNumberByStatus(item.cluster_status);

    //if(this.status.subtasks && num!=-1) console.log(item.cluster_status+' '+num+' '+this.status.subtasks[num].completed);
    // Check if a status object was found and if at least one subtask is completed
    return (this.status.subtasks && this.status.subtasks[num].completed);
  });
  //console.log('filter lenght :'+this.filterCluster.length+ '; dem : '+dem);
   
  //this.pCluster = 1; // Reset pagination to the first page when applying filters
}

filterDataService() {

  this.filterService = this.historyService.filter(item => {
    // Find the corresponding status object based on cluster_status
    const num = this.getNumberByStatus(item.service_status);
    return (this.status.subtasks && this.status.subtasks[num].completed && item.service_name == this.serviceNameSelected) ;
  });
  //console.log("history length : "+this.historyService.length+" ; filtre lenght : "+this.filterService.length);
}

filterDataComponent() {

  this.filterComponent = this.historyComponent.filter(item => {
    // Find the corresponding status object based on cluster_status
    const num = this.getNumberByStatus(item.component_status);
    return (this.status.subtasks && this.status.subtasks[num].completed && item.component_name == this.componentNameSelected) ;
  });
}

getNumberByStatus(clusterStatus : string ) : number{
  // Assuming you have an array of status objects like your "status" object
  // Loop through the status objects to find the one with a matching color
  let res : number
  switch (clusterStatus){
    case "GREEN": case "green" : res = 0; break; 
    case "ORANGE" : case'orange': res =1; break;
    case "RED" : case "red" : res = 2; break;
    default : res=3;
  }
  //console.log(clusterStatus+' '+res);
  return res;
}

  
}
