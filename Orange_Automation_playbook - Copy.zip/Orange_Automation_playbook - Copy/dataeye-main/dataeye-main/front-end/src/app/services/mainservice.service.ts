import { Injectable, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, first, interval, of } from 'rxjs';
import { Project } from '../models/project';
import { Cluster } from '../models/cluster';
import { Color } from '../models/color';
import { ServiceCluster } from '../models/service';
import { ComponentService } from '../models/component';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CdkPortal } from '@angular/cdk/portal';
import { environment } from 'src/config/env';

@Injectable({
  providedIn: 'root'
})
export class MainserviceService{
  public refreshTime! : number;
  public listMails : string[];
  private _projects : Project[];
  private _clusters : Cluster[];
  private _customers : string[];
  private _types : string[];
  private _users : {key:string; value :string}[];
  baseApi = environment.baseApi;

  constructor(private router: Router, private http : HttpClient) {
    this._projects = [];
    this._clusters = [];
    this._customers = [];
    this._types = [];
    this._users = [];
    this.listMails = [];
  }


  // startTimer(): Observable<number> {
  //   // Set the interval to 5 minutes (300,000 milliseconds)
  //   const intervalMilliseconds = 60 * 1000;

  //   // Create an observable that emits a value at the specified interval
  //   return interval(intervalMilliseconds);
  // }
  
  getTypes() : string[]{
    return this._types;
  }

  getCustomers() : string[]{
    return this._customers;
  }

  getProjects() : Project[]{
    return this._projects;
  }

  getClusters() : Cluster[]{
    //console.log(this._clusters.length);
    return this._clusters;
  }

  getUsers(): { key: string; value: string }[]{
    return this._users;
  }

  async getServices(cluster : Cluster) {
    const resSer = await this.http.get(this.baseApi+'/api/clusters/'+cluster.clusterName+'/services',{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyResSer = JSON.parse(JSON.stringify(resSer));
    //console.log('from service 1 : length of services'+cluster.services.length);
    //console.log(bodyResSer);
    var data = [];
    for(const item of bodyResSer){
      //console.log(item['clusterName'],item['projectName'],item['status'])
      const ser = new ServiceCluster(item['serviceName'],item['clusterName'],cluster.type,item['status'],item['message'], item['date']);
      cluster.addService(ser);
      await this.getComponents(ser);
      var str = {
        cluster_name : ser.clusterName,
        service_name : ser.serviceName,
        status : ser.status == Color.green ? 'GREEN' : ser.status == Color.orange ? 'ORANGE' : ser.status == Color.red ? 'RED' : 'GREY',
        msg : ser.msg,
        date : ser.date
      }
      data.push(str);
    };
    this.postService(data);
  }

  //get a list of external services
  async getExternalServices(cluster : Cluster) {
    const resSer = await this.http.get(this.baseApi+'/api/clusters/'+cluster.clusterName+'/externalservices',{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyResSer = JSON.parse(JSON.stringify(resSer));
    console.log(bodyResSer);
    for(const item of bodyResSer){
      //For Druid. Need to modify when have another type
      console.log(item['exservice_name']);
      switch (item['exservice_id']){
        //case 1 = Druid
        case (1) : await this.getDruidExternalService(cluster,item['exservice_name']); break;
      }
      // cluster.addService(ser);
      // await this.getComponents(ser);
    };
  }

  //for Druid service
  async getDruidExternalService(cluster : Cluster, exserviceName : string){
    const resComps = await this.http.get(this.baseApi+'/api/clusters/'+cluster.clusterName+'/externalservices/'+exserviceName,{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyResComp = JSON.parse(JSON.stringify(resComps));
    //console.log(bodyResComp);
    const ser = new ServiceCluster(bodyResComp['externalServiceName'],cluster.clusterName,cluster.type,bodyResComp['statusService'],bodyResComp['statusMsgService'], bodyResComp['date']);
    cluster.addService(ser);
    //console.log("add ex service");
    //console.log(cluster.services[cluster.services.length-1].serviceName);
    for(let item of bodyResComp['components']){
      //console.log(item['componentName']);
      const c = ser.components.find((p) => p.componentName == item['componentName']);
          if (c != undefined){ //if we find a component existed already
            //component is said K.O when it has 1 host is K.O
            if (item['status'] == 'RED') { c.status = Color.red; c.statusMsg = item['statusMsg'];}
            c.addMsg(item['componentName'] + ' in '+item['hostName']+' : '+item['statusMsg']);  
          } else { //if not we create
            const comp = new ComponentService(item['componentName'],ser.serviceName,item['status'],item['statusMsg']);
            comp.addMsg(item['componentName'] + ' in '+item['hostName']+' : '+item['statusMsg']);
            ser.addComponents(comp);
          }
    }

    var data = [];
    for(const s of ser.components){
      var combinedMsg = "";
      for(let i = 0; i < s.msg.length; i++){
        i!=0 ? combinedMsg += "/endMsg/" + s.msg[i] : combinedMsg = s.msg[i];
        
      }
      var str = {
        cluster_name : ser.clusterName,
        service_name : ser.serviceName,
        component_name : s.componentName,
        status : s.status,
        status_msg : s.statusMsg,
        msg : combinedMsg,
        date : ser.date
      }
      data.push(str);
      //console.log(str);
    }
    this.postExComponent(data);
  }

  async getComponents(service : ServiceCluster){
    const resComps = await this.http.get(this.baseApi+'/api/clusters/'+service.clusterName+'/services/'+service.serviceName+'/components',{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyResComps = JSON.parse(JSON.stringify(resComps));
    var date;
    //console.log(bodyResSer);
    for(const item of bodyResComps){
      date = item['date'];
      //console.log("date "+date);
      switch (service.clusterType){
      //type 2 <=> cluster CM
        case(2) : 
          const c = service.components.find((p) => p.componentName == item['componentName']);
          if (c != undefined){ //if we find a component existed already
            if (item['statusMsg'].includes('CONCERNING')) { c.status = Color.orange; c.statusMsg = item['statusMsg']; 
            }else{
              if (item['statusMsg'].includes('BAD')) { c.status = Color.red; c.statusMsg = item['statusMsg'];}
            } 

            c.addMsg(item['componentName'] + ' in '+item['hostName']+' : '+item['statusMsg']);  
          } else { //if not we create
            const comp = new ComponentService(item['componentName'],item['serviceName'],item['status'],item['statusMsg']);
            comp.addMsg(item['componentName'] + ' in '+item['hostName']+' : '+item['statusMsg']);
            service.addComponents(comp);
          }
          break;
        case(1): //if it is not cluster cm here : ambari
          const comp = new ComponentService(item['componentName'],item['serviceName'],item['status'],item['statusMsg']);
          service.addComponents(comp);
          break;
      
      }
        
    };
    const resMsg = await this.http.get(this.baseApi+'/api/clusters/'+service.clusterName+'/services/'+service.serviceName+'/messages',{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyResMsg = JSON.parse(JSON.stringify(resMsg));
    console.log(bodyResComps);
    const clt = this._clusters.find((c) => c.clusterName == service.clusterName);
    
    for(const item of bodyResMsg){
      //change after to check type
     
        const c = service.components.find((p) => p.componentName == item['componentName']);
        if (c != undefined) c.addMsg(item['message'].replaceAll("'"," "));
        else {
          const supComp = service.components.find((p) => p.componentName == 'Additional information')
          if (supComp == undefined){
            const sc = new ComponentService('Additional information',service.serviceName,'','');
            service.addComponents(sc);
            sc.addMsg(item['message']);
          }else
            supComp.addMsg(item['message'].replaceAll("'"," "));
        };
    };
    var data = [];
    for(const s of service.components){
      var combinedMsg = "";
      for(let i = 0; i < s.msg.length; i++){
        i!=0 ? combinedMsg += "/endMsg/" + s.msg[i] : combinedMsg = s.msg[i];
        
      }
      let statusComponent =
        combinedMsg.includes('BAD') || combinedMsg.includes('CRITICAL') ? "red" :
        combinedMsg.includes('CONCERNING') || combinedMsg.includes('WARNING') ? "orange" :
        s.status;
      s.status = statusComponent == 'green' ? Color.green : statusComponent == 'red' ? Color.red : statusComponent == 'orange' ? Color.orange : Color.grey;
      var str = {
        cluster_name : service.clusterName,
        service_name : service.serviceName,
        component_name : s.componentName,
        status : statusComponent,
        status_msg : s.statusMsg,
        msg : combinedMsg,
        date : date
      }
      data.push(str);
      //console.log(str);
      if (s.status == Color.red) {
        service.status = Color.red;
      } else if (s.status == Color.orange && service.status != Color.red) service.status = Color.orange;
    }
    
    this.postComponent(data);
  }

  async initHome(){
    this._projects = [];
    this._clusters = [];
    //call all projects
    const headers = new HttpHeaders({
      'Authorization': 'Bearer your_token_here'
    });
    const resProjs = await this.http.get(this.baseApi+'/api/projects',{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyResProjs = JSON.parse(JSON.stringify(resProjs));
    for(const item of bodyResProjs){
      const prj = new Project(item['project_name'],item['customer_name']);
      this._projects.push(prj);
      //console.log(item['projectName']);
      //console.log(item['customer']);
    }
    //console.log(this._projects.length);

    //call all clusters
    const resClus = await this.http.get(this.baseApi+'/api/clusters',{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyResClust = JSON.parse(JSON.stringify(resClus));
    //console.log(bodyResClust);
    for(const item of bodyResClust){
      //console.log(item['clusterName'],item['projectName'],item['status'])
      const clus = new Cluster(item['clusterName'],item['type'],item['status'], item['date']);
      clus.hosts = item['infoHosts'];
      for (const proj of item['projects']){
        const project = this._projects.find(p => p.projectName == proj);
        if (project){
          project.addCluster(clus);
          clus.addProject(project.projectName);
        }
      }
      this._clusters.push(clus);
      
    }
  }

  async callClustersProjects(){
    this._projects = [];
    this._clusters = [];
    //call all projects
    const resProjs = await this.http.get(this.baseApi+'/api/projects',{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyResProjs = JSON.parse(JSON.stringify(resProjs));
    for(const item of bodyResProjs){
      const prj = new Project(item['project_name'],item['customer_name']);
      this._projects.push(prj);
      //console.log(item['projectName']);
      //console.log(item['customer']);
    };
    //call all clusters
    const resClus = await this.http.get(this.baseApi+'/api/clusters/projects',{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }),'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyResClust = JSON.parse(JSON.stringify(resClus));
    for(const item of bodyResClust){
      const cluster = new Cluster(item['cluster_name'],item['url_id'],null,null);
      cluster.username = item['cluster_user'];
      cluster.adrIP = item['cluster_adr'];
      cluster.pwd = item['cluster_pwd'];
      cluster.typeName = item['url_type'];
      cluster.threshold = item['cluster_threshold'];
      cluster.endpoint = item['endpoint'];

      for(const project of item['projects']){
        this._projects.find(proj => proj.projectName == project)?.addCluster(cluster);
        cluster.addProject(project);
      };
      this._clusters.push(cluster);
      //console.log("call cluster project "+cluster.username+' '+cluster.pwd+' '+cluster.adrIP+' '+cluster.projects.length);
    }
    
  }

  //get status of one cluster
  async callACluster(clusterName : string){
    console.log("call a cluster status of name : "+clusterName);
    const res = await this.http.get(this.baseApi+'/api/clusters/'+clusterName,{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyRes = JSON.parse(JSON.stringify(res));
    const cluster = this._clusters.find((c) => c.clusterName == clusterName);
    if (cluster && bodyRes['date'] && bodyRes['status'] ){
      cluster.date = bodyRes['date'];
      cluster.status = bodyRes['status'];
    }
    //console.log('you called customers, lenght of list of customers : ',this._customers.length);
  }

  //get list of customers
  async callCustomers(){
    this._customers = [];
    const res = await this.http.get(this.baseApi+'/api/customers',{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyRes = JSON.parse(JSON.stringify(res));
    for(const item of bodyRes){
      this._customers.push(item['customer_name']);
    };
    //console.log('you called customers, lenght of list of customers : ',this._customers.length);
  }
  
  //create new customer 
  async postCustomer(customerName : string) {
    const url = this.baseApi+'/api/post/customer'; // URL of the API endpoint
    const data = { customer_name: customerName, roleId : localStorage.getItem('roleId')}; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.post(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response post customer:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //delete a customer
  async delCustomer(customerName: string): Promise<number> {
    const url = this.baseApi+`/api/delete/customer/${customerName}/${localStorage.getItem('roleId')}`;
    //const data = { customer_name: customerName, roleId : localStorage.getItem('roleId') };
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });
    
    return new Promise<number>((resolve, reject) => {
      this.http.delete(url, { headers }).subscribe(
        response => {
          console.log('Response delete customer:', response);
          const codeStatus = 200;
          //console.log(codeStatus);
          resolve(codeStatus);
        },
        error => {
          console.error('Error:', error);
          const codeStatus = error['status'];
          //console.log(codeStatus);
          resolve(codeStatus);
        }
      );
    });
  }
  
  //change name of customer
  async updateCustomer(oldName : string, newName : string) {
    const url = this.baseApi+'/api/patch/customer'; // URL of the API endpoint
    const data = {
      "old_name" : oldName,
      "new_name" : newName,
      "roleId" : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.patch(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response update customer:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }
  
  //create a new project
  async postProject(projectName : string, customerName : string) {
    const url = this.baseApi+'/api/post/project'; // URL of the API endpoint
    const data = { 
      project_name : projectName,
      customer_name: customerName, 
      roleId : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.post(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response post customer:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //create a new url in external_url
  async postUrlExternalService(clusterName : string, exserviceName : string, excomponentName : string, exurl : string) {
    const url = this.baseApi+'/api/post/externalservices/url'; // URL of the API endpoint
    const data = { 
      cluster_name : clusterName,
      exservice_name: exserviceName,
      excomponent_name : excomponentName,
      url : exurl,
      roleId : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
    'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
  });

    this.http.post(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response post url external customer:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //change name of project 
  async updateProject(oldName : string, newName : string) {
    const url = this.baseApi+'/api/patch/project'; // URL of the API endpoint
    const data = {
      "old_name" : oldName,
      "new_name" : newName, 
      "roleId" : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.patch(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response update project:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //change link between project and customer
  async updateRealize(projectName : string, oldCustomerName : string, newCustomerName : string) {
    const url = this.baseApi+'/api/patch/realize'; // URL of the API endpoint
    const data = {
      "project_name" : projectName,
      "old_customer_name" : oldCustomerName,
      "new_customer_name" : newCustomerName, 
      "roleId" : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.patch(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response update realize:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //delete a project
  async delProject(projectName: string): Promise<number> {
    const url = this.baseApi+`/api/delete/project/${projectName}/${localStorage.getItem('roleId')}`;
    //const data = { project_name: projectName, roleId : localStorage.getItem('roleId') };
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });
    
    return new Promise<number>((resolve, reject) => {
      this.http.delete(url, { headers }).subscribe(
        response => {
          console.log('Response delete project:', response);
          const codeStatus = 200;
          //console.log(codeStatus);
          resolve(codeStatus);
        },
        error => {
          console.error('Error:', error);
          const codeStatus = error['status'];
          //console.log(codeStatus);
          resolve(codeStatus);
        }
      );
    });
  }

  //create new link between project and cluster 
  async postIsHosted(projectName : string, clusterName : string) {
    const url = this.baseApi+'/api/post/ishosted'; // URL of the API endpoint
    const data = {
      "project_name" : projectName,
      "cluster_name" : clusterName, 
      "roleId" : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.post(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response post is_hosted:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //create new link between project and cluster 
  async delIsHosted(projectName : string, clusterName : string) {
    const url = this.baseApi+'/api/delete/ishosted/'+localStorage.getItem('roleId'); // URL of the API endpoint
    const data = {
      "project_name" : projectName,
      "cluster_name" : clusterName, 
      "roleId" : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });
    const options = {
      headers: headers,
      body: data
    };
    this.http.delete(url, options).subscribe(
      response => {
        // Handle the response data
        console.log('Response post is_hosted:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //change username of cluster
  async updateUsernameCluster(clusterName : string, newName : string) {
    const url = this.baseApi+`/api/patch/clusters/${clusterName}/username`; // URL of the API endpoint
    const data = {
      "new_name" : newName, "roleId" : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.patch(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response update username cluster:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //change pwd of cluster
  async updatePwdCluster(clusterName : string, newName : string) {
    const url = this.baseApi+`/api/patch/clusters/${clusterName}/pwd`; // URL of the API endpoint
    const data = {
      "new_name" : newName, "roleId" : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.patch(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response update pwd cluster:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //change addr of cluster
  async updateAdrCluster(clusterName : string, newName : string) {
    const url = this.baseApi+`/api/patch/clusters/${clusterName}/adr`; // URL of the API endpoint
    const data = {
      "new_name" : newName, "roleId" : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.patch(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response update address IP cluster:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //change threshold of cluster
  async updateThresholdCluster(clusterName : string, newName : string) {
    const url = this.baseApi+`/api/patch/clusters/${clusterName}/threshold`; // URL of the API endpoint
    const data = {
      "new_name" : newName, "roleId" : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.patch(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response update threshold cluster:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //change threshold of customer
  async updateThresholdExternalService(exserviceName : string, threshold : string) {
    const url = this.baseApi+`/api/patch/externalservices/${exserviceName}/threshold`; // URL of the API endpoint
    const data = {
      "threshold" : threshold, "roleId" : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.patch(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response update threshold external service:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }
  //change url
  async updateUrlExternalService(oldUrl : string, newUrl : string, cpm : string, cluster: string) {
    const url = this.baseApi+`/api/patch/externalservices/url`; // URL of the API endpoint
    const data = {
      "old_url" : oldUrl,
      "new_url" : newUrl,
      "excomponent_name" : cpm,
      "cluster_name" : cluster, 
      "roleId" : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.patch(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response update url external service:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //add cluster
  async postCluster(clusterName : string, username : string, pwd : string, adr : string, type : string, threshold : number, endpoint : string, project : string[] ) {
    const url = this.baseApi+`/api/post/cluster`; // URL of the API endpoint
    const data = {
      "cluster_name" : clusterName,
      "cluster_user" : username,
      "cluster_pwd" : pwd,
      "cluster_adr" : adr,
      "cluster_type" : type, 
      "cluster_threshold" : threshold,
      "endpoint" : endpoint,
      "projects" : project, 
      "roleId" : localStorage.getItem('roleId')
    }; // Data to be sent in the request body
    console.log(data);
    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.post(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response create new cluster:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //get list of types
  async updateTypes(){
    this._types = [];
    const res = await this.http.get(this.baseApi+'/api/types',{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyRes = JSON.parse(JSON.stringify(res));
    for(const item of bodyRes){
      this._types.push(item['url_type']);
    };
  }

  //delete a cluster
  async delCluster(clusterName: string): Promise<number> {
    const url = this.baseApi+`/api/delete/cluster/${clusterName}/${localStorage.getItem('roleId')}`;
    console.log('call clustername : '+clusterName);
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });
    
    return new Promise<number>((resolve, reject) => {
      this.http.delete(url, { headers }).subscribe(
        response => {
          console.log('Response delete cluster:', response);
          const codeStatus = 200;
          //console.log(codeStatus);
          resolve(codeStatus);
        },
        error => {
          console.error('Error:', error);
          const codeStatus = error['status'];
          //console.log(codeStatus);
          resolve(codeStatus);
        }
      );
    });
  }

  //get list of history cluster
  async callHistoryCluster(clusterName : string) : Promise<any[]>{
    const historyCluster = [];
    const res = await this.http.get(this.baseApi+'/api/history/clusters/'+clusterName,{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyRes = JSON.parse(JSON.stringify(res));
    for(const item of bodyRes){
      historyCluster.push(item);
      //console.log(item.cluster_date);
    };
    return historyCluster;
    //console.log('you called customers, lenght of list of customers : ',this._customers.length);
  }

  async callHistoryServices(clusterName : string) : Promise<any[]>{
    const historyServices = [];
    const res = await this.http.get(this.baseApi+'/api/history/services/'+clusterName,{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyRes = JSON.parse(JSON.stringify(res));
    for(const item of bodyRes){
      historyServices.push(item);
      //console.log(item.cluster_date);
    };
    return historyServices;
    //console.log('you called customers, lenght of list of customers : ',this._customers.length);
  }

  //post component history 
  async postComponent(dt : any) {
    const url = this.baseApi+'/api/post/component/'; // URL of the API endpoint
    console.log("history component: "+dt);
    const data = dt; // Data to be sent in the request body
    console.log(dt);
    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });
    
    //console.log(localStorage.getItem('token'));
    this.http.post(url, dt, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response post component:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //post external component history 
  async postExComponent(dt : any) {
    const url = this.baseApi+'/api/post/externalcomponent'; // URL of the API endpoint
    const data = dt; // Data to be sent in the request body
    console.log("History_ex_comp: "+dt);
    console.log(dt);
    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });
    this.http.post(url, dt, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response post excomponent:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  async callHistoryComponent(clusterName : string, serviceName : string) : Promise<any[]>{
    const historyComponents = [];
    const res = await this.http.get(this.baseApi+'/api/history/components/'+clusterName+'/'+serviceName,{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyRes = JSON.parse(JSON.stringify(res));
    for(const item of bodyRes){
      historyComponents.push(item);
      //console.log(item.component_msg);
      //console.log(item.component_msg[1]);
    };
    return historyComponents;
    
    //console.log('you called customers, lenght of list of customers : ',this._customers.length);
  }

  async callInfoExternalServices() : Promise<any[]>{
    const data = [];
    const res = await this.http.get(this.baseApi+'/api/externalservices/info',{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyRes = JSON.parse(JSON.stringify(res));
    for(const item of bodyRes){
      data.push(item);
    };
    return data;
  }

  //delete an url external service
  async delUrlExternalService(exurl: string,cmp : string, clt : string): Promise<number> {
    const url = this.baseApi+`/api/delete/externalservices/url/`+encodeURIComponent(exurl)+'/externalcomponent/'+cmp+'/cluster/'+clt+'/'+localStorage.getItem('roleId');
    //console.log(encodeURIComponent(exurl));
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });
    
    return new Promise<number>((resolve, reject) => {
      this.http.delete(url, { headers }).subscribe(
        response => {
          console.log('Response delete url external service:', response);
          const codeStatus = 200;
          //console.log(codeStatus);
          resolve(codeStatus);
        },
        error => {
          console.error('Error:', error);
          const codeStatus = error['status'];
          //console.log(codeStatus);
          resolve(codeStatus);
        }
      );
    });
  }

  //get a list of components of an external service
  async callListComponentsExternalService(exserviceName : string) : Promise<any[]>{
    const data = [];
    const res = await this.http.get(this.baseApi+'/api/externalservices/'+exserviceName+'/components',{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json'}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyRes = JSON.parse(JSON.stringify(res));
    for(const item of bodyRes){
      data.push(item['excomponent_name']);
    };
    return data;
  }

  //create a new cluster url in external_service
  async postClusterExternalService(clusterName : string, exserviceName : string, excomponents : string[], exurls : string[]) {
    const url = this.baseApi+'/api/post/externalservices/cluster'; // URL of the API endpoint
    const combinedStr = [];
    for (let i = 0; i < excomponents.length; i++) {
      const str = {
        excomponent_name : excomponents[i],
        exurl_host : exurls[i]
      }
      combinedStr.push(str);     
    }
    const data = { 
      cluster_name : clusterName,
      exservice_name: exserviceName,
      components : combinedStr, 
      roleId : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    //console.log(data);
    //Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.post(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response post url external customer:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //post service history 
  async postService(dt : any) {
    const url = this.baseApi+'/api/post/history/service/'; // URL of the API endpoint
    console.log("history service : "+dt);
    console.log(dt);
    const data = dt; // Data to be sent in the request body
    //console.log(dt);
    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });
    this.http.post(url, dt, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response post service:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  async getToken(username: string, pwd: string): Promise<boolean> {
    const url = this.baseApi + '/api/post/token'; // URL of the API endpoint
    const data = {
      username: username,
      password: pwd
    }; // Data to be sent in the request body

    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    try {
      const response = await this.http.post(url, data, { headers }).toPromise();
      localStorage.setItem('token', JSON.parse(JSON.stringify(response)).token);
      localStorage.setItem('roleId',JSON.parse(JSON.stringify(response)).roleId);
      // Assuming your API returns a boolean indicating success
      const success = response as boolean;
      if (success) {
        return true;
      } else {
        return false;
      }
    } catch (error) {
      // Handle the error
      console.error('Error:', error);
      return false; // or throw an error, depending on your error handling strategy
    }
  }

  //get list of users, admin role required
  async callUsers(){
    this._users = [];
    const res = await this.http.get(this.baseApi+'/api/users/'+localStorage.getItem('roleId'),{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json',}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyRes = JSON.parse(JSON.stringify(res));
    for(const item of bodyRes){
      this._users.push({key : item.username, value : item.role_name});
    };
  }

  //post user
  async postUser(dt : any) {
    const url = this.baseApi+'/api/post/user/'+localStorage.getItem('roleId'); // URL of the API endpoint
    const data = dt; // Data to be sent in the request body
    //console.log(dt);
    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });
    this.http.post(url, dt, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response post user:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //delete a user
  async delUser(username: string): Promise<number> {
    const url = this.baseApi+`/api/delete/user/${username}/${localStorage.getItem('roleId')}`;
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });
    
    return new Promise<number>((resolve, reject) => {
      this.http.delete(url, { headers }).subscribe(
        response => {
          console.log('Response delete user:', response);
          const codeStatus = 200;
          //console.log(codeStatus);
          resolve(codeStatus);
        },
        error => {
          console.error('Error:', error);
          const codeStatus = error['status'];
          //console.log(codeStatus);
          resolve(codeStatus);
        }
      );
    });
  }

  //change pwd of username 
  async updatePwdUser(username : string, newpwd : string) : Promise<number>{
    const url = this.baseApi+'/api/patch/password/'+localStorage.getItem('roleId'); // URL of the API endpoint
    const data = {
      "username" : username,
      "newpwd" : newpwd, 
      "roleId" : localStorage.getItem('roleId')
    }; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    return new Promise<number>((resolve, reject) =>{
        this.http.patch(url, data, { headers }).subscribe(
        response => {
          // Handle the response data
          console.log('Response update pwd user:', response);
          const codeStatus = 200;
          resolve(codeStatus);
        },
        error => {
          // Handle the error
          console.error('Error:', error);
          const codeStatus = error['status'];
          //console.log(codeStatus);
          resolve(codeStatus);
        }
      );
    })
  }

  //call fresh time
  async callRefreshTime(){
    const res = await this.http.get(this.baseApi+'/api/refreshtime',{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json',}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyRes = JSON.parse(JSON.stringify(res));
    this.refreshTime = bodyRes[0].refresh_time;
    console.log("refresh time : "+this.refreshTime/1000+" seconds");
  }

  //change refresh time
  async updateRefreshTime(newTime : number) {
    const url = this.baseApi+`/api/patch/refreshtime/${newTime}/${localStorage.getItem('roleId')}`; // URL of the API endpoint
    const data = {};

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.patch(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response update refresh time :', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }

  //call list of mails
  async callMail(){
    this.listMails = [];
    const res = await this.http.get(this.baseApi+'/api/mail',{'headers' : new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token')
    }), 'responseType': 'json',}).toPromise().catch((e) => {
      alert("Your Session Has Expired. Please sign in again ");
      this.router.navigate(['/']);
    });
    let bodyRes = JSON.parse(JSON.stringify(res));
    for(const elt of bodyRes){
      this.listMails.push(elt.mail);
    }
    //console.log(this.listMails);
  }

    //delete a mail
    async delMail(mail: string) {
      const url = this.baseApi+`/api/delete/mail/${mail}/${localStorage.getItem('roleId')}`;
      const headers = new HttpHeaders({
        'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
      });
      
  
      this.http.delete(url, { headers }).subscribe(
        response => {
          console.log('Response delete user:', response);
          
        },
        error => {
          console.error('Error:', error);

        }
      );
  }

  //create new mail 
  async postMail(mail : string) {
    const url = this.baseApi+'/api/post/mail'; // URL of the API endpoint
    const data = { new_mail: mail, roleId : localStorage.getItem('roleId')}; // Data to be sent in the request body

    // Optional: Set headers if needed
    const headers = new HttpHeaders({
      'Authorization': 'Bearer '+localStorage.getItem('token'), 'Content-Type': 'application/json'
    });

    this.http.post(url, data, { headers }).subscribe(
      response => {
        // Handle the response data
        console.log('Response post mail:', response);
      },
      error => {
        // Handle the error
        console.error('Error:', error);
      }
    );
  }
  
}
