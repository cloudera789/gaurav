import { Component, OnInit } from '@angular/core';
import { MainserviceService } from '../services/mainservice.service';
import { Project } from '../models/project';
import { Cluster } from '../models/cluster';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],

})
export class HomeComponent implements OnInit {

  constructor(public mainservice : MainserviceService){

    
  }
  ngOnInit(): void {
    this.mainservice.initHome();
  }
 
  getClusters(proj : Project) : Cluster[]{
    return proj.clusters;
    
  }
  //As we hard coded, we can call cluster.service. but later, must call a method which calls API. Think abt async ...  
  // getServices(cluster : Cluster) {
  //   for(let service of cluster.services){
  //     console.log("Service name : "+service.serviceName+", of cluster: "+service.clusterName+", status: "+service.status+", msg: "+service.msg);
  //   }
  // }

  refreshAll(): void {
    location.reload();
  }

  async callACluster(clusterName : string){
    await this.mainservice.callACluster(clusterName);

  }
}
