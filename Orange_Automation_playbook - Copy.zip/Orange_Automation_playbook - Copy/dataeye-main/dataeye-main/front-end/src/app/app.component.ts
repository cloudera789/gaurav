import { Component, OnInit } from '@angular/core';
import { MainserviceService } from './services/mainservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  constructor(public mainservice : MainserviceService){}

  ngOnInit(): void {
    // this.mainservice.startTimer().subscribe(() => {
    //   // Log a message every 5 minutes
    //   console.log('Message logged at ' + new Date());
    //   this.mainservice.initHome();

    // });
  }
  title = 'DataEye';

  
}
