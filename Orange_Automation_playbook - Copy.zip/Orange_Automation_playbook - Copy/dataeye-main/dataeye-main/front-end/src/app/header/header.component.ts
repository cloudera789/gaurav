import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { MainserviceService } from '../services/mainservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  roleId! : string | null;
  constructor(private router : Router, public mainservice : MainserviceService) { 
   
  }

  shouldShowNavbar(): boolean {
    // Check if the current route is not the login page
    this.roleId = localStorage.getItem('roleId');
    return this.router.url !== '/';
    
  }

  resetToken(){
    localStorage.setItem('token','');
    localStorage.setItem('roleId','');
    localStorage.setItem('username','');
  }

}
