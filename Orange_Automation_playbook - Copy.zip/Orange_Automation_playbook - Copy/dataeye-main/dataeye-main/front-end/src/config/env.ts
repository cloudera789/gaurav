const PROD_MODE = false;  //change here

const url = PROD_MODE ? 'http://fehusvcp-vco004:3000' : 'http://localhost:3000';


export const environment = {
    baseApi : url
}