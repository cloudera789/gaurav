# SUMMARY

- vco4 (`fehusvcp-vco004`) is a new server which has been setup by Eric to support cluster-wide applications (like DataEye)
- This server can directly access to clusters using peering interface. This needs to add addtional routes (see below)
- It was created in the MA tenant on FCA: `OCB0001657`
- OS is ubuntu 22.04:
`root@fehusvcp-vco004:/etc/netplan# cat /etc/os-release`
PRETTY_NAME="Ubuntu 22.04.2 LTS"
NAME="Ubuntu"
VERSION_ID="22.04"
VERSION="22.04.2 LTS (Jammy Jellyfish)"
VERSION_CODENAME=jammy
ID=ubuntu
ID_LIKE=debian
HOME_URL="https://www.ubuntu.com/"
SUPPORT_URL="https://help.ubuntu.com/"
BUG_REPORT_URL="https://bugs.launchpad.net/ubuntu/"
PRIVACY_POLICY_URL="https://www.ubuntu.com/legal/terms-and-policies/privacy-policy"
UBUNTU_CODENAME=jammy

## vco4 configuration to access clusters

- `cd /etc/netplan/`
- edit `/etc/netplan/50-cloud-init.yaml`
- compute new network plan
    `netplan apply`
- Edit `/etc/hosts` and add desired clusters hosts IP from vco2 /etc/hosts.d/01-hosts-ref (see example in `etc_hosts` file)
- Copy ssh config template from GitLab `tools/config` and remove all `ProxyJump` and bastions definition (see example in `ssh_config` file)

`/!\ When a new cluster is created in DataEye, don't forget to add route in 50-cloud-init.yaml and cluster entries in etc_hosts templates`

### Authors

MDO + ESA, July 2023
