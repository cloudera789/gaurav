===========================
kafka-offsets/getOffsets.sh
===========================

Used to display the beginning and end offsets per topic partition and the total number of messages per topic.

This script is located into the kafka-scripts dir and must be executed on a Kafka broker node.

Usage
=====
# ./getoffsets.sh consumer_group_id topics_list

You can give more than one topic at the end of the command line.

-------------
/!\ IMPORTANT
-------------
JAVA_HOME must be defined in environment vars of OS.

Sample output
-------------
The program will display output like the following:

# ./getoffsets.sh group_test test-michel test_kafka metrics druid-metrics
Kafka bootstrap.servers is mdo-vhs001.data.mdo:6643
Topics list is [test-michel, test_kafka, metrics, druid-metrics]
Java path is /usr/jdk64/jdk1.8.0_172
Security protocol is SASL_SSL
assignments of subscribed topics-partitions: [druid-metrics-0, test_kafka-0, test-michel-0, test-michel-1, metrics-0, test-michel-2, test-michel-3]
endOffsets: {druid-metrics-0=74378171, test_kafka-0=5, test-michel-0=2267846, test-michel-1=250252, metrics-0=534, test-michel-2=250253, test-michel-3=250254}
beginningOffsets: {druid-metrics-0=53167308, test_kafka-0=5, test-michel-0=2017593, test-michel-1=0, metrics-0=534, test-michel-2=0, test-michel-3=0}
*** # of messages per topic-partition ***
druid-metrics-0: 21 210 863
test_kafka-0: 0
metrics-0: 0
test-michel-0: 1 001 012

===========================
ConsumerGroupLag/getlags.sh
===========================

This program display information 
Usage
=====
# ./getlags.sh consumer_group_id refreshTime topics_list

All args are manadatory.
If 'refreshTime' is non-zero, the program will loop every 'refreshTime' seconds (use values >= 4)

Sample output
-------------
The program will display output like the following (if no refresh time is given):

# ./getlags.sh consumerGroupDemo 0 test-michel
Test if test-michel topic exists...Yes!

Good. Will process topics: test-michel

GROUP                          TOPIC                          PARTITION  CURRENT-OFFSET  LOG-END-OFFSET  LAG             OWNER                          LOG-START-OFFSET  NB_MESSAGES    2021-07-01 11:18:09
consumerGroupDemo              test-michel                    0          1221794         1221794         0               consumer-1_mdo-vkk001.data.mdo/10.102.10.251         1221384           410  

===================================================
Simple producer-consumer chain/producer_consumer.sh
===================================================

This program chains production and consumption of messages in a topic.
Used to test Kafka publish/subscribe configuration.

Usage
=====

/!\ This script must be run from kafka-script 'tools' folder.
# ./producer_consumer.sh
Missing required option: t
usage: ./kakfa-producer-consumer.jar <option> <arguments>
 -h,--help          prints command usage
 -n,--nmsg <arg>    number of messages to produce/consume
 -t,--topic <arg>   topic name

Sample output
-------------
The program will display output like the following (if no refresh time is given):

# ./producer_consumer.sh -n 2 -t test-michel
Record sent with key 0 to partition 0 with offset 1221794
Record sent with key 1 to partition 0 with offset 1221795
Record Key null
Record value This is record 0
Record partition 0
Record offset 1221794
Record Key null
Record value This is record 1
Record partition 0
Record offset 1221795


Author Information
------------------
- michel.dominique@orange.com
- Creation: April, 2020
- Revision: July, 2021
