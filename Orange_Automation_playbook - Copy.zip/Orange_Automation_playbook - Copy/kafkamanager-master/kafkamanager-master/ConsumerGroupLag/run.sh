#!/bin/bash
java -jar build/libs/ConsumerGroupLag-0.0.2-all.jar -b localhost:9092 -g consoleGroup -T "toto test-michel" -i -n 2000 $*
