package com.ocb.kafka;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Arrays;
import java.util.Map;
import java.util.Properties;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.cli.ParseException;
import org.apache.kafka.common.TopicPartition;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import kafka.admin.AdminClient;
import kafka.admin.AdminClient.ConsumerGroupSummary;
import kafka.admin.AdminClient.ConsumerSummary;
import org.apache.kafka.common.requests.OffsetFetchResponse.PartitionData;
import scala.collection.JavaConversions;


public class ConsumerGroupLag {

    static public class PartitionState {

        public long logStartOffset;
        public long logEndOffset;
        public int partition;
        public Object currentOffset;
        public Object lag;
        public String consumerId;
        public String host;
        public String clientId;

    }

    public static void main(String[] args) throws JsonProcessingException, OffsetFetchException, InterruptedException {

        String javaPath = System.getenv("JAVA_HOME");
        // List of defined security protocols
        List<String> protocolList = Arrays.asList("PLAINTEXT", "SSL", "SASL_SSL", "SASL_PLAINTEXT");
        // Consumer properties
        String bootstrapServers = "";
        String group = "";
        String securityProtocol = "PLAINTEXT";
        String truststorelocation = "bigdata1";
        String truststorePassword = "bigdata1";
        /*String keystorePassword = "bigdata1";
        String keyPassword = "bigdata1";
        */
        String topics;
        // Flags
        boolean debug;
        boolean outputAsJson;
        boolean includeStartOffset;
        boolean propertiesFile;
        String  propertiesFilePath = "config.properties";
        boolean loop = false;
        // Options values
        long groupStabilizationTimeoutMs = 5000L;
        long waitForResponseTime = 1000L;
        final int minLoopTime = 2000;
        int loopTime = minLoopTime;

        // Parse command-line arguments to get bootstrap.servers and group.id and other parameters and properties
        Options options = new Options();
        try {
            options.addOption(Option.builder("b").longOpt("bootstrap-servers").hasArg().argName("bootstrap-servers")
                    .desc("<server:port> list to connect to Kafka brokers").build());
            options.addOption(Option.builder("g").longOpt("group").hasArg().argName("group").desc(
                    "The consumer group we wish to act on").build());
            options.addOption(Option.builder("f").longOpt("properties-file").hasArg().argName("properties-file").desc(
                    "The name of the consumer properties file").build());
            options.addOption(Option.builder("T").longOpt("topics").hasArg().argName("topics").desc(
                    "topics list to monitor").build());
            options.addOption(Option.builder("n").longOpt("loop-time").hasArg().argName("loop-time").desc(
                    "execute as loop every n ms. Default: 2s (2000ms)").build());
            options.addOption(Option.builder("J").longOpt("json").argName("outputAsJson").desc(
                    "Output the data as json").build());
            options.addOption(Option.builder("d").longOpt("debug").argName("debug").desc(
                    "switch to debug mode").build());
            options.addOption(Option.builder("i").longOpt("include-start-offset").argName("includeStartOffset").desc(
                    "Include log-start-offset (the offset of the first record in a partition)").build());
            options.addOption(Option.builder("t").longOpt("group-stabilization-timeout")
                    .argName("groupStabilizationTimeoutMs")
                    .desc("time (ms) to wait for the consumer group description to be available (e.g. wait for a consumer group rebalance to complete)")
                    .build());
            options.addOption(Option.builder("w").longOpt("response-wait-time")
                    .argName("waitForResponseTime")
                    .desc("time (ms) to wait for asking request response.")
                    .build());
            options.addOption(Option.builder("s").longOpt("security-protocol").hasArg().argName("security-protocol").desc(
                    "The security protocol (default: PLAINTEXT)").build());
    
            // Set values according to command line
            CommandLine line = new DefaultParser().parse(options, args);
            if (line.hasOption("b")) bootstrapServers = line.getOptionValue("bootstrap-servers");
            if (line.hasOption("g")) group = line.getOptionValue("group");
            topics = line.getOptionValue("topics");
            outputAsJson = line.hasOption("json");
            if (line.hasOption("s")) {
                securityProtocol = line.getOptionValue("security-protocol");
                if (! protocolList.contains(securityProtocol)) {
                    throw new RuntimeException("Invalid security protocol value: " + securityProtocol);
                }
            }
            debug = line.hasOption("d");
            includeStartOffset = line.hasOption("i");
            propertiesFile = line.hasOption("f");
            if (propertiesFile) {
                propertiesFilePath = line.getOptionValue("properties-file");
            }
            // Do not loop if debug mode
            if (! debug) {
                loop = line.hasOption("loop-time");
                if (loop) {
                    // clear screen
                    System.out.print("\033[H\033[2J");
                    System.out.flush();
                    // get loop delay
                    loopTime = Integer.parseInt(line.getOptionValue("loop-time"));
                    if (loopTime < minLoopTime) {
                        loopTime = minLoopTime;
                    }
                }
            }
        } catch (ParseException ex) {
            HelpFormatter formatter = new HelpFormatter();
            formatter.printHelp("ConsumerGroupLag", "Consumer Group Lag", options, ex.toString(), true);
            throw new RuntimeException("Invalid command line options.");
        }

        // Initialize consumer properties
        Properties props = new Properties();
        if (propertiesFile) {
            //try (InputStream input = ConsumerGroupLag.class.getClassLoader().getResourceAsStream(propertiesFilePath)) {
            try (InputStream input = new FileInputStream(propertiesFilePath)) {
                    // load properties file content
                props.load(input);
                // required args
                if (bootstrapServers == "") {
                    bootstrapServers = props.getProperty("bootstrap.servers");
                } else {
                    props.setProperty("bootstrap.servers", bootstrapServers);
                }
                if (group == "") {
                    group = props.getProperty("group.id");
                } else {
                    props.setProperty("group.id", group);
                }
                props.setProperty("security.protocol", securityProtocol);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        else {
            // If no properties file given, some options are required
            try {
                if (bootstrapServers == "" && group == "") {
                    throw new RuntimeException("bootstrap.servers and group.id properties are missing");
                }
            } catch (RuntimeException ex) {
                System.out.println(ex.toString());
                System.exit(1);
            }
            props.put("bootstrap.servers", bootstrapServers);
            props.put("group.id", group);
            props.put("ssl.endpoint.identification.algorithm", "");
            props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
            props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");

            // Security
            props.put("security.protocol", securityProtocol);
            if (securityProtocol.contains("SASL") || securityProtocol.contains("SSL")) {
                props.put("ssl.truststore.location", StringUtils.stripEnd(javaPath, "/") + "/jre/lib/security/jssecacerts");
                props.put("ssl.truststore.password", truststorePassword);
                //props.put("ssl.keystore.location", "/etc/security/ocb_ssl/hadoop-private-keystore.jks");
                //props.put("ssl.keystore.password", keystorePassword);
                //props.put("ssl.key.password", keyPassword);
            }
        }

        // Create client configuration
        AdminClient ac = AdminClient.create(props);

        /*
         * {
         *   "topic-name" : {
         *     "partition-number" : {
         *       "logStartOffset" : ...
         *       "logEndOffset" : ...
         *       "partition" : ...
         *       "currentOffset" : ...
         *       "lag" : ...
         *       "consumerId" : ...
         *       "host" : ...
         *       "clientId" : ...
         *     },
         *     ...
         *   }
         * }
         */

        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (debug) {
            System.out.println("JAVA_HOME: "+javaPath);
            System.out.println("**** (1) "+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()));
        }

        // Loop until Ctrl-C
        while (true) {
            Date date = new Date();
            List<TopicPartition> c = new ArrayList<>();

            ConsumerGroupSummary summary = ac.describeConsumerGroup(group, groupStabilizationTimeoutMs);

            if (summary.state().equals("Dead")) {
                System.out.format("Consumer group %s does not exist.", group);
                System.out.println();
                System.exit(1);
            }

            if (!summary.state().equals("Stable")) {
                // PreparingRebalance, AwaitingSync
                System.err.format("Warning: Consumer group %s has state %s.", group, summary.state());
                System.err.println();
                System.exit(1);
            }

            scala.collection.immutable.List<ConsumerSummary> scalaList = summary.consumers().get();
            List<ConsumerSummary> csList = JavaConversions.seqAsJavaList(scalaList);
            if (csList.isEmpty()) {
                System.out.format("Consumer group %s is rebalancing.", group);
                System.out.println();
                System.exit(1);
            }

            Map<TopicPartition, ConsumerSummary> whoOwnsPartition = new HashMap<>();
            List<String> topicNamesList = new ArrayList<>();

            for (ConsumerSummary cs : csList) {
                scala.collection.immutable.List<TopicPartition> scalaAssignment = cs.assignment();
                List<TopicPartition> assignment = JavaConversions.seqAsJavaList(scalaAssignment);

                for (TopicPartition tp : assignment) {
                    whoOwnsPartition.put(tp, cs);
                    if (topics.contains(tp.topic()))
                        topicNamesList.add(tp.topic());
                }
                c.addAll(assignment);
            }

            if (debug) System.out.println(topicNamesList);

            // ===== This block of code is the slowest ====
            if (debug) System.out.println("**** (2.1) "+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()));
            //Get Per broker topic info based on topic list
            TopicPartitionsOffsetInfo topicPartitionsOffsetInfo = new TopicPartitionsOffsetInfo(ac);
            topicPartitionsOffsetInfo.storeTopicPartitionPerNodeInfo(props, topicNamesList);
            if (debug) System.out.println("**** (2.2) "+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()));

            //Get endoffset and BeginningOffsets info for all topics
            Map<TopicPartition, Long> endOffsets = topicPartitionsOffsetInfo.getEndOffsets();
            Map<TopicPartition, Long> beginningOffsets = topicPartitionsOffsetInfo.getBeginningOffsets();
            if (debug) System.out.println("**** (2.3) "+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()));

            //Get commited offset info
            topicPartitionsOffsetInfo.findCoordinatorNodeForGroup(group, waitForResponseTime);
            Map<TopicPartition, PartitionData> commitedOffsets = topicPartitionsOffsetInfo.getCommitedOffsets(group, c, waitForResponseTime);

            Map<String, Map<Integer, PartitionState>> results = new HashMap<>();
            if (debug) System.out.println("**** (3) "+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()));
            //==============================================

            for (TopicPartition tp : c) {

                if (!results.containsKey(tp.topic())) {
                    results.put(tp.topic(), new HashMap<>());
                }
                Map<Integer, PartitionState> topicMap = results.get(tp.topic());
                if (!topicMap.containsKey(tp.partition())) {
                    topicMap.put(tp.partition(), new PartitionState());
                }
                PartitionState partitionMap = topicMap.get(tp.partition());

                PartitionData topicPartitionCommitedOffset = commitedOffsets.get(tp);
                //-1: No Info available
                if (topicPartitionCommitedOffset.offset == -1){
                    topicPartitionCommitedOffset = null;
                }

                long end = endOffsets.get(tp);
                long begin = beginningOffsets.get(tp);

                partitionMap.logStartOffset = begin;
                partitionMap.logEndOffset = end;
                partitionMap.partition = tp.partition();

                if (topicPartitionCommitedOffset == null) {
                    // no committed offsets
                    partitionMap.currentOffset = "unknown";
                } else {
                    partitionMap.currentOffset = topicPartitionCommitedOffset.offset;
                }

                if (topicPartitionCommitedOffset == null || end == -1) {
                    // no committed offsets
                    partitionMap.lag = "unknown";
                } else {
                    partitionMap.lag = end - topicPartitionCommitedOffset.offset;
                }
                ConsumerSummary cs = whoOwnsPartition.get(tp);
                partitionMap.consumerId = cs.consumerId();
                partitionMap.host = cs.host();
                partitionMap.clientId = cs.clientId();
            }

            if (outputAsJson) {
                ObjectMapper mapper = new ObjectMapper();
                String jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(results);
                System.out.println(jsonInString);
            } else
                System.out.format("%-30s %-30s %-10s %-15s %-15s %-15s %-30s", "GROUP", "TOPIC", "PARTITION", "CURRENT-OFFSET", "LOG-END-OFFSET", "LAG", "OWNER");
                if (includeStartOffset) {
                    System.out.format(" %-15s  %-15s", "LOG-START-OFFSET", "NB_MESSAGES");
                }
                System.out.println(dateFormat.format(date));
                //System.out.println();
                for (String topic : results.keySet()) {
                    if (topics.contains(topic))  {
                        Map<Integer, PartitionState> partitionToAssignmentInfo = results.get(topic);
                        for (int partition : partitionToAssignmentInfo.keySet()) {
                            PartitionState partitionState = partitionToAssignmentInfo.get(partition);
                            Object currentOffset = partitionState.currentOffset;
                            long logEndOffset = partitionState.logEndOffset;
                            Object lag = partitionState.lag;
                            String host = partitionState.host;
                            String clientId = partitionState.clientId;
                            String owner = clientId + "_" + host;
                            System.out.format("%-30s %-30s %-10s %-15s %-15s %-15s %-30s", group, topic, partition, currentOffset, logEndOffset, lag, owner);
                            if (includeStartOffset) {
                                long logStartOffset = partitionState.logStartOffset;
                                long nbMessages = logEndOffset - logStartOffset;
                                System.out.format(" %-15s   %-15d", logStartOffset, nbMessages);
                            }
                            System.out.println();
                        }
                    }
                }
            if (debug) System.out.println("**** (4) "+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()));

            if (loop) {
                Thread.sleep(loopTime);
                System.out.print("\033[H");
                System.out.flush();
            }
            else {
                break;
            }
            }
            System.exit(0);
    }
}
