package com.ocb.kafka;

public class OffsetFetchException extends Exception {
    public OffsetFetchException(String message) {
        super(message);
    }
}
