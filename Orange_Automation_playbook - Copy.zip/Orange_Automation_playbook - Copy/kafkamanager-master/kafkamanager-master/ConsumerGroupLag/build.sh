#!/bin/bash
./gradlew build
./gradlew shadowJar

cp build/libs/ConsumerGroupLag-0.0.2-all.jar build/libs/ConsumerGroupLag-all.jar 
