
=============
Kafka scripts
=============

A collection of Kafka & Zookeeper scripts to help Ops in FE/FCA HDP clusters.
These scripts are installed on kafka brokers servers and edge hosts.

Scripts are splitted into different categories:
+	Kafka server (configs)
+	topics
+	consumers
+	consumer groups
+	producer
+   Kafka tools like JmxTool
+	zookeeper scripts related to Kafka

The use of scripts is simple but, if necessary, a README.md file is provided in the folders to specify some features.

Requirements
============

+	Kafka service
+   Zookeeper service

Installation
============
Usage of the playbook
=====================

Ansible host :
--------------

First, you need to add the kafka group in your inventory hosts file under the [kafka] markup.
Content of this group is filled with Kafka brokers hosts where scripts will be installed.

Run the playbook :
------------------

Playbook could be run on Ansible master with the following command line :

```
 ansible-playbook -i inventories/fe/<host> --private-key=<path to your key> -u <cloud for FE/admin for FCA>  
                        deployKafkaScripts.yml [-e SECURITY_PROTOCOL=SASL_SSL|SSL|PLAINTEXT]
                        [-e KAFKA_DIR=<path to Kafka bin dir>] [-e ZOOKEEPER_DIR=<path to Zookeeper bin dir>] 
                        [-e LOCAL_KAFKA_VERSION=<kafka-binaries to install on edge nodes>]
                        [-e LOG4J_LEVEL=<log4j root logger level>]
                        [-e KAFKA_ZNODE=<znode Zookeeper if not default />]
                        [-e PLATFORM=HDP|CDP]
                        [-e hdp26=true|false]
```
- SECURITY_PROTOCOL will be forced to SASL_SSL if kafka service keytab is found on the host.
If security protocol must be SSL (for Kafka Externe cluster for instance), you MUST SET the SECURITY_PROTOCOL var to SSL in the command line.
Else, SECURITY_PROTOCOL is PLAINTEXT by default.

- KAFKA_DIR and ZOOKEEPER_DIR points respectively to remote Kafka and Zookeeper bin directories and are in general defined in inventory files. If not, you need to give these vars in command line for the playbook to work correctly.

- LOCAL_KAFKA_VERSION: for edge hosts deployment, the playbook will install a binary Kafka distrib on host. Binaries Kafka archives are available in bootstrap FE into /var/www/html//mirror/kafka folder. Archive name pattern is kafka_{{LOCAL_KAFKA_VERSION}}.tar.gz (by default, LOCAL_KAFKA_VERSION=2.11-2.0.0). Change the version name with what you need. Currently 2.11-2.0.0, 2.11-2.1.0, 2.12-2.2.0 are available. More archives can be downloaded from https://kafka.apache.org/downloads 

- LOG4J_LEVEL: set the desired level for kafka scripts. Must be valid log4j values: TRACE, ERROR, WARN, INFO, DEBUG, ... By default: ERROR.

- KAFKA_ZNODE: use this path as kafka znode root in Zookeeper (for instance: /kafka in CDP). Default is empty string: Kafka znodes will be created at zookeeper znodes root.

- PLATFORM sets the target distribution for installation: this can be HDP (default) or CDP.

- hdp26: set to true for HDP 2.6.5 cluster. By default: false

Important
---------
In Ansible inventories, there must be an array variable containing Kafka servers list and used port to communicate with brokers, such as:
    KAFKA_SERVERS:
    - {host: "{{CLUSTER_NAME}}-vkk001.{{DOMAIN}}", id: 0, port: 6643}
    - {host: "{{CLUSTER_NAME}}-ves002.{{DOMAIN}}", id: 1, port: 6643}


Configuring Kafka script
=========================

A shell script is added to root account (kafka_scripts_env.sh) to enable env vars and aliases. This script is called in .bashrc
Configuration is done by playbook template to setup kafka_scripts_setup.sh according to your cluster configuration.
It uses ZK_SERVER and KAFKA_SERVERS variables which so need to be setup in host/group_vars/all/specific cluster inventory file.
Aliases are prefixed by 'k' letter then category letter ('t' for topics), for instance ktdescribe will run the 'kafka-topics --describe' function.

To activate LOG4J, create the following variable:
export KAFKA_OPTS=-Dlog4j.configuration=file:/root/kafka-scripts/tools-log4j.properties

If, for some reason, you get a heap error message, then you can increase heap size using the following environment var, for example:
export KAFKA_HEAP_OPTS="-Xmx2g -Xms2g"

Tools
=====

Other tools are available in kafka-scripts, written in Java:
-   getoffsets: get offsets of consumer for list of topics
-   getlags: get current lag of consumers for list of topics
-   producer_consumer: simulate a simple produce-consume chain

See README.kafka-scripts-tools.md for description.


How to uninstall kafka-scripts
==============================

Run playbook:
```
ansible-playbook -i inventories/fe/<host> --private-key=<path to your key> -u <cloud for FE/admin for FCA>  uninstallKafkaScripts.yml
```
tags:
    - removeKSFolder: remove kafka-scripts folder
    - removeKafkaClient: remove Kafka Client installed on edge only (/opt/Kafka_<version>
    
Author Information
------------------
- michel.dominique@orange.com
- Creation: April 2020
- Revision: July 2021, January 2023
