Object of the playbook
======================

Playbook goal is to focus on Kafka Manager installation, configuration and usage on HDP plateform. Cloud targets are both FE and FCA.

[https://github.com/yahoo/kafka-manager](https://github.com/yahoo/kafka-manager)


Kafka Manager
=============

A tool for managing Apache Kafka developed by Yahoo teams.

+	It supports the following :
+	Manage multiple clusters
+	Easy inspection of cluster state (topics, consumers, offsets, brokers, replica distribution, partition distribution)
+	Run preferred replica election
+	Generate partition assignments with option to select brokers to use
+	Run reassignment of partition (based on generated assignments)
+	Create a topic with optional topic configs (0.8.1.1 has different configs than 0.8.2+)
+	Delete topic (only supported on 0.8.2+ and remember set delete.topic.enable=true in broker config)
+	Topic list now indicates topics marked for deletion (only supported on 0.8.2+)
+	Batch generate partition assignments for multiple topics with option to select brokers to use
+	Batch run reassignment of partition for multiple topics
+	Add partitions to existing topic
+	Update config for existing topic
+	Optionally enable JMX polling for broker level and topic level metrics.
+	Optionally filter out consumers that do not have ids/ owners/ & offsets/ directories in zookeeper.

Requirements
============

+	Kafka 0.8.. or 0.9.. or 0.10.. or 0.11..
+	Java 8+
+	Ambari Server
+	Zookeeper
+	Free IPA (for LDAP)

Usage of the playbook
=====================

Considering the need of an offline deployment, a compiled version of Kafka Manager is available on both FCA and FE Bootstraps.

Ansible host :
--------------

Firstable, you need to add the kafka manager host under your host file under the kafkamanager markup. Best practice seems to put it on edge server (ves00x).

Run the playbook :
------------------

Playbook could be run locally with the following command line :

* FOR HDP clusters
```
 ansible-playbook -i ../inventories/fe/<host> --private-key=<path to your key> -u <cloud for FE/admin for FCA>  
                deployKafkaManager.yml -e SECURITY_PROTOCOL=SASL_SSL|SSL  [-e hdp26=true if edhv2 sandbox] --ask-vault
```
* FOR CDP clusters
```
 ansible-playbook -i ../inventories/fe/<host> --private-key=<path to your key> -u <cloud for FE/admin for FCA>  
                deployKafkaManager.yml -e SECURITY_PROTOCOL=SASL_SSL|SSL -e PLATFORM=CDP --ask-vault
```

This playbook allows you to install a preconfigured instance of Kafka Manager for following configuration :

+	LDAP (based on your FreeIPA service) : create a kafka-manger group with IPA admin user in it. Add members to this group in order to access to kafka manager.
+	Kafka through your Zookeeper service


Access to Kafka Manager
=======================

Once the deployment playbook successfully ran, you can access to Kafka Manager GUI through internet navigator :

```
http://<IP of your kafka manager host>:8888
or
https://<IP of your kafka manager host>:9443 (by default)
```

Kafka Manager is LDAPed with your FreeIPA instance. You need to be part of kafka-manager group. Identify yourself with FreeIPA credentials.


Configuring Kafka Manager
=========================

Application configuration : /usr/local/bin/kafka-manager/conf/application.conf
Log configuration : /usr/local/bin/kafka-manager/conf/logback.xml
Service configuration : /etc/systemd/system/kafka-manager.service


Author Information
------------------
- benjamin.philippini@orange.com
- 30-09-2019