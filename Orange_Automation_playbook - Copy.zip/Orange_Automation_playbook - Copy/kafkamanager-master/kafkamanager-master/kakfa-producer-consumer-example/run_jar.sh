#!/bin/bash
java -Djava.security.auth.login.config=/opt/kafka_2.11-2.0.0/config/kafka_jaas.conf -jar kakfa-producer-consumer-example/target/kakfa-producer-consumer-example-jar-with-dependencies.jar $@

