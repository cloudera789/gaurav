package com.ocb.kafka.consumer;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.Properties;

public class ConsumerCreator {

	public static Properties loadConfig() {
		String currentDir = System.getProperty("user.dir");

		try {
			InputStream input;
			File path = new File(currentDir + "/consumer.properties");
			if (path.exists()) {
				input = new FileInputStream(currentDir + "/consumer.properties");
			}
			else {
				input = ConsumerCreator.class.getClassLoader().getResourceAsStream("consumer.properties");
			}

			Properties prop = new Properties();
			// load a properties file
			prop.load(input);
			return prop;
		} catch (IOException ex) {
			ex.printStackTrace();
			return null;
		}
	}

	public static Consumer<Long, String> createConsumer(String topic) {
		final Properties props = loadConfig();
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, LongDeserializer.class.getName());
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());

		final Consumer<Long, String> consumer = new KafkaConsumer<>(props);
		consumer.subscribe(Collections.singleton(topic));
		return consumer;
	}

}
