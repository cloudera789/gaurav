package com.ocb.kafka;

import com.ocb.kafka.consumer.ConsumerCreator;
import com.ocb.kafka.producer.ProducerCreator;
import org.apache.commons.cli.*;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

public class App {
	static String currentDir;
	static String topicName;
	static int MESSAGE_COUNT;
	static int MAX_NO_MESSAGE_FOUND_COUNT;
	static String OFFSET_RESET_LATEST="latest";
	static String OFFSET_RESET_EARLIER="earliest";
	static Integer MAX_POLL_RECORDS;

	public static void main(String[] args) {
		currentDir = System.getProperty("user.dir");
		parseArgs(args);
		runProducer();
		runConsumer();
	}

	public static Properties loadConfig() {

		try {
			InputStream input;
			File path = new File(currentDir + "/application.properties");
			if (path.exists()) {
				//System.out.println("Loading current dir properties");
				input = new FileInputStream(currentDir + "/application.properties");
			}
			else {
				//System.out.println("Loading resources dir properties");
				input = App.class.getClassLoader().getResourceAsStream("application.properties");
			}
			Properties prop = new Properties();
			// load a properties file
			prop.load(input);
			/*for (Object key: prop.keySet()) {
				System.out.println(key + ": " + prop.getProperty(key.toString()));
			}*/
			return prop;
		} catch (IOException ex) {
			ex.printStackTrace();
			return null;
		}
	}

	static void parseArgs(String[] args) {
		String command=System.getProperty("sun.java.command").replaceAll(" .*", "");

		List<String> listSSL = Arrays.asList("SSL", "SASL_SSL", "SASL_PLAINTEXT");

		Options options = new Options();
		// -h usage switch
		Option help = new Option("h", "help", false, "prints command usage");
		help.setRequired(false);
		options.addOption(help);

		// Number of messages to produce/consume
		Option nMsg = new Option("n", "nmsg", true, "number of messages to produce/consume");
		nMsg.setRequired(false);
		options.addOption(nMsg);

		Option topic = new Option("t", "topic", true, "topic name");
		topic.setRequired(true);
		options.addOption(topic);

		CommandLineParser parser = new DefaultParser();
		HelpFormatter formatter = new HelpFormatter();
		CommandLine cmd = null;

		Properties config = loadConfig();
		/*
		Enumeration<String> enums = (Enumeration<String>) config.propertyNames();
		while (enums.hasMoreElements()) {
			String key = enums.nextElement();
			String value = config.getProperty(key);
			System.out.println(key + " : " + value);
		}
		*/

		try {
			cmd = parser.parse(options, args);
		} catch (ParseException e) {
			System.out.println(e.getMessage());
			formatter.printHelp(command + " <option> <arguments>", options);
			System.exit(1);
		}

		if (cmd.hasOption("help")) {
			formatter.printHelp( command + " <option> <arguments>", options);
			System.exit(0);
		}

		topicName = cmd.getOptionValue("topic");
		if (cmd.hasOption("nmsg")) {
			//System.out.println(cmd.getOptionValue("nmsg"));
			MESSAGE_COUNT = Integer.parseInt(cmd.getOptionValue("nmsg"));
		}
		else {
			MESSAGE_COUNT = Integer.parseInt(config.getProperty("MESSAGE_COUNT"));
		}
		MAX_NO_MESSAGE_FOUND_COUNT = Integer.parseInt(config.getProperty("MAX_NO_MESSAGE_FOUND_COUNT"));
		MAX_POLL_RECORDS = Integer.parseInt(config.getProperty("MAX_POLL_RECORDS"));
	}

	static void runConsumer() {
		Consumer<Long, String> consumer = ConsumerCreator.createConsumer(topicName);

		int noMessageToFetch = 0;

		while (true) {
			final ConsumerRecords<Long, String> consumerRecords = consumer.poll(1000);
			if (consumerRecords.count() == 0) {
				noMessageToFetch++;
				if (noMessageToFetch > MAX_NO_MESSAGE_FOUND_COUNT)
					break;
				else
					continue;
			}

			consumerRecords.forEach(record -> {
				System.out.println("Record Key " + record.key());
				System.out.println("Record value " + record.value());
				System.out.println("Record partition " + record.partition());
				System.out.println("Record offset " + record.offset());
			});
			consumer.commitAsync();
		}
		consumer.close();
	}

	static void runProducer() {
		Producer<Long, String> producer = ProducerCreator.createProducer();

		for (int index = 0; index < MESSAGE_COUNT; index++) {
			final ProducerRecord<Long, String> record = new ProducerRecord<>(topicName,
					"This is record " + index);
			try {
				RecordMetadata metadata = producer.send(record).get();
				System.out.println("Record sent with key " + index + " to partition " + metadata.partition()
						+ " with offset " + metadata.offset());
			} catch (ExecutionException e) {
				System.out.println("Execution exception in sending record");
				System.out.println("Execution exception message" + e);
			} catch (InterruptedException e) {
				System.out.println("Interrupted exception in sending record");
				System.out.println("Interrupted exception message" + e);
			}
		}
	}
}
