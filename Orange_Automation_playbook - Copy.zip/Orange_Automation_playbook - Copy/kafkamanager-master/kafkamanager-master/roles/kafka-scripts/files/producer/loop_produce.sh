#!/bin/bash
#
# Script to produce messages forever (hit CTRL-C to stop)
#

startPath=`dirname $0`

if [ $# -lt 3 ]
then
  echo "Usage: $0 TopicName NumberMessages LoopPeriod(in s) [FirstMessageIndex]"
  exit 1
fi

. ${startPath}/../kafka_scripts_setup.sh

while :
do
    ${startPath}/send_messages.sh $1 $2 $4
    sleep $3
done
