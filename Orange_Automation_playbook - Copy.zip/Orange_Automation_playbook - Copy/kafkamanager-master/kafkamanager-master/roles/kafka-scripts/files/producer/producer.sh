#!/bin/bash
#
# Script to start kafka-console-producer tool on topic
#

startPath=`dirname $0`

if [ $# -eq 0 ]
then
  echo "Usage: $startPath TopicName [file of messages to ingest if given] \
                                    [Use key if present (give separator char to use)]"
  exit 1
fi

topic=$1

key_str=""
if [ "$3" != "" ]
then
  key_str="--property parse.key=true --property key.separator=$3"
fi

. ${startPath}/../kafka_scripts_setup.sh

if [ $# -eq 1 ]
then
  kafka-console-producer.sh --broker-list ${KAFKA_BROKER_LIST} --topic $topic --producer.config ${startPath}/producer.config ${key_str}
else
  kafka-console-producer.sh --broker-list ${KAFKA_BROKER_LIST} --topic $topic --producer.config ${startPath}/producer.config ${key_str} < $2
fi
