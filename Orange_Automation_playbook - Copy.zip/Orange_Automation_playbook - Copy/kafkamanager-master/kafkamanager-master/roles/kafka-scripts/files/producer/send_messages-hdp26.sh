#!/bin/bash
#
# Script to send messages to Kafka topic via loop
#
#   args: topic_name number_of_messages first_message_index 
#
# MDO - september 2019
#

startPath=`dirname $0`

if [ $# -lt 2 ]
then
  echo "Usage: $0 TopicName NumberMessages [FirstMessageIndex]"
  exit 1
fi

topic=$1
number_messages=$2

if [ -z "$3" ]
  then
    first_ind=1
  else
    first_ind=$3
fi

. ${startPath}/../kafka_scripts_setup.sh

# create messages
for ((i=$first_ind;i<=$number_messages+$first_ind-1;i++)) ; do
  echo "Hello World $i"  ;
done > bulk_messages.txt

# send messages to Kafka
kafka-console-producer.sh --broker-list ${KAFKA_BROKER_LIST} --topic $topic --producer.config ${startPath}/producer.config --security-protocol ${SECURITY_PROTOCOL} < bulk_messages.txt
