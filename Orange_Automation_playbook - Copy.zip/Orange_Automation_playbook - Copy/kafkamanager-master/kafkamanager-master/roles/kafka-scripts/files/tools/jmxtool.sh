#
# Script to get Kafka metrics using JmxTool class
#
# Produce follwing output:
#Trying to connect to JMX url: service:jmx:rmi:///jndi/rmi://:8999/jmxrmi.
#"time","kafka.server:type=BrokerTopicMetrics,name=MessagesInPerSec:Count","kafka.server:type=BrokerTopicMetrics,name=MessagesInPerSec:EventType","kafka.server:type=BrokerTopicMetrics,name=MessagesInPerSec:FifteenMinuteRate","kafka.server:type=BrokerTopicMetrics,name=MessagesInPerSec:FiveMinuteRate","kafka.server:type=BrokerTopicMetrics,name=MessagesInPerSec:MeanRate","kafka.server:type=BrokerTopicMetrics,name=MessagesInPerSec:OneMinuteRate","kafka.server:type=BrokerTopicMetrics,name=MessagesInPerSec:RateUnit"
#1606060370980,0,messages,0.0,0.0,0.0,0.0,SECONDS
#

startPath=`dirname $0`

if [ $# -lt 1 ]
then
  echo "Usage: $0 KAFKA_JMX_PORT [MetricName] [--one-time <true|false> --reporting-interval <refresh time (in ms)>]"
#   echo "Usage: $0 KAFKA_JMX_PORT [MetricType] [MetricName] [--one-time <true|false> --reporting-interval <refresh time (in ms)>]"
#   echo "    - For MetricType, choices are: BrokerTopicMetrics (default), BrokerTopicStats"
  echo "    - For MetricName, choices are: BytesInPerSec BytesOutPerSec BytesRejectedPerSec"
  echo "    -                              FailedFetchRequestsPerSec FailedProduceRequestsPerSec FetchMessageConversionsPerSec"
  echo "    -                              MessagesInPerSec (default) ProduceMessageConversionsPerSec"
  echo "    -                              ReplicationBytesInPerSec ReplicationBytesOutPerSec"
  echo "    -                              TotalFetchRequestsPerSec TotalProduceRequestsPerSec"
  echo "  Metrics are written to standard output every --reporting-interval (default: 2000 ms, unless <--one-time true> option is specified)."
  exit 1
fi

. ${startPath}/../kafka_scripts_setup.sh

jmxport=$1
metrictype="BrokerTopicMetrics"

# metrictype=$2
# if [ -z $metrictype ]
# then
#     metrictype="BrokerTopicMetrics"
# fi

shift
metricname=$1
if [ -z $metricname ]
then
    metricname="MessagesInPerSec"
fi
shift

cmd="kafka-run-class.sh kafka.tools.JmxTool --object-name kafka.server:type=$metrictype,name=$metricname --jmx-url service:jmx:rmi:///jndi/rmi://:$jmxport/jmxrmi $@"
echo $cmd
$cmd
