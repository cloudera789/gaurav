#!/bin/bash
#
# Script to start kafka-console-consumer tool on topic
#

startPath=`dirname $0`

if [ $# -eq 0 ]
then
  echo "Usage: $0 TopicName
                  [Enables from-beginning if present (give whatever value)]
                  [Enables timeout-ms if duration in ms given (minimum value: 5000)]
                  [Maximum messages to consume if present (default: all)]
                  [Use key if present (give separator char to use)] [Print key_value if present] 
                  [Use partition number if present] [Use offset number if present]"
  exit 1
fi

topic=$1

from_beginning=""
if [ "$2" != "" ]; then
    from_beginning="--from-beginning"
fi

timeout_ms=""
if [ "$3" != "" ]
then
    tmoms=$3
    re='^[0-9]+$'
    if ! [[ $tmoms =~ $re ]]; then
      echo "ERROR: Bad timeout-ms parameter ($tmoms is not a number)" >&2
      exit 1
    fi
    if [ "$tmoms" -lt "5000" ]; then
      tmoms=5000
      echo "INFO: timeout-ms parameter has been changed to $tmoms" >&2
    fi
    timeout_ms="--timeout-ms $tmoms"
fi

max_msg=""
if [ "$4" != "" ]
then
  max_msg="--max-messages=$4"
fi

key_str=""
if [ "$5" != "" ]
then
  key_str="--property print.key=true --property key.separator=$5"
fi

key_value_str=""
if [ "$5" != "" ]
then
  if [ "$6" != "" ]
  then
    key_value_str="--property print.value=true"
  else
    key_value_str="--property print.value=false"
  fi
fi

partition=""
if [ "$7" != "" ]
then
  partition="--partition $7"
  group_id=""
else
  group_id="--group consoleGroup"
fi

offset=""
if [ "$8" != "" ]
then
  offset="--offset $8"
  from_beginning=""
fi

. ${startPath}/../kafka_scripts_setup.sh

# run command
kafka-console-consumer.sh --bootstrap-server ${KAFKA_BROKER_LIST} --topic $topic --consumer.config ${startPath}/client.config \
  ${from_beginning} ${timeout_ms} ${max_msg} ${key_str} ${key_value_str} ${partition} ${offset}
#kafka-console-consumer.sh --bootstrap-server ${KAFKA_BROKER_LIST} --topic $topic --consumer.config ${startPath}/client.config \
#  ${from_beginning} ${timeout_ms} ${group_id} ${max_msg} ${key_str} ${key_value_str} ${partition} ${offset}
