#!/bin/bash
#
# Script to search a file name through kafka-console-consumer tool and kafka key on topic
# Return kafka key that matched with string passed in parameter

startPath=`dirname $0`

if [ $# -eq 0 ]
then
  echo "Usage: $0 TopicName KafkaKeyToRetrieve
                  [Enables timeout-ms if duration in ms given (set previous param to empty string and give ms value >= 5000)]"
  exit 1
fi

topic=$1

kafka_key=$2


timeout_ms=""
if [ "$3" != "" ]
then
    tmoms=$3
    re='^[0-9]+$'
    if ! [[ $tmoms =~ $re ]]; then
      echo "ERROR: Bad timeout-ms parameter ($tmoms is not a number)" >&2
      exit 1
    fi
    if [ "$tmoms" -lt "5000" ]; then
      tmoms=5000 
      echo "INFO: timeout-ms parameter has been changed to $tmoms" >&2
    fi
    timeout_ms="--timeout-ms $tmoms"
fi


. ${startPath}/../kafka_scripts_setup.sh

kafka-console-consumer.sh --bootstrap-server ${KAFKA_BROKER_LIST} --topic $topic --consumer-property security.protocol=${SECURITY_PROTOCOL} --property print.key=true --property print.value=false --from-beginning ${timeout_ms} | grep -i ${kafka_key} 
