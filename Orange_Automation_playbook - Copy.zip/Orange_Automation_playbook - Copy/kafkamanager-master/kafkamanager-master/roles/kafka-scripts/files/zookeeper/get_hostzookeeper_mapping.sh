#!/bin/bash
startPath=`dirname $0`

. ${startPath}/../kafka_scripts_setup.sh

# Get all the Ids
ls_id=`zkCli.sh -server ${ZOOKEEPER_SERVER_LIST} -cmd ls /brokers/ids | grep '^\[' | sed -e 's/\[//g' | sed -e 's/\]//g' | sed -e 's/, /\n/g'`


# For each provide the mapping id:hostname in standard output
for id in ${ls_id}
do
	server=`(zkCli.sh -server ${ZOOKEEPER_SERVER_LIST} -cmd get /brokers/ids/${id} | grep endpoints | sed -e 's/:/\n/g' | grep '^/' | sort -u | sed -e 's/\/\///g' ) 2>/dev/null`
	echo ${id}:${server}
done

exit 0