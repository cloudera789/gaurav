#!/bin/bash
startPath=`dirname $0`

. ${startPath}/../kafka_scripts_setup.sh

# Launch zk shell
(which zkCli.sh) 2>/dev/null 1>/dev/null;
ret=$?
if [ ${ret} -ne 0 ]
then
    # on edge node we need to give port to zookeeper server, so we get the last :port in ZOOKEEPER_SERVER_LIST
    zookeeper-shell.sh ${ZOOKEEPER_SERVER}:${ZOOKEEPER_SERVER_LIST##*:}
else
    zkCli.sh -server ${ZOOKEEPER_SERVER_LIST}
fi
