#!/bin/bash

startPath=`dirname $0`

. ${startPath}/../kafka_scripts_setup.sh

ls_topic_list=`kafka-topics.sh --list --zookeeper ${ZOOKEEPER_SERVER_LIST} | grep -v '__consumer_offsets'`

TEMP_FILE="/tmp/topics_kafkareassign.json"
# Remove temporary json file if already exist
rm -f ${TEMP_FILE}
touch ${TEMP_FILE}

# Create a json file will the list of all topics.
# Json File is having the following format :
# {"topics": [{"topic": "foo1"},
#            {"topic": "foo2"}],
#  "version":1
#  }

# First element is a fix element
echo -n '{"topics":[' >> ${TEMP_FILE}
l=0

# For each topic
for topic in ${ls_topic_list}
do
	# Include a comma at the beginning of the topic part only starting from the 2nd topic
    if [ ${l} -gt 0 ] 
	then
	   echo ',' >> ${TEMP_FILE}
	fi
	echo -n '{"topic": "'${topic}'"}' >> ${TEMP_FILE}
	
	l=`expr ${l} + 1`
done
# Add bracket and version element at the end of the json
echo '],' 	>> ${TEMP_FILE}
echo '"version":1}' >> ${TEMP_FILE}

# Get all brokers ids list from zookeeper
brokers_ids=$(zkCli.sh -server ${ZOOKEEPER_SERVER_LIST} -cmd ls /brokers/ids | tail -1)
bids=${brokers_ids//[[:blank:]]/}

# GENERATE json reassign script based on topic list 
kafka-reassign-partitions.sh --zookeeper ${ZOOKEEPER_SERVER_LIST} --topics-to-move-json-file ${TEMP_FILE} --broker-list ${bids:1:-1} --generate > ${TEMP_FILE%.json}_generated.json


echo "##########################################################################################################"
echo "##    ${TEMP_FILE%.json}_generated.json generated"
echo "##    Review it and use it to create a json file to use to reassign topics/partitions/replicas"
echo "##    Command to reassign : $KAFKA_SCRIPTS_HOME/topics/reassign-partitions.sh"
echo "##########################################################################################################"


exit 0