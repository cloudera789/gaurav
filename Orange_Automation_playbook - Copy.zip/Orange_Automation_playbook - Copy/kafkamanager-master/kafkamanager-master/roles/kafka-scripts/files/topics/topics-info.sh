#!/bin/bash

startPath=`dirname $0`

. ${startPath}/../kafka_scripts_setup.sh

if [ "$1" == "" ]
then
  cmd="--list"
else
  cmd="--describe"
fi

echo "===================== topics list ====================="
kafka-topics.sh --zookeeper ${ZOOKEEPER_SERVER_LIST} ${cmd}
echo ""

echo "===================== topics with overrides ====================="
kafka-topics.sh --zookeeper ${ZOOKEEPER_SERVER_LIST} --describe --topics-with-overrides
echo ""
