#!/bin/bash

startPath=`dirname $0`

if [ $# -ne 3 ]
then
  echo "Usage: $0 TopicName Property Value"
  echo "See https://kafka.apache.org/10/documentation.html#topicconfigs for list of topic properties."
  exit 1
fi

. ${startPath}/../kafka_scripts_setup.sh

if [ "$2" == "" ];
then
    echo -n "ERROR: missing property name name for topic $1 "
    exit 1
fi

if [ "$3" == "" ];
then
    echo -n "ERROR: missing property value for topic $1 entity name $2"
    exit 1
fi

echo "===================== alter topic: $1 $2=$3 ====================="
kafka-topics.sh --alter --topic $1 --zookeeper ${ZOOKEEPER_SERVER_LIST} --config $2=$3
echo ""
