#!/bin/bash

startPath=`dirname $0`

. ${startPath}/../kafka_scripts_setup.sh

#Get the list of topics and the broker list
echo "TOPIC;PARTITION_NUM;LEADER;BROKER_LIST;LOCALSIZEONDISK"
desc=`kafka-topics.sh --describe --zookeeper ${ZOOKEEPER_SERVER_LIST} | grep -v '^Topic' | sed -e 's/ /;/g' | sed -e 's/\t/;/g' | cut -d ';' -f3,5,7,9`
for content in ${desc}
do 
    partition=`echo ${content} | cut -d ';' -f1-2 | sed -e 's/;/-/g'`
	size=`du -k -c ${KAFKA_LOGS_PATH}/${partition} 2>/dev/null | tail -1 | sed -e 's/\t/;/g' | cut -d ';' -f1`
    echo "${content};${size}"
done

exit 0


