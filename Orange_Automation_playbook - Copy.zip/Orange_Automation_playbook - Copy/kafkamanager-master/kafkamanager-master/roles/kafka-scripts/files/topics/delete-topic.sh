#!/bin/bash

startPath=`dirname $0`

if [ $# -ne 1 ]
then
  echo "Usage: $0 TopicName"
  exit 1
fi

. ${startPath}/../kafka_scripts_setup.sh

echo "===================== delete topic: $1 ====================="
kafka-topics.sh --delete --topic $1 --zookeeper ${ZOOKEEPER_SERVER_LIST}
echo ""
