#!/bin/bash

startPath=`dirname $0`

if [ $# -ne 1 ]
then
  echo "Usage: $0 TopicName"
  exit 1
fi

topic=$1

. ${startPath}/../kafka_scripts_setup.sh

TEMP_FILE="/tmp/topicPartitionList.json"
# Remove temporary json file if already exist
rm -f ${TEMP_FILE}
touch ${TEMP_FILE}

# First element is a fix element
echo -n '{"topics":[' >> ${TEMP_FILE}
l=0

# For given topic
echo -n '{"topic": "'${topic}'"}' >> ${TEMP_FILE}

# Add bracket and version element at the end of the json
echo '],' 	>> ${TEMP_FILE}
echo '"version":1}' >> ${TEMP_FILE}

echo "===================== topic leader election ====================="
kafka-preferred-replica-election.sh --zookeeper ${ZOOKEEPER_SERVER_LIST}  --path-to-json-file ${TEMP_FILE}
