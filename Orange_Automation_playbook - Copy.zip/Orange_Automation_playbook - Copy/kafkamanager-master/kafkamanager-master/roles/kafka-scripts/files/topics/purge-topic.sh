#
# Script to empty a topic by purging messages
# Uses kafka-configs.sh script
#
# This is done by running twice this script:
#   1- set the retention.ms to a small value
#      (using kafka-configs --add-config retention.ms=100 in ms)
#   2- set this property to the normal value or the cluster 
#      (using kafka-configs --delete-config retention.ms)
#

startPath=`dirname $0`

if [ $# -ne 2 ]
then
  echo "Usage: $0 TopicName Command(set|unset)"
  exit 1
fi

. ${startPath}/../kafka_scripts_setup.sh

topic=$1

# Check command passed to script
case $2 in

  set)
    command="--add-config"
    # new value in ms
    value="=100"
    ;;

  unset)
    command="--delete-config"
    value=""
    ;;

  *)
    echo -n "ERROR: unknown command ($2). Valid values are: set, unset"
    exit 1
    ;;
esac

servers="--zookeeper ${ZOOKEEPER_SERVER_LIST}"

kafka-configs.sh $servers --entity-type topics --entity-name $topic --alter $command retention.ms$value
