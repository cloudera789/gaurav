#!/bin/bash

startPath=`dirname $0`

. ${startPath}/../kafka_scripts_setup.sh

echo "===================== topics list ====================="
kafka-topics.sh --zookeeper ${ZOOKEEPER_SERVER_LIST} --list
