#!/bin/bash

startPath=`dirname $0`

if [ $# -ne 1 ]
then
  echo "Usage: $0 reassigments_json_file"
  exit 1
fi

my_file=$1

. ${startPath}/../kafka_scripts_setup.sh

echo "===================== reassign topic partitions ====================="
kafka-reassign-partitions.sh --zookeeper ${ZOOKEEPER_SERVER_LIST} --reassignment-json-file ${my_file} --execute
