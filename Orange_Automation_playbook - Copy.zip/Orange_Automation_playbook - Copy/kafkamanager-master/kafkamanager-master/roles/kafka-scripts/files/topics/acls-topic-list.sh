#
# Script to list ACLs on topic
#

startPath=`dirname $0`

if [ $# -eq 0 ]
then
  echo "Usage: $0 Topic"
  exit 1
fi

. ${startPath}/../kafka_scripts_setup.sh

kafka-acls.sh --authorizer-properties zookeeper.connect=${ZOOKEEPER_SERVER_LIST} --list --topic $1
