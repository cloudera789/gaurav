#
# Script to add ACLs on topic
#

startPath=`dirname $0`

if [ $# -ne 3 ]
then
  echo "Usage: $0 Topic Principal(User:username) Operation(read|write)"
  exit 1
fi

. ${startPath}/../kafka_scripts_setup.sh

kafka-acls.sh --authorizer-properties zookeeper.connect=${ZOOKEEPER_SERVER_LIST} --remove --allow-principal $2 --operation $3 --topic $1
