#
# Script to list all ACLs on topics
#

startPath=`dirname $0`

. ${startPath}/../kafka_scripts_setup.sh

kafka-acls.sh --authorizer-properties zookeeper.connect=${ZOOKEEPER_SERVER_LIST} --list
