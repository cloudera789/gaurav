#!/bin/bash

startPath=`dirname $0`

if [ $# -ne 2 ]
then
  echo "Usage: $0 TopicName Number_of_partitions"
  exit 1
fi

. ${startPath}/../kafka_scripts_setup.sh

if [ "$2" == "" ];
then
    echo -n "ERROR: missing new number of partitions value for topic $1 "
    exit 1
fi

echo "===================== add partitions: $1 $2 ====================="
kafka-topics.sh --alter --topic $1 --zookeeper ${ZOOKEEPER_SERVER_LIST} --partitions $2
echo ""
