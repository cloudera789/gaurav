Using topic partition reassignment scripts
------------------------------------------

* Reassignment of topic partitions/replicas between brokers is a semi-manual operation.

- Scripts: `generate_reassignment.sh` and `reassign-partitions.sh`
  * First, launch the `generate_reassignment.sh` script. It will 
    . automatically collect the current partitions table list for ALL TOPICS into `/tmp/topics_kafkareassign.json` file 
    . and passed this file to `kafka-reassign-partitions.sh` script in order to generate current partitions assignments for ALL TOPICS into `/tmp/topics_kafkareassign_generated.json` file.
  * Then, review the `/tmp/topics_kafkareassign_generated.json` file. See if "Proposed partition reassignment configuration" is suitable to your, else make changes in it and save the desired json block to a json file (for instance my_file.json).
  * Finally, launch the `reassign-partitions.sh` script with the path of my_file.json as first argument to reassign partitions/replicas according to my_file.json created during the (manually) previous step.

These operations can be done for example when increasing replicas number for a given topic.


* Fixing Preferred Leader assignment for a topic

- Script: `topic-leader-election.sh`, arg: topic name
  * First, the script automatically generates the current partition table for desired topic into `/tmp/topicPartitionList.json` file.
  * Then, this file is passed to `kafka-preferred-replica-election.sh`script to let Kafka set preferred broker leader for each partition of the topic.
