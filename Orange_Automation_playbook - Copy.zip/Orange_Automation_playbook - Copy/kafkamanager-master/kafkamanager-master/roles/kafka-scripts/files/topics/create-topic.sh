#!/bin/bash

startPath=`dirname $0`

if [ $# -ne 3 ]
then
  echo "Usage: $0 TopicName ReplicationFactor Partitions"
  exit 1
fi

. ${startPath}/../kafka_scripts_setup.sh

echo "===================== create topic: $1 $2 $3 ====================="
kafka-topics.sh --create --topic $1 --replication-factor $2 --partitions $3 --zookeeper ${ZOOKEEPER_SERVER_LIST}
echo ""
