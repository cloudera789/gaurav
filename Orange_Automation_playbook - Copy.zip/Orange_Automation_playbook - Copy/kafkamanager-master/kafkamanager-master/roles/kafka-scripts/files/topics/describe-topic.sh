#!/bin/bash

startPath=`dirname $0`

if [ $# -ne 1 ]
then
  echo "Usage: $0 TopicName"
  exit 1
fi

. ${startPath}/../kafka_scripts_setup.sh

echo "===================== topic: $1 ====================="
kafka-topics.sh --zookeeper ${ZOOKEEPER_SERVER_LIST} --describe --topic $1
echo ""
