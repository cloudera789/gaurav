#!/bin/bash

startPath=`dirname $0`

if [ $# -lt 1 ]
then
  echo "Usage: $0 list | [describe|delete ConsumerGroupName] [watch ConsumerGroupName nb_sec(default: 4)]"
  exit 1
fi

com=$1

if [[ "$1" != "list" && "$2" == "" ]]
then
  echo "Usage: $0 describe|delete|watch ConsumerGroupName"
  exit 2
fi

if [[ "$1" == "watch" && "$3" == "" ]]
then
  nb_sec=4
else
  nb_sec=$3
fi

consumer_group=$2

. ${startPath}/../kafka_scripts_setup.sh

case $com in

  list)
    kafka-consumer-groups.sh --bootstrap-server ${KAFKA_BROKER_LIST} \
          --command-config ${startPath}/config.properties --list
    ;;

  watch)
    watch -d -n $nb_sec kafka-consumer-groups.sh --bootstrap-server ${KAFKA_BROKER_LIST} \
          --command-config ${startPath}/config.properties --describe --group $consumer_group
    ;;

  describe)
    kafka-consumer-groups.sh --bootstrap-server ${KAFKA_BROKER_LIST} \
          --command-config ${startPath}/config.properties --describe --group $consumer_group
    ;;

  delete)
    kafka-consumer-groups.sh --bootstrap-server ${KAFKA_BROKER_LIST} \
          --command-config ${startPath}/config.properties --delete --group $consumer_group
    ;;

  *)
    echo "Bad command: $com"
    echo "Usage: $0 describe|watch ConsumerGroupName"
    exit 3
    ;;

esac
