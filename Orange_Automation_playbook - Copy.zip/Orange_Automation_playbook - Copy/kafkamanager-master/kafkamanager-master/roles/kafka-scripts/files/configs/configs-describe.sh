#
# Script to manage config information (for topics, supersede kafka-topics.sh)
#
# Describes entity passed in args (Type, Name)
#

startPath=`dirname $0`

if [ $# -lt 2 ]
then
  echo "Usage: $0 EntityType EntityName"
  echo "See https://kafka.apache.org/10/documentation.html#configuration for list of configs properties."
  exit 1
fi

. ${startPath}/../kafka_scripts_setup.sh

case $1 in

  brokers)
    servers="--zookeeper ${ZOOKEEPER_SERVER_LIST}"
    #servers="--bootstrap-server ${KAFKA_BROKER_LIST}"
    ;;

  topics | clients | users)
    servers="--zookeeper ${ZOOKEEPER_SERVER_LIST}"
    ;;

  *)
    echo -n "ERROR: unknown entity type ($1). Valid values are: brokers, topics, clients, users"
    exit 1
    ;;
esac

if [ "$2" == "" ];
then
    echo -n "ERROR: missing entity name for entity type $1"
    exit 1
fi

kafka-configs.sh $servers --entity-type $1 --entity-name $2 --describe
