kafka-offsets
=============

Used to display last offset per topic partition. Developed using IntelliJ Idea community edition (version 2020.2)

This program must be executed on a Kafka broker node.

Usage
=====
    # java [-Dlogging.level=<log4j level>] -Djava.security.auth.login.config=/etc/kafka/conf/kafka_jaas.conf 
            -jar kafka-offsets-1.0-SNAPSHOT-jar-with-dependencies.jar 
            -b mdo-vhs001.data.mdo:6643 -s SASL_SSL -g group_test [-t] --topics="test_kafka druid-metrics"

You can also use the getoffsets.sh script like this:
  ./getoffsets.sh mdo-vhs001.data.mdo:6643 SASL_SSL /etc/kafka/conf/kafka_jaas.conf group_test test_kafka druid-metrics

NOTES: 
-----
- you can give more than one topic in the --topics option entering space-separated names between quotation marks.
- logging.level System property is used to set the desired log4j level for logging.

Help screen
-----------
usage: Main [-h] -b BOOTSTRAPSERVERS [-s SECURITYPROTOCOL] [-t] [-g GROUPID] [--truststore.password TRUSTSTOREPASSWORD] --topics [TOPICS [TOPICS ...]]

named arguments:
  -h, --help             show this help message and exit
  -b BOOTSTRAPSERVERS, --bootstrap-servers BOOTSTRAPSERVERS
                         Kafka bootstrap servers
  -s SECURITYPROTOCOL, --security-protocol SECURITYPROTOCOL
                         Security protocol to use with Kafka: SASL_SSL, SSL, PLAINTEXT, ...
  -t, --total            Display total number of messages in topics
  -g GROUPID, --groupId GROUPID
                         Consumer Group Id to use for consumer
  --truststore.password TRUSTSTOREPASSWORD
                         ssl.truststore.password
  --topics [TOPICS [TOPICS ...]]

-------------
/!\ IMPORTANT
-------------
-D options must be given BEFORE -jar option
JAVA_HOME must be defined in environment vars.

Sample output
-------------
The program will display output like this:

[root@mdo-vhs001 kafka-scripts]# ./getoffsets.sh mdo-vhs001.data.mdo:6643 SASL_SSL /etc/kafka/conf/kafka_jaas.conf group_test test-michel test_kafka metrics druid-metrics
Kafka bootstrap.servers is mdo-vhs001.data.mdo:6643
Topics list is [test-michel, test_kafka, metrics, druid-metrics]
Java path is /usr/jdk64/jdk1.8.0_172
Security protocol is SASL_SSL
assignments of subscribed topics-partitions: [druid-metrics-0, test_kafka-0, test-michel-0, test-michel-1, metrics-0, test-michel-2, test-michel-3]
endOffsets: {druid-metrics-0=74378171, test_kafka-0=5, test-michel-0=2267846, test-michel-1=250252, metrics-0=534, test-michel-2=250253, test-michel-3=250254}
beginningOffsets: {druid-metrics-0=53167308, test_kafka-0=5, test-michel-0=2017593, test-michel-1=0, metrics-0=534, test-michel-2=0, test-michel-3=0}
*** # of messages per topic ***
druid-metrics-0: 21210863
test_kafka-0: 0
metrics-0: 0
test-michel-0: 1001012

AND if -t is given:
*** # of messages per topic ***
druid-metrics: 21210863
test_kafka: 0
metrics: 0
test-michel: 1001012
