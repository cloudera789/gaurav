#!/bin/bash
#
# Usage: ./getoffsets_pwd.sh 
#           key_password keystore_password truststore_password 
#           localhost:9092 
#           PLAINTEXT
#           /etc/kafka/conf/kafka_jaas.conf
#           group_test
#           test-michel
#

startPath=`dirname $0`

if [ $# -lt 8 ]
then
    echo "Usage: `basename $0` keystore_password truststore_password key_password bootstrap_servers security_protocol kafka_jaas_file_path consumer_group_id topics_list"
    exit 1
fi

keystore_password="$1"
shift
truststore_password="$1"
shift
key_password="$1"
shift
bootstrap_servers="$1"
shift
security_protocol="$1"
shift
kafka_jaas_file_path="$1"
shift
group_id="$1"
shift
topics="$@"

jar_path="$startPath/kafka-offsets-jar-with-dependencies.jar"

java -Djava.security.auth.login.config=$kafka_jaas_file_path -jar $jar_path -b $bootstrap_servers -g $group_id -s $security_protocol \
     --truststore.password $truststore_password --topics="$topics"
