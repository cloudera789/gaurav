/*
 * GetOffsets.java : get and display endOffsets of Kafka topics partitions
 */
import net.sourceforge.argparse4j.impl.Arguments;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.commons.lang3.StringUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.time.Duration;

// for argparse
import net.sourceforge.argparse4j.ArgumentParsers;
import net.sourceforge.argparse4j.inf.ArgumentParser;
import net.sourceforge.argparse4j.inf.ArgumentParserException;
import net.sourceforge.argparse4j.inf.Namespace;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.Configurator;

public class GetOffsets {
    public static void main(String[] args) throws IOException, ArgumentParserException {
        // Pretty print on terminal
        final String ANSI_RESET = "\u001B[0m";
        final String BLUE_BOLD = "\033[1;34m";

        // ========= Log4j =========
        // Get property -Dlogger.level if exists
        String loggingLevel = System.getProperty("logging.level");
        Level finalLevel = Level.ERROR;  // default value
        if (loggingLevel != null) {
            finalLevel = Level.toLevel(loggingLevel);
        } else {
            Properties p = System.getProperties();
            p.put("logging.level", "ERROR");
            System.setProperties(p);
        }
        Configurator.setRootLevel(finalLevel);
        Logger logger = LogManager.getLogger(GetOffsets.class);
        // =========================

        logger.info("Hello, this is GetOffsets!");

        final ArgumentParser argumentParser = ArgumentParsers.newFor("Main").build();
        argumentParser.addArgument("-f", "--properties-file")
                .dest("propertiesFile")
                .required(false)
                .help("Consumer properties file");
        argumentParser.addArgument("-b", "--bootstrap-servers")
                .dest("bootstrapServers")
                .required(false)
                .help("Kafka bootstrap servers");
        argumentParser.addArgument("-s", "--security-protocol")
                .dest("securityProtocol")
                .required(false)
                .setDefault("PLAINTEXT")
                .help("Security protocol to use with Kafka: SASL_SSL, SSL, PLAINTEXT, ...");
        argumentParser.addArgument("-v", "--verbose")
                .dest("verbose")
                .action(Arguments.storeTrue())
                .required(false)
                .help("Display more information if given");
        argumentParser.addArgument("-g", "--groupId")
                .dest("groupId")
                .required(false)
                .setDefault("ConsoleGroup")
                .help("Consumer Group Id to use for consumer");
        argumentParser.addArgument("--truststore.password")
                .dest("truststorePassword")
                .required(false)
                .setDefault("bigdata1")
                .help("ssl.truststore.password");
        argumentParser.addArgument("--keystore.password")
                .dest("keystorePassword")
                .required(false)
                .setDefault("bigdata1")
                .help("ssl.keystore.password");
        argumentParser.addArgument("--key.password")
                .dest("keyPassword")
                .required(false)
                .setDefault("bigdata1")
                .help("ssl.key.password");
        argumentParser.addArgument("--topics")
                .dest("topics")
                .required(true)
                .nargs("*");

        String propertiesFile = "config.properties";
        String bootstrapServers = "";
        List<String> topics = new ArrayList<>();
        String javaPath = System.getenv("JAVA_HOME");
        String securityProtocol = "";
        String groupId = "";
        String keystorePassword = "";
        String truststorePassword = "";
        String keyPassword = "";
        Boolean verbose = Boolean.FALSE;
        Boolean total = Boolean.FALSE;
        try {
            Namespace response = argumentParser.parseKnownArgs(args, null);
            propertiesFile = response.getString("propertiesFile");
            bootstrapServers = response.getString("bootstrapServers");
            topics = response.getList("topics");
            securityProtocol = response.getString("securityProtocol");
            groupId = response.getString("groupId");
            keystorePassword = response.getString("keystorePassword");
            truststorePassword = response.getString("truststorePassword");
            keyPassword = response.getString("keyPassword");
            verbose = response.getBoolean("verbose");
        } catch (ArgumentParserException e) {
            argumentParser.handleError(e);
            argumentParser.printHelp();
            System.exit(1);
        }

        logger.info("Properties file is " + propertiesFile);
        logger.info("Kafka bootstrap.servers is " + bootstrapServers);
        logger.info("Topics list is " + topics);
        logger.info("Java path is " + javaPath);
        logger.info("Security protocol is " + securityProtocol);
        logger.info("Consumer group id is " + groupId);

        Properties props = new Properties();
        if (propertiesFile != null) {
            //try (InputStream input = GetOffsets.class.getClassLoader().getResourceAsStream("config.properties")) {
            try (InputStream input = new FileInputStream(propertiesFile)) {
                // load a properties file
                props.load(input);
                // required args
                if (bootstrapServers == "") {
                    bootstrapServers = props.getProperty("bootstrap.servers");
                } else {
                    props.setProperty("bootstrap.servers", bootstrapServers);
                }
                if (groupId == "") {
                    groupId = props.getProperty("group.id");
                } else {
                    props.setProperty("group.id", groupId);
                }
                props.setProperty("security.protocol", securityProtocol);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        else {
            try {
                if (bootstrapServers == "" && groupId == "") {
                    throw new RuntimeException("bootstrap.servers property is missing");
                }
            } catch (RuntimeException ex) {
                System.out.println(ex.toString());
                System.exit(1);
            }
            props.put("bootstrap.servers", bootstrapServers);
            props.put("group.id", groupId);
            props.put("ssl.endpoint.identification.algorithm", "");
            props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
            props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");

            // Security
            props.put("security.protocol", securityProtocol);
            if (securityProtocol.contains("SASL") || securityProtocol.contains("SSL")) {
                props.put("ssl.truststore.location", StringUtils.stripEnd(javaPath, "/") + "/jre/lib/security/jssecacerts");
                props.put("ssl.truststore.password", truststorePassword);
                // props.put("ssl.keystore.location", "/etc/security/ocb_ssl/hadoop-private-keystore.jks");
                // props.put("ssl.keystore.password", keystorePassword);
                // props.put("ssl.key.password", keyPassword);
            }
         }
        // create Kafka consumer
        KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props);

        // Create topic list as array
        String[] itemsArray = topics.get(0).split("\\s+",-1);

        // Subscribe to topics
        consumer.subscribe(Arrays.asList(itemsArray));

        // ================================================
        // Get partitions assignments for subscribed topics
        // ================================================
        Set<TopicPartition> assignment = new HashSet<>();
        while (assignment.size() == 0) {
            consumer.poll(Duration.ofMillis(100));
            assignment = consumer.assignment();
        }
        if (verbose) {
            System.out.println("assignments of subscribed topics-partitions: " + assignment);
        }

        // =======================================
        // Get end offset for each topic-partition
        // =======================================
        Map<TopicPartition, Long> endOffsets = consumer.endOffsets(assignment);
        for (TopicPartition tp : assignment) {
            consumer.seek(tp, endOffsets.get(tp));
        }
        if (verbose) {
            System.out.println("endOffsets: " + endOffsets);
        }

        // =============================================
        // Get beginning offset for each topic-partition
        // =============================================
        Map<TopicPartition, Long> beginningOffsets = consumer.beginningOffsets(assignment);
        for (TopicPartition tp : assignment) {
            consumer.seek(tp, beginningOffsets.get(tp));
        }
        if (verbose) {
            System.out.println("beginningOffsets: " + beginningOffsets);
        }

        // ============================================
        // Count number of messages per topic-partition
        // ============================================
        Map<String, Long> sumTopicPartitionOffsets = new HashMap<String, Long>();
        Map<String, Long> endTopicPartitionOffsets = new HashMap<String, Long>();
        // Initialize result Map with end Offsets
        for (Map.Entry<TopicPartition, Long> e : endOffsets.entrySet()) {
            logger.debug(e.getKey() + ": " + e.getValue());
            String key = e.getKey().toString();
            Long value = e.getValue();
            endTopicPartitionOffsets.put(key, value);
            if (!sumTopicPartitionOffsets.containsKey(key)) {
                sumTopicPartitionOffsets.put(key, value);
            } else {
                sumTopicPartitionOffsets.put(key, sumTopicPartitionOffsets.get(key) + e.getValue());
            }
            logger.debug(key + ": " + sumTopicPartitionOffsets.get(key));
        }
        // Substract beginning Offsets
        Map<String, Long> beginTopicPartitionOffsets = new HashMap<String, Long>();
        for (Map.Entry<TopicPartition, Long> e : beginningOffsets.entrySet()) {
            logger.debug(e.getKey() + ": " + e.getValue());
            String key = e.getKey().toString();
            Long value = e.getValue();
            beginTopicPartitionOffsets.put(key, value);
            if (!sumTopicPartitionOffsets.containsKey(key)) {
                sumTopicPartitionOffsets.put(key, -value);
            } else {
                sumTopicPartitionOffsets.put(key, sumTopicPartitionOffsets.get(key) - value);
            }
            logger.debug(key + ": " + sumTopicPartitionOffsets.get(key));
        }

        // Print begin and end offsets and total number of messages per topic/partition if verbose mode
        if (verbose) {
            // Print topic/partition number of messages
            System.out.println();
            System.out.println(BLUE_BOLD + "*** # of messages per topic-partition ***" + ANSI_RESET);
            System.out.println(StringUtils.leftPad("-", 72, '-'));
            System.out.println(StringUtils.rightPad("Topic-Partition", 24) +
                    StringUtils.rightPad("BeginOffset", 16) +
                    StringUtils.rightPad("EndOffset",16) +
                    StringUtils.rightPad("NbMsg", 16));
            System.out.println(StringUtils.leftPad("-", 72, '-'));
            for (Map.Entry<String, Long> e : sumTopicPartitionOffsets.entrySet()) {
                System.out.println(StringUtils.rightPad(e.getKey(), 24) +
                        StringUtils.rightPad(beginTopicPartitionOffsets.get(e.getKey()).toString(), 16) +
                        StringUtils.rightPad(endTopicPartitionOffsets.get(e.getKey()).toString(),16) +
                        StringUtils.rightPad(e.getValue().toString(),16));
                //System.out.println(e.getKey() + " " + beginTopicPartitionOffsets.get(e.getKey()) + " " + endTopicPartitionOffsets.get(e.getKey()) + " " + e.getValue());
            }
            System.out.println(StringUtils.leftPad("-", 72, '-'));
        }

        // Set topic message count for endOffsets
        Map<String, Long> sumTopicOffsets = new HashMap<String, Long>();

        for (Map.Entry<TopicPartition, Long> e : endOffsets.entrySet()) {
            logger.debug(e.getKey() + ": " + e.getValue());
            String key = e.getKey().toString();
            String topicName = key.substring(0, key.lastIndexOf("-"));
            //String partitionNumber = key.substring(key.lastIndexOf("-") + 1, key.length());
            if (!sumTopicOffsets.containsKey(topicName)) {
                sumTopicOffsets.put(topicName, e.getValue());
            } else {
                sumTopicOffsets.put(topicName, sumTopicOffsets.get(topicName) + e.getValue());
            }
            logger.debug(topicName + ": " + sumTopicOffsets.get(topicName));
        }

        // Substract topic message count of beginningOffsets
        for (Map.Entry<TopicPartition, Long> e : beginningOffsets.entrySet()) {
            logger.debug(e.getKey() + ": " + e.getValue());
            String key = e.getKey().toString();
            Long value = e.getValue();
            String topicName = key.substring(0, key.lastIndexOf("-"));
            //String partitionNumber = key.substring(key.lastIndexOf("-") + 1, key.length());
            if (!sumTopicOffsets.containsKey(topicName)) {
                sumTopicOffsets.put(topicName, -value);
            } else {
                sumTopicOffsets.put(topicName, sumTopicOffsets.get(topicName) - value);
            }
            logger.debug(topicName + ": " + sumTopicOffsets.get(key));
        }

        // ============================
        // *** Prints total results ***
        // ============================
        System.out.println();
        System.out.println(BLUE_BOLD + "*** # of messages per topic ***" + ANSI_RESET);
        System.out.println(StringUtils.leftPad("-", 40, '-'));
        System.out.println(StringUtils.rightPad("Topic", 24) + StringUtils.rightPad("NbMsg", 20));
        System.out.println(StringUtils.leftPad("-", 40, '-'));
        for (Map.Entry<String, Long> e : sumTopicOffsets.entrySet()) {
            System.out.println(StringUtils.rightPad(e.getKey(), 24) +
                    StringUtils.rightPad(e.getValue().toString(),20));
            //System.out.println(e.getKey() + ": " + String.format("%,d", e.getValue()));
        }
        System.out.println(StringUtils.leftPad("-", 40, '-'));
    }
}

