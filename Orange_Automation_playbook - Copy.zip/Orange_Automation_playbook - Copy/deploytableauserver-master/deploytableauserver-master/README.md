deploy Tableau server
=========

This repo contains the code to deploy the tableau server.

Pre-Requisites
------------
We should have a linux server/VM running in the environment with the minimum configuration of 8 cores and 32G of RAM. Please refer to below link for the latest information.

https://help.tableau.com/current/server/en-us/server_hardware_min.htm

Usage
-----
Please update the hosts information with the linux server/VM ip in the inventory file.
Also, make sure the host field is updated with the host information in deploytableauserver.yml file
After running the playbook, please open https://tableau-server:8850 in browser to navigate to tableau server configuration.

Running playbook
-----
ansible-playbook -i <inv> --private-key=<>.pem -u <user> deploytableauserver.yml  --ask-vault-pass --list-tasks --list-hosts
